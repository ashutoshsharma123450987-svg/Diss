package com.ogstudio.streamer.rtmp;

import java.util.ArrayList;
import java.util.List;

/** Helpers for converting Annex-B H.264 (what MediaCodec gives us) to the RTMP / FLV layout. */
public final class H264Util {
    private H264Util() {}

    public static final class Nal {
        public final int off;
        public final int len;
        public final int type;

        Nal(int off, int len, int type) {
            this.off = off;
            this.len = len;
            this.type = type;
        }
    }

    /** Splits an Annex-B buffer into NAL units (start codes removed). */
    public static List<Nal> split(byte[] d, int off, int len) {
        List<Nal> res = new ArrayList<Nal>();
        int end = off + len;
        int i = off;
        int nalStart = -1;
        while (i + 2 < end) {
            if (d[i] == 0 && d[i + 1] == 0 && d[i + 2] == 1) {
                if (nalStart >= 0) addNal(res, d, nalStart, i);
                nalStart = i + 3;
                i += 3;
            } else {
                i++;
            }
        }
        if (nalStart >= 0 && nalStart < end) addNal(res, d, nalStart, end);
        return res;
    }

    private static void addNal(List<Nal> res, byte[] d, int start, int end) {
        // remove zero bytes that belong to the next 4 byte start code
        while (end > start && d[end - 1] == 0) end--;
        if (end > start) res.add(new Nal(start, end - start, d[start] & 0x1f));
    }

    /** Builds an AVCDecoderConfigurationRecord from a raw SPS and PPS (no start codes). */
    public static byte[] avcConfig(byte[] sps, byte[] pps) {
        byte[] r = new byte[11 + sps.length + pps.length];
        int p = 0;
        r[p++] = 1;
        r[p++] = sps[1];
        r[p++] = sps[2];
        r[p++] = sps[3];
        r[p++] = (byte) 0xFF; // 4 byte NAL length
        r[p++] = (byte) 0xE1; // one SPS
        r[p++] = (byte) (sps.length >> 8);
        r[p++] = (byte) sps.length;
        System.arraycopy(sps, 0, r, p, sps.length);
        p += sps.length;
        r[p++] = 1; // one PPS
        r[p++] = (byte) (pps.length >> 8);
        r[p++] = (byte) pps.length;
        System.arraycopy(pps, 0, r, p, pps.length);
        return r;
    }
}
