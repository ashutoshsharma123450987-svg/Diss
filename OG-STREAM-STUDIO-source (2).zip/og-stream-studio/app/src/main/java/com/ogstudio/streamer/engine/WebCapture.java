package com.ogstudio.streamer.engine;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/**
 * Shows one web page in an invisible WebView and copies it into a small bitmap a few times a
 * second. Kept deliberately light (small size, low frame rate) for weak phones. The page
 * background is transparent, so overlays with a transparent background blend into the stream.
 */
final class WebCapture {
    private static final int FPS = 8;
    private static final int MAX_W = 640;

    private final Context ctx;
    private final String url;
    private final int w;
    private final int h;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Bitmap[] bmps = new Bitmap[3];
    private final Canvas[] canvases = new Canvas[3];
    private int next;
    private volatile Bitmap front;
    private WebView web;
    private volatile boolean running;

    WebCapture(Context ctx, String url, float pxW, float pxH) {
        this.ctx = ctx.getApplicationContext();
        this.url = url;
        float k = Math.min(1f, MAX_W / Math.max(1f, pxW));
        this.w = Math.max(32, Math.round(pxW * k));
        this.h = Math.max(32, Math.round(pxH * k));
    }

    Bitmap frame() {
        return front;
    }

    void start() {
        running = true;
        main.post(new Runnable() {
            @Override
            public void run() {
                try {
                    for (int i = 0; i < 3; i++) {
                        bmps[i] = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                        canvases[i] = new Canvas(bmps[i]);
                    }
                    web = new WebView(ctx);
                    web.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
                    web.setBackgroundColor(Color.TRANSPARENT);
                    web.setVerticalScrollBarEnabled(false);
                    web.setHorizontalScrollBarEnabled(false);
                    WebSettings st = web.getSettings();
                    st.setJavaScriptEnabled(true);
                    st.setDomStorageEnabled(true);
                    st.setUseWideViewPort(true);
                    st.setLoadWithOverviewMode(true);
                    st.setMediaPlaybackRequiresUserGesture(false);
                    web.setWebViewClient(new WebViewClient());
                    web.measure(View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
                            View.MeasureSpec.makeMeasureSpec(h, View.MeasureSpec.EXACTLY));
                    web.layout(0, 0, w, h);
                    web.onResume();
                    web.loadUrl(url);
                    main.postDelayed(tick, 500);
                } catch (Throwable t) {
                    running = false; // WebView missing or broken: the stream goes on without it
                }
            }
        });
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!running || web == null) return;
            try {
                int i = next;
                next = (next + 1) % 3;
                bmps[i].eraseColor(Color.TRANSPARENT);
                web.draw(canvases[i]);
                front = bmps[i];
            } catch (Throwable ignored) {
            }
            main.postDelayed(this, 1000 / FPS);
        }
    };

    void stop() {
        running = false;
        main.post(new Runnable() {
            @Override
            public void run() {
                main.removeCallbacks(tick);
                try {
                    if (web != null) {
                        web.onPause();
                        web.destroy();
                    }
                } catch (Throwable ignored) {
                }
                web = null;
                front = null;
            }
        });
    }
}
