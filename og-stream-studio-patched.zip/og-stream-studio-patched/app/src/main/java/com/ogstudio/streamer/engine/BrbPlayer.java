package com.ogstudio.streamer.engine;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.media.Image;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaExtractor;
import android.media.MediaFormat;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.ShortBuffer;

/**
 * Plays the "STREAMING SOON" video (assets/brb.mp4) in a loop while BRB mode is on: the pictures go to
 * {@link #frame} (drawn inside the screen box) and the song goes into the audio mixer through a ring.
 *
 * To make BRB start at once, everything is prepared when the stream starts: the decoders are created and
 * the first picture is decoded into {@link #poster}. Turning BRB on only has to rewind and play.
 * Every part is optional: if the video or the sound cannot be decoded on a phone, the rest still works.
 */
final class BrbPlayer {
    /** Latest video picture while BRB is playing, else null. */
    static volatile Bitmap frame;
    /** First picture of the video, ready before BRB is switched on, so something correct shows instantly. */
    static volatile Bitmap poster;
    /** True when the video cannot be played on this phone (then the built-in animation is allowed). */
    static volatile boolean failed;

    private static final String ASSET = "brb.mp4";
    private static final String CACHE = "brb_v1.mp4";

    private final Context ctx;
    private final PcmRing musicRing;
    private int gen;
    private boolean playing;
    private boolean released;

    BrbPlayer(Context ctx, PcmRing musicRing) {
        this.ctx = ctx.getApplicationContext();
        this.musicRing = musicRing;
        failed = false;
        frame = null;
        poster = null;
        new Thread(new Runnable() {
            @Override
            public void run() {
                videoThread();
            }
        }, "og-brb-video").start();
        if (musicRing != null) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    audioThread();
                }
            }, "og-brb-audio").start();
        }
    }

    private synchronized boolean alive(int g) {
        return !released && playing && g == gen;
    }

    /** BRB ON: rewind and play. Returns at once. */
    synchronized void start() {
        gen++;
        playing = true;
        notifyAll();
    }

    /** BRB OFF. Returns at once; the player threads rewind and wait for the next start. */
    synchronized void stop() {
        gen++;
        playing = false;
        frame = null;
        if (musicRing != null) musicRing.trimTo(0);
    }

    /** Stream is over: threads end and the codecs are released. */
    synchronized void release() {
        released = true;
        playing = false;
        gen++;
        frame = null;
        poster = null;
        notifyAll();
    }

    /** Waits until BRB is switched on (returns its generation) or the player is released (returns -1). */
    private synchronized int waitForStart() throws InterruptedException {
        while (!released && !playing) wait();
        return released ? -1 : gen;
    }

    private String ensureFile() {
        try {
            File f = new File(ctx.getCacheDir(), CACHE);
            if (f.exists() && f.length() > 0) return f.getPath();
            InputStream in = ctx.getAssets().open(ASSET);
            FileOutputStream out = new FileOutputStream(f);
            byte[] buf = new byte[32768];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            out.close();
            in.close();
            return f.getPath();
        } catch (Throwable t) {
            return null;
        }
    }

    private static int findTrack(MediaExtractor ex, String prefix) {
        for (int i = 0; i < ex.getTrackCount(); i++) {
            String mime = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME);
            if (mime != null && mime.startsWith(prefix)) return i;
        }
        return -1;
    }

    private static void sleepMs(long ms) throws InterruptedException {
        if (ms > 0) Thread.sleep(ms);
    }

    // ------------------------------------------------------------------ video

    /** Buffers and bitmaps re-used for every decoded picture. */
    private static final class VideoState {
        final Bitmap[] bmps = new Bitmap[3];
        int next;
        int[] px;
        byte[] yb;
        byte[] ub;
        byte[] vb;
    }

    private void videoThread() {
        MediaExtractor ex = null;
        MediaCodec dec = null;
        try {
            String path = ensureFile();
            if (path == null) {
                failed = true;
                return;
            }
            ex = new MediaExtractor();
            ex.setDataSource(path);
            int track = findTrack(ex, "video/");
            if (track < 0) {
                failed = true;
                return;
            }
            ex.selectTrack(track);
            MediaFormat fmt = ex.getTrackFormat(track);
            dec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME));
            fmt.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible);
            dec.configure(fmt, null, null, 0);
            dec.start();

            VideoState st = new VideoState();
            playVideo(dec, ex, st, -1); // decode only the first picture into poster
            rewind(dec, ex);

            while (true) {
                int g = waitForStart();
                if (g < 0) return;
                playVideo(dec, ex, st, g);
                rewind(dec, ex);
                frame = null;
            }
        } catch (Throwable t) {
            failed = true; // this phone cannot play the video: the built-in animation is used instead
        } finally {
            try {
                if (dec != null) {
                    dec.stop();
                    dec.release();
                }
            } catch (Throwable ignored) {
            }
            try {
                if (ex != null) ex.release();
            } catch (Throwable ignored) {
            }
        }
    }

    private static void rewind(MediaCodec dec, MediaExtractor ex) {
        dec.flush();
        ex.seekTo(0, MediaExtractor.SEEK_TO_CLOSEST_SYNC);
    }

    /**
     * Plays the video in a loop while generation g is alive. With g = -1 it only decodes the first
     * picture (the poster) and returns.
     */
    private void playVideo(MediaCodec dec, MediaExtractor ex, VideoState st, int g) throws Exception {
        boolean posterOnly = g < 0;
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        boolean inputDone = false;
        long startNs = -1;
        long basePts = 0;
        long giveUp = System.nanoTime() + 4000000000L;

        while (posterOnly ? (poster == null && System.nanoTime() < giveUp && !released) : alive(g)) {
            if (!inputDone) {
                int ii = dec.dequeueInputBuffer(5000);
                if (ii >= 0) {
                    ByteBuffer ib = dec.getInputBuffer(ii);
                    int n = ex.readSampleData(ib, 0);
                    if (n < 0) {
                        dec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                        inputDone = true;
                    } else {
                        dec.queueInputBuffer(ii, 0, n, ex.getSampleTime(), 0);
                        ex.advance();
                    }
                }
            }
            int oi = dec.dequeueOutputBuffer(info, 5000);
            if (oi < 0) continue;
            boolean end = (info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;
            if (info.size > 0) {
                boolean show = true;
                if (!posterOnly) {
                    if (startNs < 0) {
                        startNs = System.nanoTime();
                        basePts = info.presentationTimeUs;
                    }
                    long waitMs = (startNs + (info.presentationTimeUs - basePts) * 1000L - System.nanoTime()) / 1000000L;
                    if (waitMs > 0) sleepMs(Math.min(waitMs, 200));
                    show = waitMs > -80; // skip the picture if we are far behind
                }
                if (show) {
                    Bitmap b = convert(dec.getOutputImage(oi), st, posterOnly);
                    if (b != null) {
                        if (posterOnly) poster = b;
                        else if (alive(g)) frame = b;
                    }
                }
            }
            dec.releaseOutputBuffer(oi, false);
            if (end) { // loop the video
                dec.flush();
                ex.seekTo(0, MediaExtractor.SEEK_TO_CLOSEST_SYNC);
                inputDone = false;
                startNs = -1;
                if (posterOnly) return;
            }
        }
    }

    /** Converts one decoded picture to a bitmap. The poster gets its own copy, so it is never overwritten. */
    private Bitmap convert(Image img, VideoState st, boolean forPoster) {
        if (img == null) return null;
        try {
            Rect cr = img.getCropRect();
            int w = cr.width();
            int h = cr.height();
            Image.Plane[] p = img.getPlanes();
            if (st.px == null || st.px.length != w * h) {
                st.px = new int[w * h];
                for (int i = 0; i < 3; i++) st.bmps[i] = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            }
            st.yb = fill(p[0].getBuffer(), st.yb);
            st.ub = fill(p[1].getBuffer(), st.ub);
            st.vb = fill(p[2].getBuffer(), st.vb);
            MediaTools.yuvToArgb(st.yb, p[0].getRowStride(), st.ub, p[1].getRowStride(), p[1].getPixelStride(),
                    st.vb, p[2].getRowStride(), p[2].getPixelStride(), w, h, st.px);
            Bitmap b;
            if (forPoster) {
                b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888); // the poster, kept separately
            } else {
                b = st.bmps[st.next];
                st.next = (st.next + 1) % 3;
            }
            b.setPixels(st.px, 0, w, 0, 0, w, h);
            return b;
        } finally {
            img.close();
        }
    }

    /** Copies a whole plane buffer into a (re-used) byte array. */
    private static byte[] fill(ByteBuffer b, byte[] reuse) {
        int n = b.remaining();
        if (reuse == null || reuse.length < n) reuse = new byte[n];
        b.get(reuse, 0, n);
        return reuse;
    }

    // ------------------------------------------------------------------ audio

    private void audioThread() {
        MediaExtractor ex = null;
        MediaCodec dec = null;
        try {
            String path = ensureFile();
            if (path == null) return;
            ex = new MediaExtractor();
            ex.setDataSource(path);
            int track = findTrack(ex, "audio/");
            if (track < 0) return;
            ex.selectTrack(track);
            MediaFormat fmt = ex.getTrackFormat(track);
            dec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME));
            dec.configure(fmt, null, null, 0);
            dec.start();

            while (true) {
                int g = waitForStart();
                if (g < 0) return;
                playAudio(dec, ex, fmt, g);
                dec.flush();
                ex.seekTo(0, MediaExtractor.SEEK_TO_CLOSEST_SYNC);
            }
        } catch (Throwable t) {
            // no sound from the BRB video on this phone
        } finally {
            try {
                if (dec != null) {
                    dec.stop();
                    dec.release();
                }
            } catch (Throwable ignored) {
            }
            try {
                if (ex != null) ex.release();
            } catch (Throwable ignored) {
            }
        }
    }

    private void playAudio(MediaCodec dec, MediaExtractor ex, MediaFormat fmt, int g) throws Exception {
        int srcRate = fmt.containsKey(MediaFormat.KEY_SAMPLE_RATE) ? fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE) : 44100;
        int ch = fmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT) ? fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT) : 2;
        MediaTools.Resampler rs = new MediaTools.Resampler(srcRate, AudioPipeline.SAMPLE_RATE);
        short[] in = new short[8192];
        short[] out = new short[rs.maxOut(8192) + 16];
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        boolean inputDone = false;
        long startNs = -1;
        long basePts = 0;

        while (alive(g)) {
            if (!inputDone) {
                int ii = dec.dequeueInputBuffer(5000);
                if (ii >= 0) {
                    ByteBuffer ib = dec.getInputBuffer(ii);
                    int n = ex.readSampleData(ib, 0);
                    if (n < 0) {
                        dec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                        inputDone = true;
                    } else {
                        dec.queueInputBuffer(ii, 0, n, ex.getSampleTime(), 0);
                        ex.advance();
                    }
                }
            }
            int oi = dec.dequeueOutputBuffer(info, 5000);
            if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                MediaFormat of = dec.getOutputFormat();
                if (of.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) ch = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                if (of.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                    int r = of.getInteger(MediaFormat.KEY_SAMPLE_RATE);
                    if (r != srcRate) {
                        srcRate = r;
                        rs = new MediaTools.Resampler(srcRate, AudioPipeline.SAMPLE_RATE);
                    }
                }
                continue;
            }
            if (oi < 0) continue;
            boolean end = (info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;
            if (info.size > 0) {
                if (startNs < 0) {
                    startNs = System.nanoTime();
                    basePts = info.presentationTimeUs;
                }
                // stay about 150 ms ahead of real time, no more (the ring is small)
                long waitMs = (startNs + (info.presentationTimeUs - basePts) * 1000L - System.nanoTime()) / 1000000L - 150;
                while (waitMs > 0 && alive(g)) {
                    sleepMs(Math.min(waitMs, 50));
                    waitMs -= 50;
                }
                if (alive(g)) {
                    ByteBuffer ob = dec.getOutputBuffer(oi);
                    ob.position(info.offset);
                    ob.limit(info.offset + info.size);
                    ShortBuffer sb = ob.order(ByteOrder.nativeOrder()).asShortBuffer();
                    int c = Math.max(1, ch);
                    int total = sb.remaining();
                    while (total > 0 && alive(g)) {
                        int take = Math.min(total, (in.length / c) * c);
                        sb.get(in, 0, take);
                        total -= take;
                        int n = rs.process(in, take / c, c, out);
                        musicRing.write(out, 0, n);
                    }
                }
            }
            dec.releaseOutputBuffer(oi, false);
            if (end) { // loop the song
                dec.flush();
                ex.seekTo(0, MediaExtractor.SEEK_TO_CLOSEST_SYNC);
                inputDone = false;
                startNs = -1;
            }
        }
    }
}
