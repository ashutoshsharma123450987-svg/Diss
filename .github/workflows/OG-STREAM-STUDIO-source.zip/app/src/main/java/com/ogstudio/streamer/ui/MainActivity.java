package com.ogstudio.streamer.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.ogstudio.streamer.R;
import com.ogstudio.streamer.engine.StreamService;
import com.ogstudio.streamer.model.Prefs;

import java.util.ArrayList;
import java.util.List;

/** Home screen: scene preview, status and the Go Live button. */
public class MainActivity extends Activity {
    private static final int REQ_PERM = 1;
    private static final int REQ_CAPTURE = 2;

    private Prefs prefs;
    private SceneView preview;
    private TextView status;
    private Button goButton;
    private SeekBar micBar;
    private SeekBar gameBar;
    private Button micMute;
    private Button gameMute;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private final Runnable poll = new Runnable() {
        @Override
        public void run() {
            refreshStatus();
            handler.postDelayed(this, 500);
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = new Prefs(this);
        buildUi();
    }

    private void buildUi() {
        LinearLayout root = Ui.column(this);
        root.setBackgroundColor(Ui.BG);
        int pad = Ui.dp(this, 16);
        root.setPadding(pad, pad, pad, pad);

        LinearLayout header = Ui.row(this);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.logo);
        header.addView(logo, new LinearLayout.LayoutParams(Ui.dp(this, 48), Ui.dp(this, 48)));
        LinearLayout titles = Ui.column(this);
        titles.addView(Ui.label(this, "OG STREAM STUDIO", 20, Ui.TEXT, true));
        titles.addView(Ui.label(this, "Create  •  Stream  •  Share", 12, Ui.MUTED, false));
        header.addView(titles, Ui.lpMargins(this, ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, 0, 12, 0, 0, 0));
        root.addView(header, Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0));

        FrameLayout previewBox = new FrameLayout(this);
        previewBox.setBackground(Ui.rounded(this, Ui.PANEL, 12));
        preview = new SceneView(this);
        preview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openEditor();
            }
        });
        previewBox.addView(preview, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.addView(previewBox, Ui.lpMargins(this, ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f, 0, 12, 0, 8));

        status = Ui.label(this, "", 14, Ui.MUTED, false);
        status.setGravity(Gravity.CENTER);
        root.addView(status, Ui.lpMargins(this, ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0, 0, 0, 8));

        volumeRow(root, true);
        volumeRow(root, false);

        LinearLayout row = Ui.row(this);
        Button edit =Ui.button(this, "Edit scene", Ui.PANEL, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openEditor();
            }
        });
        Button settings = Ui.button(this, "Settings", Ui.PANEL, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSettings();
            }
        });
        row.addView(edit, Ui.lpMargins(this, 0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f, 0, 0, 6, 0));
        row.addView(settings, Ui.lpMargins(this, 0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f, 6, 0, 0, 0));
        root.addView(row, Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0));

        goButton = Ui.button(this, "GO LIVE", Ui.ACCENT, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onGoLiveClicked();
            }
        });
        goButton.setTextSize(18);
        root.addView(goButton, Ui.lpMargins(this, ViewGroup.LayoutParams.MATCH_PARENT,
                Ui.dp(this, 56), 0, 0, 12, 0, 0));

        setContentView(root);
    }

    /** One volume line: label, slider (0 to 200 percent) and a Mute button. Works live while streaming. */
    private void volumeRow(LinearLayout root, final boolean isMic) {
        final TextView label = Ui.label(this, "", 14, Ui.TEXT, false);
        final SeekBar bar = new SeekBar(this);
        bar.setMax(200);
        final Button mute = Ui.button(this, "Mute", Ui.PANEL, null);
        mute.setMinimumHeight(Ui.dp(this, 36));
        mute.setTextSize(12);

        int initial = isMic ? prefs.micVolume() : prefs.gameVolume();
        bar.setProgress(initial);
        label.setText((isMic ? "Mic " : "Game ") + initial + "%");
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int progress, boolean fromUser) {
                label.setText((isMic ? "Mic " : "Game ") + progress + "%");
                if (isMic) StreamService.micGain = progress / 100f;
                else StreamService.gameGain = progress / 100f;
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
                if (isMic) prefs.setMicVolume(s.getProgress());
                else prefs.setGameVolume(s.getProgress());
            }
        });
        mute.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isMic) StreamService.micMuted = !StreamService.micMuted;
                else StreamService.gameMuted = !StreamService.gameMuted;
                updateMuteButtons();
            }
        });

        LinearLayout row = Ui.row(this);
        row.addView(label, Ui.lp(Ui.dp(this, 92), ViewGroup.LayoutParams.WRAP_CONTENT, 0));
        row.addView(bar, Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(mute, Ui.lpMargins(this, ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, 0, 8, 0, 0, 0));
        root.addView(row, Ui.lpMargins(this, ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0, 0, 0, 4));
        if (isMic) {
            micBar = bar;
            micMute = mute;
        } else {
            gameBar = bar;
            gameMute = mute;
        }
    }

    private void updateMuteButtons() {
        micMute.setText(StreamService.micMuted ? "Unmute" : "Mute");
        micMute.setBackground(Ui.rounded(this, StreamService.micMuted ? Ui.RED : Ui.PANEL, 10));
        gameMute.setText(StreamService.gameMuted ? "Unmute" : "Mute");
        gameMute.setBackground(Ui.rounded(this, StreamService.gameMuted ? Ui.RED : Ui.PANEL, 10));
    }

    /** Sliders only matter for the audio sources chosen in Settings. */
    private void updateVolumeEnabled() {
        int a = prefs.audio();
        boolean micOn = a == Prefs.AUDIO_MIC || a == Prefs.AUDIO_BOTH;
        boolean gameOn = a == Prefs.AUDIO_GAME || a == Prefs.AUDIO_BOTH;
        micBar.setEnabled(micOn);
        micMute.setEnabled(micOn);
        gameBar.setEnabled(gameOn);
        gameMute.setEnabled(gameOn);
    }

    @Override
    protected void onResume() {
        super.onResume();
        preview.setScene(prefs.loadScene(), false);
        if (!StreamService.isActive()) {
            // not streaming: show what is saved
            micBar.setProgress(prefs.micVolume());
            gameBar.setProgress(prefs.gameVolume());
        }
        updateMuteButtons();
        updateVolumeEnabled();
        handler.post(poll);
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(poll);
        super.onPause();
    }

    private void openEditor() {
        if (StreamService.isActive()) {
            Toast.makeText(this, "Live ke time scene edit nahi hota. Pehle stream band karo.", Toast.LENGTH_SHORT).show();
            return;
        }
        startActivity(new Intent(this, EditorActivity.class));
    }

    private void openSettings() {
        if (StreamService.isActive()) {
            Toast.makeText(this, "Live ke time settings nahi badalti. Pehle stream band karo.", Toast.LENGTH_SHORT).show();
            return;
        }
        startActivity(new Intent(this, SettingsActivity.class));
    }

    private void refreshStatus() {
        int st = StreamService.state;
        String msg = StreamService.message;
        if (st == StreamService.LIVE) {
            long secs = (SystemClock.elapsedRealtime() - StreamService.liveSinceMs) / 1000;
            String s = String.format("LIVE  %02d:%02d   %d fps   %d kbps   dropped %d",
                    secs / 60, secs % 60, StreamService.curFps, StreamService.curKbps, StreamService.droppedFrames);
            if (msg.length() > 0 && !"Live".equals(msg)) s += "\n" + msg;
            status.setText(s);
            status.setTextColor(0xFF66BB6A);
        } else if (st == StreamService.STARTING) {
            status.setText(msg);
            status.setTextColor(Ui.MUTED);
        } else if (st == StreamService.ERROR) {
            status.setText("Error: " + msg);
            status.setTextColor(0xFFEF5350);
        } else {
            status.setText(msg.length() > 0 ? msg : "Ready. Settings me URL aur Stream Key daalo, phir Go Live dabao.");
            status.setTextColor(Ui.MUTED);
        }
        boolean active = StreamService.isActive();
        goButton.setText(active ? "STOP" : "GO LIVE");
        goButton.setBackground(Ui.rounded(this, active ? Ui.RED : Ui.ACCENT, 10));
    }

    // ------------------------------------------------------------------ go live flow

    private void onGoLiveClicked() {
        if (StreamService.isActive()) {
            Intent stop = new Intent(this, StreamService.class);
            stop.setAction(StreamService.ACTION_STOP);
            startService(stop);
            return;
        }
        if (prefs.url().trim().length() == 0 || prefs.key().trim().length() == 0) {
            Toast.makeText(this, "Pehle Settings me Stream URL aur Stream Key daalo", Toast.LENGTH_LONG).show();
            openSettings();
            return;
        }
        List<String> need = new ArrayList<String>();
        if (prefs.audio() != Prefs.AUDIO_OFF && !granted("android.permission.RECORD_AUDIO")) {
            need.add("android.permission.RECORD_AUDIO");
        }
        if (Build.VERSION.SDK_INT >= 33 && !granted("android.permission.POST_NOTIFICATIONS")) {
            need.add("android.permission.POST_NOTIFICATIONS");
        }
        if (!need.isEmpty()) {
            requestPermissions(need.toArray(new String[0]), REQ_PERM);
            return;
        }
        confirmAndCapture();
    }

    private boolean granted(String p) {
        return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code != REQ_PERM) return;
        if (prefs.audio() != Prefs.AUDIO_OFF && !granted("android.permission.RECORD_AUDIO")) {
            Toast.makeText(this, "Mic permission nahi mili, stream bina awaaz ke chalegi", Toast.LENGTH_LONG).show();
        }
        confirmAndCapture();
    }

    private void confirmAndCapture() {
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Go Live se pehle")
                .setMessage("1. YouTube Studio me apna live page kholo aur wahan bhi Go Live dabao (agar auto-start off hai).\n\n"
                        + "2. Agle popup me \"Start now\" dabao.\n\n"
                        + "3. Phir apna game kholo. Stream band karne ke liye notification me Stop dabao.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Aage badho", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
                        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE);
                    }
                })
                .show();
    }

    @Override
    protected void onActivityResult(int req, int result, Intent data) {
        super.onActivityResult(req, result, data);
        if (req != REQ_CAPTURE) return;
        if (result != RESULT_OK || data == null) {
            Toast.makeText(this, "Screen sharing allow nahi hui", Toast.LENGTH_LONG).show();
            return;
        }
        Intent i = new Intent(this, StreamService.class);
        i.setAction(StreamService.ACTION_START);
        i.putExtra(StreamService.EXTRA_CODE, result);
        i.putExtra(StreamService.EXTRA_DATA, data);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
        else startService(i);
        Toast.makeText(this, "Stream shuru ho rahi hai. Ab apna game kholo.", Toast.LENGTH_LONG).show();
        moveTaskToBack(true);
    }
}
