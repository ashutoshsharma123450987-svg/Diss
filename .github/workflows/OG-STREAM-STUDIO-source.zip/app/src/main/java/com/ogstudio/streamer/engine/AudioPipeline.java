package com.ogstudio.streamer.engine;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioPlaybackCaptureConfiguration;
import android.media.AudioRecord;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaRecorder;
import android.media.projection.MediaProjection;
import android.os.Build;

import com.ogstudio.streamer.model.Prefs;
import com.ogstudio.streamer.rtmp.RtmpClient;

import java.io.IOException;
import java.nio.ByteBuffer;

/**
 * Records the microphone and / or the game audio (Android 10+), mixes them, encodes AAC
 * (mono, 44.1 kHz) and hands the frames to the RTMP client.
 */
final class AudioPipeline {
    static final int SAMPLE_RATE = 44100;
    static final int BITRATE = 96000;
    private static final int CHUNK = 1024; // samples per read, one AAC frame

    private final StreamConfig cfg;
    private final MediaProjection projection;
    private final RtmpClient rtmp;
    private final long t0Us;
    private final FailListener fail;

    private AudioRecord mic;
    private AudioRecord game;
    private MediaCodec encoder;
    private Thread captureThread;
    private Thread drainThread;
    private volatile boolean running;
    private boolean configSent;
    private long lastTsMs;
    /** Human readable note when a requested source could not be started. */
    String warning = "";

    AudioPipeline(StreamConfig cfg, MediaProjection projection, RtmpClient rtmp, long t0Us, FailListener fail) {
        this.cfg = cfg;
        this.projection = projection;
        this.rtmp = rtmp;
        this.t0Us = t0Us;
        this.fail = fail;
    }

    /** Returns false if no audio source could be opened (stream continues without sound). */
    boolean start() throws IOException {
        int bufBytes = Math.max(AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT) * 2, 16384);

        if (cfg.audio == Prefs.AUDIO_MIC || cfg.audio == Prefs.AUDIO_BOTH) {
            mic = openMic(bufBytes);
            if (mic == null) warning = "Mic start nahi hua. ";
        }
        if (cfg.audio == Prefs.AUDIO_GAME || cfg.audio == Prefs.AUDIO_BOTH) {
            if (Build.VERSION.SDK_INT >= 29 && projection != null) {
                game = openGame(bufBytes);
                if (game == null) warning += "Game audio start nahi hui. ";
            } else {
                warning += "Game audio ke liye Android 10 ya upar chahiye. ";
            }
        }
        if (mic == null && game == null) return false;

        MediaFormat f = MediaFormat.createAudioFormat("audio/mp4a-latm", SAMPLE_RATE, 1);
        f.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC);
        f.setInteger(MediaFormat.KEY_BIT_RATE, BITRATE);
        f.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384);
        try {
            encoder = MediaCodec.createEncoderByType("audio/mp4a-latm");
            encoder.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            encoder.start();
        } catch (Exception e) {
            releaseRecorders();
            throw new IOException("Audio encoder start nahi hua: " + e.getMessage());
        }

        running = true;
        drainThread = new Thread(new Runnable() {
            @Override
            public void run() {
                drainLoop();
            }
        }, "og-audio-drain");
        captureThread = new Thread(new Runnable() {
            @Override
            public void run() {
                captureLoop();
            }
        }, "og-audio-capture");
        drainThread.start();
        captureThread.start();
        return true;
    }

    void stop() {
        running = false;
        join(captureThread);
        join(drainThread);
        releaseRecorders();
        try {
            if (encoder != null) {
                encoder.stop();
                encoder.release();
            }
        } catch (Exception ignored) {
        }
    }

    private static void join(Thread t) {
        if (t == null || t == Thread.currentThread()) return;
        try {
            t.join(1500);
        } catch (InterruptedException ignored) {
        }
    }

    private void releaseRecorders() {
        for (AudioRecord r : new AudioRecord[]{mic, game}) {
            if (r == null) continue;
            try {
                r.stop();
            } catch (Exception ignored) {
            }
            try {
                r.release();
            } catch (Exception ignored) {
            }
        }
        mic = null;
        game = null;
    }

    private AudioRecord openMic(int bufBytes) {
        try {
            AudioRecord r = new AudioRecord(MediaRecorder.AudioSource.MIC, SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufBytes);
            if (r.getState() != AudioRecord.STATE_INITIALIZED) {
                r.release();
                return null;
            }
            r.startRecording();
            return r;
        } catch (Exception e) {
            return null;
        }
    }

    private AudioRecord openGame(int bufBytes) {
        try {
            AudioPlaybackCaptureConfiguration pc = new AudioPlaybackCaptureConfiguration.Builder(projection)
                    .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                    .addMatchingUsage(AudioAttributes.USAGE_GAME)
                    .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                    .build();
            AudioFormat fmt = new AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SAMPLE_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                    .build();
            AudioRecord r = new AudioRecord.Builder()
                    .setAudioPlaybackCaptureConfig(pc)
                    .setAudioFormat(fmt)
                    .setBufferSizeInBytes(bufBytes)
                    .build();
            if (r.getState() != AudioRecord.STATE_INITIALIZED) {
                r.release();
                return null;
            }
            r.startRecording();
            return r;
        } catch (Throwable e) {
            return null;
        }
    }

    private static int readFull(AudioRecord r, short[] buf, int n) {
        int got = 0;
        while (got < n) {
            int k = r.read(buf, got, n - got);
            if (k <= 0) break;
            got += k;
        }
        return got;
    }

    private void captureLoop() {
        short[] micBuf = new short[CHUNK];
        short[] gameBuf = new short[CHUNK];
        byte[] pcm = new byte[CHUNK * 2];
        long samples = 0;
        long baseUs = -1;
        while (running) {
            // read the live volume once per chunk so slider changes apply at once
            float micGain = StreamService.micMuted ? 0f : StreamService.micGain;
            float gameGain = StreamService.gameMuted ? 0f : StreamService.gameGain;
            int nm = mic != null ? readFull(mic, micBuf, CHUNK) : 0;
            int ng = game != null ? readFull(game, gameBuf, CHUNK) : 0;
            if (mic != null && nm == 0 && game == null) {
                fail.onFail("Mic se awaaz nahi mil rahi");
                return;
            }
            if (baseUs < 0) baseUs = System.nanoTime() / 1000L - CHUNK * 1000000L / SAMPLE_RATE;
            for (int i = 0; i < CHUNK; i++) {
                float v = 0f;
                if (i < nm) v += micBuf[i] * micGain;
                if (i < ng) v += gameBuf[i] * gameGain;
                int s = (int) v;
                if (s > 32767) s = 32767;
                if (s < -32768) s = -32768;
                pcm[i * 2] = (byte) (s & 0xff);
                pcm[i * 2 + 1] = (byte) ((s >> 8) & 0xff);
            }
            long ptsUs = baseUs + samples * 1000000L / SAMPLE_RATE;
            samples += CHUNK;
            try {
                int idx = encoder.dequeueInputBuffer(20000);
                if (idx >= 0) {
                    ByteBuffer in = encoder.getInputBuffer(idx);
                    in.clear();
                    in.put(pcm, 0, pcm.length);
                    encoder.queueInputBuffer(idx, 0, pcm.length, ptsUs, 0);
                }
            } catch (Exception e) {
                if (running) fail.onFail("Audio encoder error: " + e.getMessage());
                return;
            }
        }
    }

    private void drainLoop() {
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        while (running) {
            int idx;
            try {
                idx = encoder.dequeueOutputBuffer(info, 20000);
            } catch (Exception e) {
                if (running) fail.onFail("Audio encoder error: " + e.getMessage());
                return;
            }
            if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                try {
                    ByteBuffer csd = encoder.getOutputFormat().getByteBuffer("csd-0");
                    if (csd != null && !configSent) {
                        byte[] asc = new byte[csd.remaining()];
                        csd.get(asc);
                        rtmp.sendAudioConfig(asc);
                        configSent = true;
                    }
                } catch (Exception ignored) {
                }
                continue;
            }
            if (idx < 0) continue;
            try {
                ByteBuffer out = encoder.getOutputBuffer(idx);
                if (out != null && info.size > 0) {
                    byte[] data = new byte[info.size];
                    out.position(info.offset);
                    out.limit(info.offset + info.size);
                    out.get(data);
                    if ((info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                        if (!configSent) {
                            rtmp.sendAudioConfig(data);
                            configSent = true;
                        }
                    } else {
                        if (!configSent) {
                            // AAC-LC, 44100 Hz, mono
                            rtmp.sendAudioConfig(new byte[]{0x12, 0x08});
                            configSent = true;
                        }
                        long ts = Math.max(0, (info.presentationTimeUs - t0Us) / 1000L);
                        if (ts < lastTsMs) ts = lastTsMs;
                        lastTsMs = ts;
                        rtmp.sendAudioFrame(data, 0, data.length, ts);
                    }
                }
            } finally {
                try {
                    encoder.releaseOutputBuffer(idx, false);
                } catch (Exception ignored) {
                }
            }
        }
    }
}
