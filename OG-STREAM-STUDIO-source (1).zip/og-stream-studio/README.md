# OG STREAM STUDIO

Apne use ke liye halka Android streaming app. Phone ki screen (game) ko seedha YouTube par live karta hai,
upar text aur logo laga sakte ho. Koi bahari library nahi hai, isliye APK chhota aur halka hai.

## APK kaise banayein (GitHub se)

1. GitHub par naya (private) repository banao.
2. Is folder ki saari files us repo me upload karo (`.github` folder samet).
3. Repo me **Actions** tab kholo. "Build APK" apne aap chalega (nahi chale to "Run workflow" dabao).
4. 3-5 minute baad run ke andar **Artifacts** me `OG-STREAM-STUDIO-apk` milega. Download karke zip kholo,
   andar `app-debug.apk` hai. Use phone me install karo ("Unknown source" allow karna padega).
5. Agar build fail ho to us run ka error text copy karke bhej do, main theek kar dunga.

## Use kaise karein

1. **Settings** me daalo: Stream URL (`rtmp://a.rtmp.youtube.com/live2`) aur Stream Key (YouTube Studio > Go Live).
2. Low-end phone ke liye 480p, 24 fps, 1200 kbps se shuru karo.
3. **Edit scene** me screen box ko canvas me kahin bhi rakho, bada-chhota karo. Text aur Image jodo.
   Canvas se bahar gaya hissa stream me nahi dikhta.
4. **GO LIVE** dabao. YouTube Studio me bhi Go Live dabao (agar auto-start off hai). "Start now" dabao.
   Phir apna game kholo. Band karne ke liye notification me **Stop**.

## Volume

Home screen par Mic aur Game ke slider (0 se 200%) aur Mute button hain. Stream chalte waqt bhi kaam karte hain.

Live chat dikhana, Screensaver, local recording. Ye baad me jod sakte hain.

## Agar video kaali dikhe

Settings me "Software drawing" ON karo.

## Mic aur Free Fire (zaroori)
Agar stream ke dauran screen par "OG STREAM STUDIO cannot record now as Free Fire MAX is recording" aaye, to
ye Android ka niyam hai: jab game apna voice chat/mic chalata hai to dusre app ka mic band kar diya jaata hai.
Isse bachne ke liye Free Fire me voice chat / mic band rakho, ya Settings > Awaaz > "Sirf game audio" chuno.
Home screen par "Mic band" ki chetavni dikhegi jab mic ko sirf khamoshi mil rahi ho.

## Teammate ki awaaz
App ab game ke saath teammate ki voice chat bhi capture karne ki koshish karta hai. Ye tabhi aati hai jab game
apni voice chat ko capture hone deta hai. Aapki apni awaaz (mic) tab hi aati hai jab game mic na le rahi ho.

## Web source (overlay / animation)
Editor me "+ Web" dabao, link daalo. Ye page stream me dikhta hai (editor me hara box dikhta hai).
Halka rakha gaya hai: chhota size (max 640 px) aur 8 fps. Transparent background wale overlays achhe se blend hote hain.
Ek ya do se zyada Web source mat rakho, low-end phone par load badhta hai.

## Quality: 720p 60 / 1080p
Settings me Quality me 1080p aur FPS me 60 aa gaye. Ye bhaari hain. Agar phone frames nahi bana paata, to app fps
apne aap ghata deta hai (aur halka hone par dheere dheere wapas badhata hai). Pehle 720p 30 se test karo.

## Floating controls
Settings > "Floating controls" ON karo aur 'Display over other apps' permission do. Stream chalne par game ke upar
LIVE bubble aata hai. Bubble dabao: Mic ON/OFF, Game ON/OFF, volume sliders, STOP (do baar dabana padta hai).
Bubble ko khinchkar kahin bhi rakh sakte ho. Notification me bhi Mic mute / Game mute / Stop buttons hain.
Dhyan: Android overlay ko screen capture me le leta hai, isliye bubble stream me dikh sakta hai.
