package com.ogstudio.streamer.engine;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioPlaybackCaptureConfiguration;
import android.media.AudioRecord;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaRecorder;
import android.media.audiofx.AcousticEchoCanceler;
import android.media.audiofx.NoiseSuppressor;
import android.media.projection.MediaProjection;
import android.os.Build;

import com.ogstudio.streamer.model.Prefs;
import com.ogstudio.streamer.rtmp.RtmpClient;

import java.io.IOException;
import java.nio.ByteBuffer;

/**
 * Records the microphone and / or the game audio (Android 10+), mixes them, encodes AAC
 * (mono, 44.1 kHz) and hands the frames to the RTMP client.
 *
 * Every source is read by its own thread into a ring buffer; a separate mixer thread takes
 * audio from the rings on a steady clock. This keeps mic and game audio in sync with the video
 * even when one of the sources stalls.
 */
final class AudioPipeline {
    /** 48 kHz is what Android mixes at internally, so no poor-quality resampling happens. */
    static final int SAMPLE_RATE = 48000;
    static final int BITRATE = 128000;
    /** Everything inside the pipeline is stereo, interleaved (left, right, left, right ...). */
    private static final int CH = 2;
    private static final int CHUNK = 1024 * CH; // shorts per AAC frame (1024 stereo frames)
    private static final int READ = 512 * CH;   // shorts per AudioRecord read

    private final StreamConfig cfg;
    private final MediaProjection projection;
    private final RtmpClient rtmp;
    private final long t0Us;
    private final FailListener fail;

    private volatile AudioRecord mic;
    private volatile AudioRecord game;
    private PcmRing micRing;
    private PcmRing gameRing;
    private AudioMixer mixer;
    private AcousticEchoCanceler aec;
    private NoiseSuppressor ns;
    private MediaCodec encoder;
    private Thread micThread;
    private Thread gameThread;
    private Thread mixThread;
    private Thread drainThread;
    private volatile boolean running;
    private boolean configSent;
    private long lastTsMs;
    private int bufBytes;
    /** Human readable note when a requested source could not be started. */
    String warning = "";

    AudioPipeline(StreamConfig cfg, MediaProjection projection, RtmpClient rtmp, long t0Us, FailListener fail) {
        this.cfg = cfg;
        this.projection = projection;
        this.rtmp = rtmp;
        this.t0Us = t0Us;
        this.fail = fail;
    }

    /** Returns false if no audio source could be opened (stream continues without sound). */
    boolean start() throws IOException {
        StreamService.micSilenced = false;
        bufBytes = Math.max(AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_STEREO,
                AudioFormat.ENCODING_PCM_16BIT) * 2, 32768);

        if (cfg.audio == Prefs.AUDIO_MIC || cfg.audio == Prefs.AUDIO_BOTH) {
            mic = openMic(bufBytes);
            if (mic == null) warning = "Mic start nahi hua. ";
        }
        if (cfg.audio == Prefs.AUDIO_GAME || cfg.audio == Prefs.AUDIO_BOTH) {
            if (Build.VERSION.SDK_INT >= 29 && projection != null) {
                game = openGame(bufBytes);
                if (game == null) warning += "Game audio start nahi hui. ";
            } else {
                warning += "Game audio ke liye Android 10 ya upar chahiye. ";
            }
        }
        if (mic == null && game == null) return false;

        MediaFormat f = MediaFormat.createAudioFormat("audio/mp4a-latm", SAMPLE_RATE, CH);
        f.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC);
        f.setInteger(MediaFormat.KEY_BIT_RATE, BITRATE);
        f.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 32768);
        try {
            encoder = MediaCodec.createEncoderByType("audio/mp4a-latm");
            encoder.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            encoder.start();
        } catch (Exception e) {
            releaseRecorders();
            throw new IOException("Audio encoder start nahi hua: " + e.getMessage());
        }

        micRing = mic != null ? new PcmRing(SAMPLE_RATE * CH) : null;
        gameRing = game != null ? new PcmRing(SAMPLE_RATE * CH) : null;
        mixer = new AudioMixer(micRing, gameRing, CHUNK, SAMPLE_RATE * CH, new AudioMixer.Gains() {
            @Override
            public float mic() {
                return StreamService.micMuted ? 0f : StreamService.micGain;
            }

            @Override
            public float game() {
                return StreamService.gameMuted ? 0f : StreamService.gameGain;
            }
        }, new AudioMixer.Sink() {
            @Override
            public void onChunk(byte[] pcm, long ptsUs) {
                feedEncoder(pcm, ptsUs);
                StreamService.micSilenced = mixer != null && mixer.micSilent;
            }
        });

        running = true;
        drainThread = new Thread(new Runnable() {
            @Override
            public void run() {
                drainLoop();
            }
        }, "og-audio-drain");
        mixThread = new Thread(mixer, "og-audio-mix");
        if (mic != null) micThread = reader(true);
        if (game != null) gameThread = reader(false);
        drainThread.start();
        if (micThread != null) micThread.start();
        if (gameThread != null) gameThread.start();
        mixThread.start();
        return true;
    }

    private Thread reader(final boolean isMic) {
        return new Thread(new Runnable() {
            @Override
            public void run() {
                readLoop(isMic);
            }
        }, isMic ? "og-audio-mic" : "og-audio-game");
    }

    void stop() {
        running = false;
        if (mixer != null) mixer.stop();
        join(mixThread);
        join(micThread);
        join(gameThread);
        join(drainThread);
        releaseRecorders();
        try {
            if (encoder != null) {
                encoder.stop();
                encoder.release();
            }
        } catch (Exception ignored) {
        }
        StreamService.micSilenced = false;
    }

    private static void join(Thread t) {
        if (t == null || t == Thread.currentThread()) return;
        try {
            t.join(1500);
        } catch (InterruptedException ignored) {
        }
    }

    private void releaseRecorders() {
        for (AudioRecord r : new AudioRecord[]{mic, game}) {
            closeRecord(r);
        }
        releaseEffects();
        mic = null;
        game = null;
    }

    private void releaseEffects() {
        try {
            if (aec != null) aec.release();
        } catch (Exception ignored) {
        }
        try {
            if (ns != null) ns.release();
        } catch (Exception ignored) {
        }
        aec = null;
        ns = null;
    }

    private static void closeRecord(AudioRecord r) {
        if (r == null) return;
        try {
            r.stop();
        } catch (Exception ignored) {
        }
        try {
            r.release();
        } catch (Exception ignored) {
        }
    }

    private AudioRecord openMic(int bufBytes) {
        try {
            int src = cfg.micClean ? MediaRecorder.AudioSource.VOICE_COMMUNICATION : MediaRecorder.AudioSource.MIC;
            AudioRecord r = new AudioRecord(src, SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufBytes);
            if (r.getState() != AudioRecord.STATE_INITIALIZED) {
                r.release();
                return null;
            }
            if (cfg.micClean) {
                releaseEffects();
                try {
                    if (AcousticEchoCanceler.isAvailable()) {
                        aec = AcousticEchoCanceler.create(r.getAudioSessionId());
                        if (aec != null) aec.setEnabled(true);
                    }
                    if (NoiseSuppressor.isAvailable()) {
                        ns = NoiseSuppressor.create(r.getAudioSessionId());
                        if (ns != null) ns.setEnabled(true);
                    }
                } catch (Throwable ignored) {
                }
            }
            r.startRecording();
            return r;
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Captures everything the phone plays: game sound and, if the game allows it, the teammates'
     * voice chat (which many games play as "voice communication"). If the phone refuses the wider
     * list, the normal list (media, game, unknown) is used.
     */
    private AudioRecord openGame(int bufBytes) {
        AudioRecord r = openGame(bufBytes, true);
        if (r == null) r = openGame(bufBytes, false);
        return r;
    }

    private AudioRecord openGame(int bufBytes, boolean withVoice) {
        try {
            AudioPlaybackCaptureConfiguration.Builder pb = new AudioPlaybackCaptureConfiguration.Builder(projection)
                    .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                    .addMatchingUsage(AudioAttributes.USAGE_GAME)
                    .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN);
            if (withVoice) pb.addMatchingUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION);
            AudioPlaybackCaptureConfiguration pc = pb.build();
            AudioFormat fmt = new AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SAMPLE_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                    .build();
            AudioRecord r = new AudioRecord.Builder()
                    .setAudioPlaybackCaptureConfig(pc)
                    .setAudioFormat(fmt)
                    .setBufferSizeInBytes(bufBytes)
                    .build();
            if (r.getState() != AudioRecord.STATE_INITIALIZED) {
                r.release();
                return null;
            }
            r.startRecording();
            return r;
        } catch (Throwable e) {
            return null;
        }
    }

    /** Reads one source forever into its ring. If the source breaks, it is reopened with a growing pause. */
    private void readLoop(boolean isMic) {
        short[] buf = new short[READ];
        short[] st = new short[READ];
        PcmRing ring = isMic ? micRing : gameRing;
        long backoffMs = 200;
        while (running) {
            AudioRecord r = isMic ? mic : game;
            int n = -1;
            if (r != null) {
                try {
                    n = isMic ? r.read(buf, 0, READ / CH) : r.read(buf, 0, READ);
                } catch (Exception e) {
                    n = -1;
                }
            }
            if (n > 0) {
                if (isMic) {
                    // mic is mono: copy it to left and right
                    for (int i = 0; i < n; i++) {
                        st[i * 2] = buf[i];
                        st[i * 2 + 1] = buf[i];
                    }
                    ring.write(st, 0, n * 2);
                } else {
                    ring.write(buf, 0, n & ~1);
                }
                backoffMs = 200;
                continue;
            }
            // read failed: wait, then try to open the source again
            try {
                Thread.sleep(backoffMs);
            } catch (InterruptedException e) {
                return;
            }
            if (!running) return;
            backoffMs = Math.min(2000, backoffMs * 2);
            closeRecord(r);
            AudioRecord fresh = isMic ? openMic(bufBytes) : openGame(bufBytes);
            if (isMic) mic = fresh;
            else game = fresh;
        }
    }

    private void feedEncoder(byte[] pcm, long ptsUs) {
        try {
            int idx = encoder.dequeueInputBuffer(20000);
            if (idx >= 0) {
                ByteBuffer in = encoder.getInputBuffer(idx);
                in.clear();
                in.put(pcm, 0, pcm.length);
                encoder.queueInputBuffer(idx, 0, pcm.length, ptsUs, 0);
            }
        } catch (Exception e) {
            if (running) fail.onFail("Audio encoder error: " + e.getMessage());
        }
    }

    private void drainLoop() {
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        while (running) {
            int idx;
            try {
                idx = encoder.dequeueOutputBuffer(info, 20000);
            } catch (Exception e) {
                if (running) fail.onFail("Audio encoder error: " + e.getMessage());
                return;
            }
            if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                try {
                    ByteBuffer csd = encoder.getOutputFormat().getByteBuffer("csd-0");
                    if (csd != null && !configSent) {
                        byte[] asc = new byte[csd.remaining()];
                        csd.get(asc);
                        rtmp.sendAudioConfig(asc);
                        configSent = true;
                    }
                } catch (Exception ignored) {
                }
                continue;
            }
            if (idx < 0) continue;
            try {
                ByteBuffer out = encoder.getOutputBuffer(idx);
                if (out != null && info.size > 0) {
                    byte[] data = new byte[info.size];
                    out.position(info.offset);
                    out.limit(info.offset + info.size);
                    out.get(data);
                    if ((info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                        if (!configSent) {
                            rtmp.sendAudioConfig(data);
                            configSent = true;
                        }
                    } else {
                        if (!configSent) {
                            // AAC-LC, 48000 Hz, stereo
                            rtmp.sendAudioConfig(new byte[]{0x11, (byte) 0x90});
                            configSent = true;
                        }
                        long ts = Math.max(0, (info.presentationTimeUs - t0Us) / 1000L);
                        if (ts < lastTsMs) ts = lastTsMs;
                        lastTsMs = ts;
                        rtmp.sendAudioFrame(data, 0, data.length, ts);
                    }
                }
            } finally {
                try {
                    encoder.releaseOutputBuffer(idx, false);
                } catch (Exception ignored) {
                }
            }
        }
    }
}
