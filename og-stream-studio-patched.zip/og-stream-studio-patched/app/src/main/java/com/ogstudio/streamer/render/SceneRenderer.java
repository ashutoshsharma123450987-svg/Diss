package com.ogstudio.streamer.render;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;

import com.ogstudio.streamer.model.Scene;
import com.ogstudio.streamer.model.Source;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

/**
 * Draws a scene onto any Canvas in logical canvas pixels. The editor and the live stream
 * use the same code, so what you see in the editor is what viewers get.
 * Not thread safe: use one instance per thread.
 */
public final class SceneRenderer {
    private final Context ctx;
    private final Map<String, Bitmap> images = new HashMap<String, Bitmap>();
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bmpPaint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
    private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Rect src = new Rect();
    private final RectF dst = new RectF();

    /** Supplies the latest picture of a web page source (null = not ready). */
    public interface WebProvider {
        Bitmap frame(Source s);
    }

    private WebProvider webProvider;

    // BRB / "STREAMING SOON" animation state
    private boolean brb;
    private long brbMs;
    private Bitmap brbBitmap;
    private boolean brbVideoFailed;
    private long brbOnMs;
    private Shader brbShader;
    private float brbShaderH = -1f;
    private final Paint brbPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF brbRect = new RectF();

    /** The BRB video's current picture (null = use the built-in animation). */
    public void setBrbBitmap(Bitmap b, boolean videoFailed) {
        brbBitmap = b;
        brbVideoFailed = videoFailed;
    }

    /** Turns the "streaming soon" animation on or off; ms is any steadily growing clock. */
    public void setBrb(boolean on, long ms) {
        if (on && !brb) brbOnMs = ms;
        brb = on;
        brbMs = ms;
    }

    public void setWebProvider(WebProvider p) {
        webProvider = p;
    }

    public SceneRenderer(Context c) {
        ctx = c.getApplicationContext();
    }

    public void release() {
        images.clear();
    }

    public Bitmap image(String file) {
        if (file == null || file.length() == 0) return null;
        Bitmap b = images.get(file);
        if (b == null) {
            b = BitmapFactory.decodeFile(new File(ctx.getFilesDir(), file).getPath());
            if (b != null) images.put(file, b);
        }
        return b;
    }

    public void forget(String file) {
        images.remove(file);
    }

    /** Bounds of a source in logical canvas pixels. */
    public RectF bounds(Source s) {
        switch (s.type) {
            case Source.TEXT: {
                prepareText(s);
                String[] lines = lines(s);
                float maxW = 1f;
                for (String l : lines) maxW = Math.max(maxW, textPaint.measureText(l));
                Paint.FontMetrics fm = textPaint.getFontMetrics();
                float lh = fm.descent - fm.ascent;
                float pad = s.box ? s.w * 0.3f : 0f;
                return new RectF(s.x, s.y, s.x + maxW + pad * 2, s.y + lh * lines.length + pad * 2);
            }
            case Source.IMAGE: {
                float ar = s.ar;
                Bitmap b = image(s.imageFile);
                if (b != null && b.getHeight() > 0) ar = b.getWidth() / (float) b.getHeight();
                return new RectF(s.x, s.y, s.x + s.w, s.y + s.w / ar);
            }
            default:
                return new RectF(s.x, s.y, s.x + s.w, s.y + s.w / s.ar);
        }
    }

    private static String[] lines(Source s) {
        String t = s.text == null || s.text.length() == 0 ? " " : s.text;
        return t.split("\n", -1);
    }

    private void prepareText(Source s) {
        textPaint.setTextSize(Math.max(4f, s.w));
        textPaint.setTypeface(Typeface.create(Typeface.DEFAULT, s.bold ? Typeface.BOLD : Typeface.NORMAL));
    }

    /**
     * Draws all layers.
     *
     * @param frame   latest screen capture or null (a placeholder is drawn then)
     * @param frameW  visible width of the frame inside the bitmap
     * @param frameH  visible height of the frame inside the bitmap
     */
    public void drawScene(Canvas c, Scene sc, Bitmap frame, int frameW, int frameH) {
        drawScene(c, sc, frame, frameW, frameH, null);
    }

    /** Same, but {@code crop} is the part of the frame that shows the screen (null = whole frame). */
    public void drawScene(Canvas c, Scene sc, Bitmap frame, int frameW, int frameH, Rect crop) {
        for (Source s : sc.sources) {
            switch (s.type) {
                case Source.SCREEN:
                    drawScreen(c, s, frame, frameW, frameH, crop);
                    break;
                case Source.TEXT:
                    drawText(c, s);
                    break;
                case Source.WEB:
                    drawWeb(c, s);
                    break;
                default:
                    drawImage(c, s);
                    break;
            }
        }
    }

    private void drawScreen(Canvas c, Source s, Bitmap frame, int fw, int fh, Rect crop) {
        RectF r = bounds(s);
        if (brb) {
            drawBrb(c, r);
            return;
        }
        if (frame != null && fw > 0 && fh > 0) {
            boolean useCrop = crop != null && crop.width() > 0 && crop.height() > 0;
            int sw = useCrop ? crop.width() : fw;
            int sh = useCrop ? crop.height() : fh;
            float far = sw / (float) sh;
            float dw;
            float dh;
            if (r.width() / r.height() > far) {
                dh = r.height();
                dw = dh * far;
            } else {
                dw = r.width();
                dh = dw / far;
            }
            dst.set(r.centerX() - dw / 2f, r.centerY() - dh / 2f, r.centerX() + dw / 2f, r.centerY() + dh / 2f);
            if (useCrop) src.set(crop);
            else src.set(0, 0, fw, fh);
            c.drawBitmap(frame, src, dst, bmpPaint);
        } else {
            fillPaint.setStyle(Paint.Style.FILL);
            fillPaint.setColor(0xFF12306B);
            c.drawRect(r, fillPaint);
            fillPaint.setColor(0xFFFFFFFF);
            fillPaint.setTextAlign(Paint.Align.CENTER);
            fillPaint.setTextSize(Math.max(12f, Math.min(r.height() / 8f, 44f)));
            c.drawText("Screen capture", r.centerX(), r.centerY() + fillPaint.getTextSize() / 3f, fillPaint);
            fillPaint.setTextAlign(Paint.Align.LEFT);
        }
    }

    /** Smooth looping animation shown in the screen box while the game is switched off. */
    private void drawBrb(Canvas c, RectF r) {
        Bitmap vb = brbBitmap;
        if (vb != null) {
            // the video fills the box (centered, the extra edge is cut off)
            float bw = vb.getWidth();
            float bh = vb.getHeight();
            float boxAr = r.width() / r.height();
            float vAr = bw / bh;
            if (boxAr > vAr) {
                float sh = bw / boxAr;
                src.set(0, (int) ((bh - sh) / 2f), (int) bw, (int) ((bh + sh) / 2f));
            } else {
                float sw = bh * boxAr;
                src.set((int) ((bw - sw) / 2f), 0, (int) ((bw + sw) / 2f), (int) bh);
            }
            c.drawBitmap(vb, src, r, bmpPaint);
            return;
        }
        // The video is still starting up: show a plain dark background (the video begins dark too) so the
        // built-in animation never flashes first. It is used only if the video really cannot play.
        if (!brbVideoFailed && brbMs - brbOnMs < 6000) {
            fillPaint.setStyle(Paint.Style.FILL);
            fillPaint.setColor(0xFF0A0C0E);
            c.drawRect(r, fillPaint);
            return;
        }
        float w = r.width();
        float h = r.height();
        float t = (brbMs % 600000L) / 1000f;
        float base = Math.min(w, h);
        int save = c.save();
        c.clipRect(r);
        c.translate(r.left, r.top);

        if (brbShader == null || brbShaderH != h) {
            brbShader = new LinearGradient(0, 0, 0, h, 0xFF070B24, 0xFF3B1573, Shader.TileMode.CLAMP);
            brbShaderH = h;
        }
        brbPaint.setStyle(Paint.Style.FILL);
        brbPaint.setShader(brbShader);
        c.drawRect(0, 0, w, h, brbPaint);
        brbPaint.setShader(null);

        float cx = w / 2f;
        float cy = h * 0.40f;

        // drifting glowing dots
        brbPaint.setStyle(Paint.Style.FILL);
        for (int i = 0; i < 9; i++) {
            float fx = (i * 0.37f + 0.11f) % 1f;
            float p = (t * (0.05f + 0.01f * (i % 3)) + i * 0.13f) % 1f;
            float x = w * (0.06f + 0.88f * fx) + (float) Math.sin(t * 0.8f + i) * base * 0.02f;
            float y = h * (1.05f - 1.1f * p);
            float tw = 0.5f + 0.5f * (float) Math.sin(t * 2f + i * 1.7f);
            brbPaint.setColor(((int) (40 + 90 * tw) << 24) | 0x00B9A4FF);
            c.drawCircle(x, y, base * (0.008f + 0.006f * (i % 3)), brbPaint);
        }

        // ripples
        brbPaint.setStyle(Paint.Style.STROKE);
        brbPaint.setStrokeWidth(Math.max(1.5f, base * 0.008f));
        for (int i = 0; i < 3; i++) {
            float p = (t * 0.30f + i / 3f) % 1f;
            float rad = base * (0.10f + 0.34f * p);
            brbPaint.setColor(((int) (120 * (1f - p)) << 24) | 0x0080C8FF);
            c.drawCircle(cx, cy, rad, brbPaint);
        }

        // spinner
        float sr = base * 0.085f;
        brbRect.set(cx - sr, cy - sr, cx + sr, cy + sr);
        brbPaint.setStrokeCap(Paint.Cap.ROUND);
        brbPaint.setStrokeWidth(Math.max(2f, base * 0.022f));
        brbPaint.setColor(0x40FFFFFF);
        c.drawCircle(cx, cy, sr, brbPaint);
        brbPaint.setColor(0xFFFF7A1A);
        float sweep = 70f + 50f * (float) Math.sin(t * 2.2f);
        c.drawArc(brbRect, (t * 240f) % 360f, sweep, false, brbPaint);
        brbPaint.setStrokeCap(Paint.Cap.BUTT);

        // title, fitted to the box and gently pulsing
        brbPaint.setStyle(Paint.Style.FILL);
        brbPaint.setTextAlign(Paint.Align.CENTER);
        brbPaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        String title = "STREAMING SOON";
        brbPaint.setTextSize(100f);
        float fit = (w * 0.86f) / Math.max(1f, brbPaint.measureText(title));
        float size = Math.min(100f * fit, h * 0.16f);
        float pulse = 1f + 0.03f * (float) Math.sin(t * 2.4f);
        brbPaint.setTextSize(size * pulse);
        float ty = cy + sr + base * 0.17f;
        brbPaint.setShadowLayer(size * 0.35f, 0, 0, 0xCC8E5BFF);
        brbPaint.setColor(((int) (225 + 30 * Math.sin(t * 2.4f)) << 24) | 0x00FFFFFF);
        c.drawText(title, cx, ty, brbPaint);
        brbPaint.clearShadowLayer();

        // subtitle with animated dots
        int dots = 1 + (int) (t * 1.8f) % 3;
        String sub = "Thodi der me wapas aate hain";
        for (int i = 0; i < dots; i++) sub += ".";
        brbPaint.setTypeface(Typeface.DEFAULT);
        brbPaint.setTextSize(size * 0.42f);
        brbPaint.setColor(0xCCCFD8FF);
        c.drawText(sub, cx, ty + size * 0.75f, brbPaint);

        brbPaint.setTextAlign(Paint.Align.LEFT);
        c.restoreToCount(save);
    }

    private void drawWeb(Canvas c, Source s) {
        RectF r = bounds(s);
        Bitmap b = webProvider != null ? webProvider.frame(s) : null;
        if (b != null) {
            c.drawBitmap(b, null, r, bmpPaint);
        } else {
            fillPaint.setStyle(Paint.Style.FILL);
            fillPaint.setColor(0x6638A169);
            c.drawRect(r, fillPaint);
            fillPaint.setColor(0xFFFFFFFF);
            fillPaint.setTextAlign(Paint.Align.CENTER);
            fillPaint.setTextSize(Math.max(12f, Math.min(r.height() / 8f, 40f)));
            c.drawText("Web", r.centerX(), r.centerY() + fillPaint.getTextSize() / 3f, fillPaint);
            fillPaint.setTextAlign(Paint.Align.LEFT);
        }
    }

    private void drawImage(Canvas c, Source s) {
        Bitmap b = image(s.imageFile);
        RectF r = bounds(s);
        if (b != null) {
            c.drawBitmap(b, null, r, bmpPaint);
        } else {
            fillPaint.setStyle(Paint.Style.FILL);
            fillPaint.setColor(0x55FFFFFF);
            c.drawRect(r, fillPaint);
        }
    }

    private void drawText(Canvas c, Source s) {
        prepareText(s);
        RectF r = bounds(s);
        float pad = s.box ? s.w * 0.3f : 0f;
        if (s.box) {
            fillPaint.setStyle(Paint.Style.FILL);
            fillPaint.setColor(0x99000000);
            float rad = s.w * 0.25f;
            c.drawRoundRect(r, rad, rad, fillPaint);
        }
        textPaint.setColor(s.color);
        if (!s.box) textPaint.setShadowLayer(Math.max(1f, s.w * 0.06f), 0, s.w * 0.03f, 0xCC000000);
        else textPaint.clearShadowLayer();
        Paint.FontMetrics fm = textPaint.getFontMetrics();
        float lh = fm.descent - fm.ascent;
        String[] ls = lines(s);
        float y = r.top + pad - fm.ascent;
        for (String l : ls) {
            c.drawText(l, r.left + pad, y, textPaint);
            y += lh;
        }
        textPaint.clearShadowLayer();
    }
}
