package com.ogstudio.streamer.engine;

/**
 * Pulls audio from the mic ring and the game ring on a steady wall-clock beat (one chunk every
 * ~23 ms), mixes them and hands each chunk to a sink with a timestamp on the same clock the
 * video uses. Because every source has its own reader thread, a slow or blocked source can no
 * longer delay the other one or shift the timestamps.
 */
final class AudioMixer implements Runnable {
    interface Sink {
        void onChunk(byte[] pcm, long ptsUs);
    }

    interface Gains {
        float mic();

        float game();
    }

    /** Rough delay between a sound happening and its samples reaching our ring (AudioRecord buffers). */
    private static final long CAPTURE_LATENCY_US = 40000L;

    private final PcmRing micRing;
    private final PcmRing gameRing;
    private final int chunk;
    private final int sampleRate;
    private final Gains gains;
    private final Sink sink;

    private volatile boolean running = true;
    volatile boolean micSilent;
    volatile int underruns;
    private int micZeroChunks;

    AudioMixer(PcmRing micRing, PcmRing gameRing, int chunk, int sampleRate, Gains gains, Sink sink) {
        this.micRing = micRing;
        this.gameRing = gameRing;
        this.chunk = chunk;
        this.sampleRate = sampleRate;
        this.gains = gains;
        this.sink = sink;
    }

    void stop() {
        running = false;
    }

    private static long nowUs() {
        return System.nanoTime() / 1000L;
    }

    private static void sleepUntil(long targetUs) throws InterruptedException {
        long d = targetUs - nowUs();
        if (d > 0) Thread.sleep(d / 1000L, (int) ((d % 1000L) * 1000L));
    }

    @Override
    public void run() {
        try {
            loop();
        } catch (InterruptedException ignored) {
        }
    }

    private void loop() throws InterruptedException {
        final long tickUs = chunk * 1000000L / sampleRate;
        final int want = chunk * 2;

        // Wait until every source has a little audio stored, so the first chunks are not full of gaps.
        long deadline = nowUs() + 600000L;
        while (running && nowUs() < deadline) {
            boolean ready = (micRing == null || micRing.size() >= want) && (gameRing == null || gameRing.size() >= want);
            if (ready) break;
            Thread.sleep(5);
        }

        short[] mb = new short[chunk];
        short[] gb = new short[chunk];
        byte[] pcm = new byte[chunk * 2];
        long due = nowUs() + tickUs;
        long lastPts = Long.MIN_VALUE;
        double latEma = -1;

        while (running) {
            sleepUntil(due);
            if (!running) return;
            long now = nowUs();
            if (now - due > 250000L) due = now; // we were stalled for a long time, do not burst

            float mg = gains.mic();
            float gg = gains.game();

            int level = Math.max(micRing != null ? micRing.size() : 0, gameRing != null ? gameRing.size() : 0);
            double lat = level * 1000000.0 / sampleRate + CAPTURE_LATENCY_US;
            latEma = latEma < 0 ? lat : latEma * 0.98 + lat * 0.02;

            boolean haveMic = false;
            boolean haveGame = false;
            if (micRing != null) {
                micRing.trimTo(chunk * 6);
                haveMic = micRing.read(mb, chunk);
                if (!haveMic) underruns++;
            }
            if (gameRing != null) {
                gameRing.trimTo(chunk * 6);
                haveGame = gameRing.read(gb, chunk);
                if (!haveGame) underruns++;
            }

            if (micRing != null && haveMic) {
                boolean allZero = true;
                for (int i = 0; i < chunk; i++) {
                    if (mb[i] != 0) {
                        allZero = false;
                        break;
                    }
                }
                if (allZero) {
                    if (++micZeroChunks >= 140) micSilent = true; // about 3 seconds of pure digital silence
                } else {
                    micZeroChunks = 0;
                    micSilent = false;
                }
            }

            for (int i = 0; i < chunk; i++) {
                float v = 0f;
                if (haveMic) v += mb[i] * mg;
                if (haveGame) v += gb[i] * gg;
                int s = (int) v;
                if (s > 32767) s = 32767;
                if (s < -32768) s = -32768;
                pcm[i * 2] = (byte) (s & 0xff);
                pcm[i * 2 + 1] = (byte) ((s >> 8) & 0xff);
            }

            long pts = due - (long) latEma;
            if (pts <= lastPts) pts = lastPts + 1;
            lastPts = pts;
            sink.onChunk(pcm, pts);

            due += tickUs;
        }
    }
}
