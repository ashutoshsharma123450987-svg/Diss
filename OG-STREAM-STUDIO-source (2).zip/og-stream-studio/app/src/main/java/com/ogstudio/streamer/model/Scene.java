package com.ogstudio.streamer.model;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** The canvas (stream picture) and its layers. Index 0 is drawn first (bottom). */
public final class Scene {
    public static final int PORTRAIT = 0;
    public static final int LANDSCAPE = 1;

    public int aspect = PORTRAIT;
    public final List<Source> sources = new ArrayList<Source>();

    public int logicalW() {
        return aspect == PORTRAIT ? 720 : 1280;
    }

    public int logicalH() {
        return aspect == PORTRAIT ? 1280 : 720;
    }

    public Source firstScreen() {
        for (Source s : sources) if (s.type == Source.SCREEN) return s;
        return null;
    }

    public String toJson() {
        try {
            JSONObject o = new JSONObject();
            o.put("aspect", aspect);
            JSONArray a = new JSONArray();
            for (Source s : sources) a.put(s.toJson());
            o.put("sources", a);
            return o.toString();
        } catch (Exception e) {
            return "";
        }
    }

    public static Scene fromJson(String json) {
        try {
            JSONObject o = new JSONObject(json);
            Scene sc = new Scene();
            sc.aspect = o.optInt("aspect", PORTRAIT) == LANDSCAPE ? LANDSCAPE : PORTRAIT;
            JSONArray a = o.optJSONArray("sources");
            if (a != null) {
                for (int i = 0; i < a.length(); i++) sc.sources.add(Source.fromJson(a.getJSONObject(i)));
            }
            return sc;
        } catch (Exception e) {
            return null;
        }
    }

    /** A new scene with only the phone screen, as big as possible and centered. */
    public static Scene createDefault(int aspect, float gameAr) {
        Scene sc = new Scene();
        sc.aspect = aspect;
        float cw = sc.logicalW();
        float ch = sc.logicalH();
        Source s = new Source(Source.SCREEN);
        s.ar = gameAr;
        float w = cw;
        if (cw / gameAr > ch) w = ch * gameAr;
        s.w = w;
        s.x = (cw - w) / 2f;
        s.y = (ch - w / gameAr) / 2f;
        sc.sources.add(s);
        return sc;
    }
}
