package com.ogstudio.streamer.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

import com.ogstudio.streamer.model.Scene;
import com.ogstudio.streamer.model.Source;
import com.ogstudio.streamer.render.SceneRenderer;

/**
 * Shows the canvas. In edit mode you can drag layers, resize them with the corner handle
 * or with two fingers, and parts outside the canvas are cut off (just like on the stream).
 */
public final class SceneView extends View {

    public interface Listener {
        void onSelectionChanged(Source s);

        void onSceneChanged();
    }

    private static final int NONE = 0;
    private static final int DRAG = 1;
    private static final int RESIZE = 2;

    private final SceneRenderer renderer;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final ScaleGestureDetector scaleDetector;

    private Scene scene;
    private boolean editable;
    private Source selected;
    private Listener listener;

    private float ox;
    private float oy;
    private float scale = 1f;

    private int mode = NONE;
    private float dragDX;
    private float dragDY;
    private float startW;
    private float startBoundsW;
    private boolean snapX;
    private boolean snapY;

    public SceneView(Context c) {
        super(c);
        renderer = new SceneRenderer(c);
        scaleDetector = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector d) {
                if (selected == null || selected.locked) return false;
                RectF before = renderer.bounds(selected);
                float cx = before.centerX();
                float cy = before.centerY();
                selected.w = clampSize(selected, selected.w * d.getScaleFactor());
                RectF after = renderer.bounds(selected);
                selected.x += cx - after.centerX();
                selected.y += cy - after.centerY();
                invalidate();
                return true;
            }

            @Override
            public void onScaleEnd(ScaleGestureDetector d) {
                if (listener != null) listener.onSceneChanged();
            }
        });
    }

    public void setListener(Listener l) {
        listener = l;
    }

    public void setScene(Scene s, boolean editable) {
        scene = s;
        this.editable = editable;
        if (selected != null && (s == null || !s.sources.contains(selected))) selected = null;
        invalidate();
    }

    public SceneRenderer renderer() {
        return renderer;
    }

    public Source getSelected() {
        return selected;
    }

    public void select(Source s) {
        if (selected == s) return;
        selected = s;
        if (listener != null) listener.onSelectionChanged(s);
        invalidate();
    }

    private float clampSize(Source s, float v) {
        if (scene == null) return v;
        if (s.type == Source.TEXT) return Math.max(10f, Math.min(600f, v));
        return Math.max(40f, Math.min(scene.logicalW() * 4f, v));
    }

    // ------------------------------------------------------------------ layout

    private void computeLayout() {
        float margin = editable ? Ui.dp(getContext(), 24) : 0f;
        float availW = Math.max(1f, getWidth() - margin * 2);
        float availH = Math.max(1f, getHeight() - margin * 2);
        scale = Math.min(availW / scene.logicalW(), availH / scene.logicalH());
        ox = (getWidth() - scene.logicalW() * scale) / 2f;
        oy = (getHeight() - scene.logicalH() * scale) / 2f;
    }

    private float toLX(float vx) {
        return (vx - ox) / scale;
    }

    private float toLY(float vy) {
        return (vy - oy) / scale;
    }

    private RectF toView(RectF r) {
        return new RectF(ox + r.left * scale, oy + r.top * scale, ox + r.right * scale, oy + r.bottom * scale);
    }

    // ------------------------------------------------------------------ drawing

    @Override
    protected void onDraw(Canvas canvas) {
        if (scene == null) return;
        computeLayout();
        float cw = scene.logicalW() * scale;
        float ch = scene.logicalH() * scale;

        canvas.drawColor(editable ? 0xFF0A0A0A : Ui.BG);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xFF000000);
        canvas.drawRect(ox, oy, ox + cw, oy + ch, paint);

        canvas.save();
        canvas.translate(ox, oy);
        canvas.scale(scale, scale);
        canvas.clipRect(0, 0, scene.logicalW(), scene.logicalH());
        renderer.drawScene(canvas, scene, null, 0, 0);
        canvas.restore();

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Ui.dp(getContext(), 1.5f));
        paint.setColor(Ui.ACCENT);
        canvas.drawRect(ox, oy, ox + cw, oy + ch, paint);

        if (!editable) return;

        if (mode == DRAG) {
            paint.setColor(0xFFFFD54F);
            paint.setStrokeWidth(Ui.dp(getContext(), 1));
            if (snapX) canvas.drawLine(ox + cw / 2f, oy, ox + cw / 2f, oy + ch, paint);
            if (snapY) canvas.drawLine(ox, oy + ch / 2f, ox + cw, oy + ch / 2f, paint);
        }

        if (selected != null) {
            RectF r = toView(renderer.bounds(selected));
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(Ui.dp(getContext(), 1.5f));
            paint.setColor(selected.locked ? 0xFF9E9E9E : 0xFFFFFFFF);
            paint.setPathEffect(new DashPathEffect(new float[]{Ui.dp(getContext(), 6), Ui.dp(getContext(), 4)}, 0));
            canvas.drawRect(r, paint);
            paint.setPathEffect(null);
            if (!selected.locked) {
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(Ui.ACCENT);
                canvas.drawCircle(r.right, r.bottom, Ui.dp(getContext(), 11), paint);
                paint.setStyle(Paint.Style.STROKE);
                paint.setColor(0xFFFFFFFF);
                canvas.drawCircle(r.right, r.bottom, Ui.dp(getContext(), 11), paint);
            }
        }
    }

    // ------------------------------------------------------------------ touch

    private boolean hitHandle(float vx, float vy) {
        RectF r = toView(renderer.bounds(selected));
        float d = Ui.dp(getContext(), 26);
        return Math.abs(vx - r.right) < d && Math.abs(vy - r.bottom) < d;
    }

    private Source hitTest(float lx, float ly) {
        for (int i = scene.sources.size() - 1; i >= 0; i--) {
            Source s = scene.sources.get(i);
            if (s.locked) continue;
            RectF b = renderer.bounds(s);
            if (b.contains(lx, ly)) return s;
        }
        return null;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (!editable || scene == null) return super.onTouchEvent(e); // lets setOnClickListener work in preview
        scaleDetector.onTouchEvent(e);
        if (scaleDetector.isInProgress()) {
            mode = NONE;
            return true;
        }
        computeLayout();
        float lx = toLX(e.getX());
        float ly = toLY(e.getY());
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (selected != null && !selected.locked && hitHandle(e.getX(), e.getY())) {
                    mode = RESIZE;
                    startW = selected.w;
                    startBoundsW = Math.max(1f, renderer.bounds(selected).width());
                } else {
                    Source hit = hitTest(lx, ly);
                    select(hit);
                    if (hit != null) {
                        mode = DRAG;
                        dragDX = lx - hit.x;
                        dragDY = ly - hit.y;
                    } else {
                        mode = NONE;
                    }
                }
                invalidate();
                return true;
            case MotionEvent.ACTION_POINTER_DOWN:
                mode = NONE;
                return true;
            case MotionEvent.ACTION_MOVE:
                if (selected == null || selected.locked) return true;
                if (mode == DRAG) {
                    float nx = lx - dragDX;
                    float ny = ly - dragDY;
                    RectF b = renderer.bounds(selected);
                    float bw = b.width();
                    float bh = b.height();
                    float cw = scene.logicalW();
                    float ch = scene.logicalH();
                    float snap = 10f;
                    snapX = Math.abs(nx + bw / 2f - cw / 2f) < snap;
                    snapY = Math.abs(ny + bh / 2f - ch / 2f) < snap;
                    if (snapX) nx = cw / 2f - bw / 2f;
                    if (snapY) ny = ch / 2f - bh / 2f;
                    selected.x = nx;
                    selected.y = ny;
                    invalidate();
                } else if (mode == RESIZE) {
                    float want = lx - selected.x;
                    if (selected.type == Source.TEXT) {
                        selected.w = clampSize(selected, startW * (want / startBoundsW));
                    } else {
                        selected.w = clampSize(selected, want);
                    }
                    invalidate();
                }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                boolean changed = mode != NONE;
                mode = NONE;
                snapX = false;
                snapY = false;
                invalidate();
                if (changed && listener != null) listener.onSceneChanged();
                return true;
            default:
                return true;
        }
    }
}
