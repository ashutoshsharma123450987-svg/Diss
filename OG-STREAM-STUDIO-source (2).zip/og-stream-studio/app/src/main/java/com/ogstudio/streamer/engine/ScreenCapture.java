package com.ogstudio.streamer.engine;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.DisplayMetrics;
import android.view.Display;

import java.nio.ByteBuffer;

/**
 * Captures the phone screen with MediaProjection into a Bitmap that the render loop draws
 * inside the "Screen capture" box. The capture size follows the box size, so a small box
 * costs less CPU. If the phone rotates, the capture is resized automatically.
 */
final class ScreenCapture {
    /** Guards bitmap, frameW and frameH. */
    final Object lock = new Object();
    Bitmap bitmap;
    int frameW;
    int frameH;

    private final Context ctx;
    private final MediaProjection projection;
    private final float boxW;
    private final float boxH;
    private final DisplayManager displayManager;

    private HandlerThread thread;
    private Handler handler;
    private ImageReader reader;
    private VirtualDisplay display;
    private int realW;
    private int realH;
    private int dpi;
    private ByteBuffer scratch;
    private Runnable onStopped;
    private volatile boolean stopped;

    private final MediaProjection.Callback projectionCallback = new MediaProjection.Callback() {
        @Override
        public void onStop() {
            Runnable r = onStopped;
            if (!stopped && r != null) r.run();
        }
    };

    private final DisplayManager.DisplayListener displayListener = new DisplayManager.DisplayListener() {
        @Override
        public void onDisplayAdded(int displayId) {
        }

        @Override
        public void onDisplayRemoved(int displayId) {
        }

        @Override
        public void onDisplayChanged(int displayId) {
            if (displayId == Display.DEFAULT_DISPLAY && handler != null) handler.post(resizeTask);
        }
    };

    private final Runnable resizeTask = new Runnable() {
        @Override
        public void run() {
            resizeIfNeeded();
        }
    };

    private final ImageReader.OnImageAvailableListener imageListener = new ImageReader.OnImageAvailableListener() {
        @Override
        public void onImageAvailable(ImageReader r) {
            onImage(r);
        }
    };

    ScreenCapture(Context ctx, MediaProjection projection, float boxWidthPx, float boxHeightPx) {
        this.ctx = ctx.getApplicationContext();
        this.projection = projection;
        this.boxW = boxWidthPx;
        this.boxH = boxHeightPx;
        this.displayManager = (DisplayManager) this.ctx.getSystemService(Context.DISPLAY_SERVICE);
    }

    void setOnStopped(Runnable r) {
        onStopped = r;
    }

    void start() {
        thread = new HandlerThread("og-capture");
        thread.start();
        handler = new Handler(thread.getLooper());
        projection.registerCallback(projectionCallback, handler);

        DisplayMetrics m = realMetrics();
        realW = m.widthPixels;
        realH = m.heightPixels;
        dpi = m.densityDpi;
        int[] size = captureSize(realW, realH);
        reader = ImageReader.newInstance(size[0], size[1], PixelFormat.RGBA_8888, 2);
        reader.setOnImageAvailableListener(imageListener, handler);
        display = projection.createVirtualDisplay("OGStreamCapture", size[0], size[1], dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, handler);
        displayManager.registerDisplayListener(displayListener, handler);
    }

    void stop() {
        stopped = true;
        try {
            displayManager.unregisterDisplayListener(displayListener);
        } catch (Exception ignored) {
        }
        try {
            projection.unregisterCallback(projectionCallback);
        } catch (Exception ignored) {
        }
        try {
            if (display != null) display.release();
        } catch (Exception ignored) {
        }
        try {
            if (reader != null) reader.close();
        } catch (Exception ignored) {
        }
        if (thread != null) thread.quitSafely();
        synchronized (lock) {
            if (bitmap != null) bitmap.recycle();
            bitmap = null;
        }
    }

    private DisplayMetrics realMetrics() {
        Display d = displayManager.getDisplay(Display.DEFAULT_DISPLAY);
        DisplayMetrics m = new DisplayMetrics();
        d.getRealMetrics(m);
        return m;
    }

    /** Fits the screen aspect into the box (in output pixels), never bigger than the real screen. */
    private int[] captureSize(int rw, int rh) {
        float far = rw / (float) rh;
        float dw;
        float dh;
        if (boxW / boxH > far) {
            dh = boxH;
            dw = dh * far;
        } else {
            dw = boxW;
            dh = dw / far;
        }
        float s = Math.min(1f, Math.min(rw / dw, rh / dh));
        dw *= s;
        dh *= s;
        int w = Math.max(64, ((int) dw) & ~1);
        int h = Math.max(64, ((int) dh) & ~1);
        return new int[]{w, h};
    }

    private void resizeIfNeeded() {
        if (stopped || display == null) return;
        try {
            DisplayMetrics m = realMetrics();
            if (m.widthPixels == realW && m.heightPixels == realH) return;
            realW = m.widthPixels;
            realH = m.heightPixels;
            int[] size = captureSize(realW, realH);
            ImageReader nr = ImageReader.newInstance(size[0], size[1], PixelFormat.RGBA_8888, 2);
            nr.setOnImageAvailableListener(imageListener, handler);
            display.resize(size[0], size[1], dpi);
            display.setSurface(nr.getSurface());
            ImageReader old = reader;
            reader = nr;
            if (old != null) old.close();
        } catch (Exception ignored) {
            // keep the old capture running
        }
    }

    private void onImage(ImageReader r) {
        Image img = null;
        try {
            img = r.acquireLatestImage();
            if (img == null || stopped) return;
            Image.Plane plane = img.getPlanes()[0];
            ByteBuffer buf = plane.getBuffer();
            int pixelStride = plane.getPixelStride();
            int bw = plane.getRowStride() / pixelStride;
            int w = img.getWidth();
            int h = img.getHeight();
            int need = bw * h * 4;
            buf.rewind();
            if (buf.remaining() < need) {
                if (scratch == null || scratch.capacity() < need) scratch = ByteBuffer.allocateDirect(need);
                scratch.clear();
                scratch.put(buf);
                scratch.limit(need);
                scratch.position(0);
                buf = scratch;
            }
            synchronized (lock) {
                if (stopped) return;
                if (bitmap == null || bitmap.getWidth() != bw || bitmap.getHeight() != h) {
                    if (bitmap != null) bitmap.recycle();
                    bitmap = Bitmap.createBitmap(bw, h, Bitmap.Config.ARGB_8888);
                }
                bitmap.copyPixelsFromBuffer(buf);
                frameW = w;
                frameH = h;
            }
        } catch (Exception ignored) {
            // skip this frame
        } finally {
            if (img != null) img.close();
        }
    }
}
