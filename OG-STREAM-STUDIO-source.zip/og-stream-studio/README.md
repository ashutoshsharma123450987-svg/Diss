# OG STREAM STUDIO

Apne use ke liye halka Android streaming app. Phone ki screen (game) ko seedha YouTube par live karta hai,
upar text aur logo laga sakte ho. Koi bahari library nahi hai, isliye APK chhota aur halka hai.

## APK kaise banayein (GitHub se)

1. GitHub par naya (private) repository banao.
2. Is folder ki saari files us repo me upload karo (`.github` folder samet).
3. Repo me **Actions** tab kholo. "Build APK" apne aap chalega (nahi chale to "Run workflow" dabao).
4. 3-5 minute baad run ke andar **Artifacts** me `OG-STREAM-STUDIO-apk` milega. Download karke zip kholo,
   andar `app-debug.apk` hai. Use phone me install karo ("Unknown source" allow karna padega).
5. Agar build fail ho to us run ka error text copy karke bhej do, main theek kar dunga.

## Use kaise karein

1. **Settings** me daalo: Stream URL (`rtmp://a.rtmp.youtube.com/live2`) aur Stream Key (YouTube Studio > Go Live).
2. Low-end phone ke liye 480p, 24 fps, 1200 kbps se shuru karo.
3. **Edit scene** me screen box ko canvas me kahin bhi rakho, bada-chhota karo. Text aur Image jodo.
   Canvas se bahar gaya hissa stream me nahi dikhta.
4. **GO LIVE** dabao. YouTube Studio me bhi Go Live dabao (agar auto-start off hai). "Start now" dabao.
   Phir apna game kholo. Band karne ke liye notification me **Stop**.

## Volume

Home screen par Mic aur Game ke slider (0 se 200%) aur Mute button hain. Stream chalte waqt bhi kaam karte hain.

Live chat dikhana, Screensaver, local recording. Ye baad me jod sakte hain.

## Agar video kaali dikhe

Settings me "Software drawing" ON karo.

## Mic aur Free Fire (zaroori)
Agar stream ke dauran screen par "OG STREAM STUDIO cannot record now as Free Fire MAX is recording" aaye, to
ye Android ka niyam hai: jab game apna voice chat/mic chalata hai to dusre app ka mic band kar diya jaata hai.
Isse bachne ke liye Free Fire me voice chat / mic band rakho, ya Settings > Awaaz > "Sirf game audio" chuno.
Home screen par "Mic band" ki chetavni dikhegi jab mic ko sirf khamoshi mil rahi ho.

## Teammate ki awaaz
App ab game ke saath teammate ki voice chat bhi capture karne ki koshish karta hai. Ye tabhi aati hai jab game
apni voice chat ko capture hone deta hai. Aapki apni awaaz (mic) tab hi aati hai jab game mic na le rahi ho.

## Web source (overlay / animation)
Editor me "+ Web" dabao, link daalo. Ye page stream me dikhta hai (editor me hara box dikhta hai).
Halka rakha gaya hai: chhota size (max 640 px) aur 8 fps. Transparent background wale overlays achhe se blend hote hain.
Ek ya do se zyada Web source mat rakho, low-end phone par load badhta hai.

## Quality: 720p 60 / 1080p
Settings me Quality me 1080p aur FPS me 60 aa gaye. Ye bhaari hain. Agar phone frames nahi bana paata, to app fps
apne aap ghata deta hai (aur halka hone par dheere dheere wapas badhata hai). Pehle 720p 30 se test karo.

## Floating controls
Settings > "Floating controls" ON karo aur 'Display over other apps' permission do. Stream chalne par game ke upar
LIVE bubble aata hai. Bubble dabao: Mic ON/OFF, Game ON/OFF, volume sliders, STOP (do baar dabana padta hai).
Bubble ko khinchkar kahin bhi rakh sakte ho. Notification me bhi Mic mute / Game mute / Stop buttons hain.
Dhyan: Android overlay ko screen capture me le leta hai, isliye bubble stream me dikh sakta hai.

## Game chhota dikhne ki dikkat (fix)
Capture ka size ab sirf ek baar, Settings ke "Game kaise khelte ho" (Landscape/Portrait) ke hisaab se banta hai aur
stream ke dauran badla nahi jaata. Phone ghoomne par kaali patti apne aap kaat di jaati hai.
Isliye Settings me Landscape/Portrait sahi chuno. Free Fire ke liye Landscape.

## BRB mode ("Game OFF")
Floating panel me "Game ON/OFF" ab BRB mode hai. OFF karne par screen box me "STREAMING SOON" ka animation chalta hai,
game ki awaaz aur mic dono band ho jaate hain, aur screen capture ka copy rukne se CPU bhi bachta hai.
Wapas ON karne par game aur mic pehle jaise ho jaate hain. "Mic" button sirf mic ko band karta hai.
Notification me bhi "Game OFF / Game ON" button hai.

## BRB video (STREAMING SOON)
"Game OFF" dabane par screen box me assets/brb.mp4 (STREAMING SOON video) loop me chalti hai aur uska gaana stream me jaata hai
(game aur mic band). "Game ON" par video aur gaana ruk jaate hain aur game wapas aata hai.
Agar video kisi phone par na chale to purani animation dikhti hai.
Apni video lagane ke liye assets/brb.mp4 badal do (H.264 + AAC, 16:9, chhoti rakho, 768x432 24fps theek hai)
aur BrbPlayer.java me CACHE ka naam badlo (brb_v2.mp4), warna purani cache wali file chalegi.
Dhyan: gaana copyright wala ho to YouTube stream ko mute/claim kar sakta hai.

## BRB turant shuru hota hai
Stream shuru hote hi BRB video ke decoders taiyar ho jaate hain aur pehla frame (poster) memory me rehta hai.
BRB ON dabate hi wahi frame dikhta hai aur video bina deri ke chalne lagti hai (beech me purani animation nahi aati).

## Delay (latency)
Delay ka sabse bada hissa YouTube ki "Stream latency" setting hai. YouTube Studio > Create > Go live > Stream settings > Stream latency
me "Ultra-low latency" chuno (live shuru karne se pehle). Ye YouTube ke hisaab se zyadatar viewers ke liye 5 second se kam delay deta hai.
App ki taraf: encoder ko real-time hint, aur net slow hone par queue 1.5 second se zyada badhne nahi di jaati.
