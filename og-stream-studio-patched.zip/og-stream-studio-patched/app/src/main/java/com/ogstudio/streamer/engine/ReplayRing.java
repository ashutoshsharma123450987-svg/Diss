package com.ogstudio.streamer.engine;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Rolling buffer of already-encoded media for OG CLIP STUDIO (Java port of the Kotlin ReplayRing).
 * Video is kept in whole GOPs (first sample is always a key frame). Oldest GOP is dropped only when the next
 * key frame is still at least the window older than the newest frame. A byte cap protects RAM.
 * Samples are immutable, so snapshots share them without copying.
 */
final class ReplayRing {
    static final class Sample {
        final byte[] data;
        final long ptsUs;
        final boolean key;

        Sample(byte[] data, long ptsUs, boolean key) {
            this.data = data;
            this.ptsUs = ptsUs;
            this.key = key;
        }
    }

    static final class Snapshot {
        final List<Sample> video;
        final List<Sample> audio;

        Snapshot(List<Sample> video, List<Sample> audio) {
            this.video = video;
            this.audio = audio;
        }

        long startUs() {
            return video.get(0).ptsUs;
        }

        long durationUs() {
            return video.get(video.size() - 1).ptsUs - video.get(0).ptsUs;
        }
    }

    private final Object lock = new Object();
    private final ArrayList<Sample> video = new ArrayList<Sample>();
    private final ArrayDeque<Sample> audio = new ArrayDeque<Sample>();
    private final long maxBytes;
    private volatile long windowUs;
    private long bytes;
    private boolean waitingForKey = true;
    private int head; // index of the first live video sample inside 'video' (lazy compaction)

    ReplayRing(int windowSeconds, long maxBytes) {
        this.windowUs = windowSeconds * 1000000L;
        this.maxBytes = maxBytes;
    }

    void setWindowSeconds(int s) {
        windowUs = s * 1000000L;
    }

    int windowSeconds() {
        return (int) (windowUs / 1000000L);
    }

    void addVideo(byte[] data, long ptsUs, boolean key) {
        synchronized (lock) {
            if (waitingForKey) {
                if (!key) return;
                waitingForKey = false;
            }
            video.add(new Sample(data, ptsUs, key));
            bytes += data.length;
            trim();
        }
    }

    void addAudio(byte[] data, long ptsUs) {
        synchronized (lock) {
            if (video.size() - head == 0) return;
            audio.addLast(new Sample(data, ptsUs, false));
            bytes += data.length;
        }
    }

    void clear() {
        synchronized (lock) {
            video.clear();
            head = 0;
            audio.clear();
            bytes = 0;
            waitingForKey = true;
        }
    }

    long bufferedBytes() {
        synchronized (lock) {
            return bytes;
        }
    }

    long bufferedUs() {
        synchronized (lock) {
            int n = video.size() - head;
            return n == 0 ? 0 : video.get(video.size() - 1).ptsUs - video.get(head).ptsUs;
        }
    }

    /** Last durationUs of media starting on the latest key frame at or before (newest - duration); null if empty. */
    Snapshot snapshot(long durationUs) {
        synchronized (lock) {
            int n = video.size();
            if (n - head == 0) return null;
            long target = video.get(n - 1).ptsUs - durationUs;
            int start = head;
            for (int i = head; i < n; i++) {
                Sample s = video.get(i);
                if (s.key && s.ptsUs <= target) start = i;
            }
            List<Sample> v = new ArrayList<Sample>(video.subList(start, n));
            long from = v.get(0).ptsUs;
            List<Sample> a = new ArrayList<Sample>();
            for (Iterator<Sample> it = audio.iterator(); it.hasNext(); ) {
                Sample s = it.next();
                if (s.ptsUs >= from) a.add(s);
            }
            return new Snapshot(v, a);
        }
    }

    // ---- internals, lock held ----

    private void trim() {
        while (true) {
            int k = secondKey();
            if (k < 0) break;
            if (video.get(k).ptsUs <= video.get(video.size() - 1).ptsUs - windowUs) dropTo(k);
            else break;
        }
        while (bytes > maxBytes) {
            int k = secondKey();
            if (k < 0) break;
            dropTo(k);
        }
        long first = video.get(head).ptsUs;
        while (!audio.isEmpty() && audio.peekFirst().ptsUs < first) {
            bytes -= audio.removeFirst().data.length;
        }
        // compact occasionally so the list does not grow without bound
        if (head > 512) {
            video.subList(0, head).clear();
            head = 0;
        }
    }

    private int secondKey() {
        for (int i = head + 1; i < video.size(); i++) if (video.get(i).key) return i;
        return -1;
    }

    private void dropTo(int index) {
        for (int i = head; i < index; i++) {
            bytes -= video.get(i).data.length;
            video.set(i, null);
        }
        head = index;
    }
}
