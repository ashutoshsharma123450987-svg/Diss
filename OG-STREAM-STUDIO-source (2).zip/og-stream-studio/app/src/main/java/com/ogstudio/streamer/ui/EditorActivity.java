package com.ogstudio.streamer.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.ogstudio.streamer.model.Prefs;
import com.ogstudio.streamer.model.Scene;
import com.ogstudio.streamer.model.Source;

import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/** Scene editor: place the screen box, text and images on the canvas. */
public class EditorActivity extends Activity implements SceneView.Listener {
    private static final int REQ_IMAGE = 11;
    private static final int[] COLORS = {0xFFFFFFFF, 0xFFFF5A1F, 0xFFE53935, 0xFFFFD54F, 0xFF66BB6A, 0xFF29B6F6, 0xFF000000};

    private Prefs prefs;
    private Scene scene;
    private SceneView view;
    private LinearLayout selectionBar;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = new Prefs(this);
        scene = prefs.loadScene();

        LinearLayout root = Ui.column(this);
        root.setBackgroundColor(Ui.BG);
        int pad = Ui.dp(this, 10);
        root.setPadding(pad, pad, pad, pad);

        LinearLayout top = Ui.row(this);
        Button done = Ui.button(this, "Done", Ui.ACCENT, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        TextView title = Ui.label(this, "Scene editor", 18, Ui.TEXT, true);
        title.setGravity(Gravity.CENTER);
        Button layers = Ui.button(this, "Layers", Ui.PANEL, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showLayers();
            }
        });
        top.addView(done);
        top.addView(title, Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        top.addView(layers);
        root.addView(top, Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0));

        view = new SceneView(this);
        view.setListener(this);
        view.setScene(scene, true);
        root.addView(view, Ui.lpMargins(this, ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f, 0, 8, 0, 8));

        HorizontalScrollView sel = new HorizontalScrollView(this);
        sel.setHorizontalScrollBarEnabled(false);
        selectionBar = Ui.row(this);
        sel.addView(selectionBar);
        root.addView(sel, Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0));

        LinearLayout bottom = Ui.row(this);
        bottom.addView(Ui.button(this, "+ Text", Ui.PANEL, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addText();
            }
        }), Ui.lpMargins(this, 0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f, 0, 0, 4, 0));
        bottom.addView(Ui.button(this, "+ Image", Ui.PANEL, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pickImage();
            }
        }), Ui.lpMargins(this, 0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f, 4, 0, 4, 0));
        bottom.addView(Ui.button(this, "+ Web", Ui.PANEL, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addWeb();
            }
        }), Ui.lpMargins(this, 0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f, 4, 0, 4, 0));
        bottom.addView(Ui.button(this, "Reset", Ui.PANEL, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmReset();
            }
        }), Ui.lpMargins(this, 0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f, 4, 0, 0, 0));
        root.addView(bottom, Ui.lpMargins(this, ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0, 8, 0, 0));

        setContentView(root);
        rebuildSelectionBar();
    }

    @Override
    protected void onPause() {
        save();
        super.onPause();
    }

    private void save() {
        prefs.saveScene(scene);
    }

    @Override
    public void onSelectionChanged(Source s) {
        rebuildSelectionBar();
    }

    @Override
    public void onSceneChanged() {
        save();
    }

    // ------------------------------------------------------------------ selection actions

    private void rebuildSelectionBar() {
        selectionBar.removeAllViews();
        final Source s = view.getSelected();
        if (s == null) {
            TextView hint = Ui.label(this, "Kisi layer par tap karo. Khinch kar move karo, kone ke gole se ya do ungli se bada-chhota karo.",
                    12, Ui.MUTED, false);
            hint.setPadding(Ui.dp(this, 4), Ui.dp(this, 10), Ui.dp(this, 4), Ui.dp(this, 10));
            selectionBar.addView(hint, Ui.lp(Ui.dp(this, 360), ViewGroup.LayoutParams.WRAP_CONTENT, 0));
            return;
        }
        if (s.type == Source.TEXT) {
            addAction("Edit text", new Runnable() {
                @Override
                public void run() {
                    editText(s, false);
                }
            });
        }
        if (s.type == Source.WEB) {
            addAction("Edit link", new Runnable() {
                @Override
                public void run() {
                    editWebUrl(s, false);
                }
            });
        }
        addAction(s.locked ? "Unlock" : "Lock", new Runnable() {
            @Override
            public void run() {
                s.locked = !s.locked;
                save();
                view.invalidate();
                rebuildSelectionBar();
            }
        });
        addAction("Center", new Runnable() {
            @Override
            public void run() {
                RectF b = view.renderer().bounds(s);
                s.x = (scene.logicalW() - b.width()) / 2f;
                s.y = (scene.logicalH() - b.height()) / 2f;
                save();
                view.invalidate();
            }
        });
        if (s.type != Source.TEXT) {
            addAction("Fit width", new Runnable() {
                @Override
                public void run() {
                    s.w = scene.logicalW();
                    s.x = 0;
                    save();
                    view.invalidate();
                }
            });
        }
        addAction("Front", new Runnable() {
            @Override
            public void run() {
                scene.sources.remove(s);
                scene.sources.add(s);
                save();
                view.invalidate();
            }
        });
        addAction("Back", new Runnable() {
            @Override
            public void run() {
                scene.sources.remove(s);
                scene.sources.add(0, s);
                save();
                view.invalidate();
            }
        });
        if (s.type != Source.SCREEN) {
            addAction("Delete", new Runnable() {
                @Override
                public void run() {
                    scene.sources.remove(s);
                    view.select(null);
                    save();
                    view.invalidate();
                }
            });
        }
    }

    private void addAction(String text, final Runnable r) {
        Button b = Ui.button(this, text, Ui.PANEL, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                r.run();
            }
        });
        selectionBar.addView(b, Ui.lpMargins(this, ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0, 0, 6, 0));
    }

    // ------------------------------------------------------------------ add / reset

    private void addText() {
        Source s = new Source(Source.TEXT);
        s.text = "Text";
        s.w = scene.aspect == Scene.PORTRAIT ? 72f : 64f;
        s.x = scene.logicalW() * 0.1f;
        s.y = scene.logicalH() * 0.08f;
        scene.sources.add(s);
        view.select(s);
        view.invalidate();
        editText(s, true);
    }

    private void addWeb() {
        Source s = new Source(Source.WEB);
        s.ar = 16f / 9f;
        s.w = scene.logicalW() * 0.6f;
        s.x = scene.logicalW() * 0.2f;
        s.y = scene.logicalH() * 0.1f;
        editWebUrl(s, true);
    }

    private void editWebUrl(final Source s, final boolean isNew) {
        final EditText in = new EditText(this);
        in.setSingleLine(true);
        in.setText(s.url);
        in.setHint("https://...");
        in.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Web page ka link")
                .setMessage("Overlay / animation ka link daalo. Ye stream me dikhega (editor me hara box).")
                .setView(in)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        String u = in.getText().toString().trim();
                        if (u.length() == 0) return;
                        s.url = u;
                        if (isNew) {
                            scene.sources.add(s);
                            view.select(s);
                        }
                        save();
                        view.invalidate();
                        rebuildSelectionBar();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void pickImage() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType("image/*");
        try {
            startActivityForResult(Intent.createChooser(i, "Image chuno"), REQ_IMAGE);
        } catch (Exception e) {
            Toast.makeText(this, "Gallery nahi khuli", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int req, int result, Intent data) {
        super.onActivityResult(req, result, data);
        if (req != REQ_IMAGE || result != RESULT_OK || data == null || data.getData() == null) return;
        try {
            Uri uri = data.getData();
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            InputStream is = getContentResolver().openInputStream(uri);
            BitmapFactory.decodeStream(is, null, o);
            if (is != null) is.close();
            int sample = 1;
            while (Math.max(o.outWidth, o.outHeight) / sample > 1024) sample *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            is = getContentResolver().openInputStream(uri);
            Bitmap bmp = BitmapFactory.decodeStream(is, null, o2);
            if (is != null) is.close();
            if (bmp == null) throw new IllegalStateException("decode failed");

            String name = "img_" + System.currentTimeMillis() + ".png";
            FileOutputStream fos = openFileOutput(name, MODE_PRIVATE);
            bmp.compress(Bitmap.CompressFormat.PNG, 100, fos);
            fos.close();

            Source s = new Source(Source.IMAGE);
            s.imageFile = name;
            s.ar = bmp.getWidth() / (float) bmp.getHeight();
            s.w = scene.logicalW() * 0.35f;
            s.x = scene.logicalW() * 0.6f;
            s.y = scene.logicalH() * 0.04f;
            bmp.recycle();
            scene.sources.add(s);
            view.select(s);
            save();
            view.invalidate();
        } catch (Exception e) {
            Toast.makeText(this, "Image load nahi hui", Toast.LENGTH_LONG).show();
        }
    }

    private void confirmReset() {
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Scene reset?")
                .setMessage("Text aur images hata di jaayengi, sirf screen box bachega.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Reset", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        scene = Scene.createDefault(scene.aspect, prefs.defaultGameAr());
                        view.select(null);
                        view.setScene(scene, true);
                        save();
                    }
                })
                .show();
    }

    // ------------------------------------------------------------------ text dialog

    private void editText(final Source s, final boolean isNew) {
        final EditText et = new EditText(this);
        et.setText(s.text);
        et.setTextColor(Ui.TEXT);
        et.setMinLines(2);
        et.setGravity(Gravity.TOP | Gravity.START);
        et.setSelection(et.getText().length());

        final int[] color = {s.color};
        final List<View> swatches = new ArrayList<View>();
        LinearLayout colors = Ui.row(this);
        for (final int c : COLORS) {
            View v = new View(this);
            swatches.add(v);
            v.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View x) {
                    color[0] = c;
                    markSwatches(swatches, color[0]);
                }
            });
            colors.addView(v, Ui.lpMargins(this, Ui.dp(this, 34), Ui.dp(this, 34), 0, 0, 0, 8, 0));
        }
        markSwatches(swatches, color[0]);

        final CheckBox bold = new CheckBox(this);
        bold.setText("Bold");
        bold.setTextColor(Ui.TEXT);
        bold.setChecked(s.bold);
        final CheckBox box = new CheckBox(this);
        box.setText("Piche kaala box");
        box.setTextColor(Ui.TEXT);
        box.setChecked(s.box);

        LinearLayout col = Ui.column(this);
        int pad = Ui.dp(this, 20);
        col.setPadding(pad, Ui.dp(this, 8), pad, 0);
        col.addView(et);
        col.addView(colors, Ui.lpMargins(this, ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0, 12, 0, 4));
        col.addView(bold);
        col.addView(box);
        ScrollView sv = new ScrollView(this);
        sv.addView(col);

        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Text")
                .setView(sv)
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        if (isNew) {
                            scene.sources.remove(s);
                            view.select(null);
                            view.invalidate();
                        }
                    }
                })
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        String t = et.getText().toString();
                        s.text = t.length() == 0 ? " " : t;
                        s.color = color[0];
                        s.bold = bold.isChecked();
                        s.box = box.isChecked();
                        save();
                        view.invalidate();
                    }
                })
                .show();
    }

    private void markSwatches(List<View> swatches, int selected) {
        for (int i = 0; i < swatches.size(); i++) {
            GradientDrawable d = new GradientDrawable();
            d.setShape(GradientDrawable.OVAL);
            d.setColor(COLORS[i]);
            d.setStroke(Ui.dp(this, COLORS[i] == selected ? 3 : 1), COLORS[i] == selected ? Ui.ACCENT : 0xFF777777);
            swatches.get(i).setBackground(d);
        }
    }

    // ------------------------------------------------------------------ layers dialog

    private void showLayers() {
        final LinearLayout list = Ui.column(this);
        int pad = Ui.dp(this, 12);
        list.setPadding(pad, pad, pad, pad);
        ScrollView sv = new ScrollView(this);
        sv.addView(list);
        final AlertDialog dlg = new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Layers (upar wali upar dikhti hai)")
                .setView(sv)
                .setPositiveButton("Close", null)
                .create();
        populateLayers(list, dlg);
        dlg.show();
    }

    private void populateLayers(final LinearLayout list, final AlertDialog dlg) {
        list.removeAllViews();
        for (int i = scene.sources.size() - 1; i >= 0; i--) {
            final Source s = scene.sources.get(i);
            final int idx = i;
            LinearLayout row = Ui.row(this);
            TextView name = Ui.label(this, s.label() + (s.locked ? "  (locked)" : ""), 14,
                    s == view.getSelected() ? Ui.ACCENT : Ui.TEXT, false);
            name.setPadding(0, Ui.dp(this, 10), Ui.dp(this, 6), Ui.dp(this, 10));
            name.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    view.select(s);
                    dlg.dismiss();
                }
            });
            row.addView(name, Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            row.addView(small("↑", new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (idx < scene.sources.size() - 1) {
                        scene.sources.remove(idx);
                        scene.sources.add(idx + 1, s);
                        changed(list, dlg);
                    }
                }
            }));
            row.addView(small("↓", new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (idx > 0) {
                        scene.sources.remove(idx);
                        scene.sources.add(idx - 1, s);
                        changed(list, dlg);
                    }
                }
            }));
            row.addView(small(s.locked ? "Unlock" : "Lock", new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    s.locked = !s.locked;
                    changed(list, dlg);
                }
            }));
            if (s.type != Source.SCREEN) {
                row.addView(small("X", new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        scene.sources.remove(s);
                        if (view.getSelected() == s) view.select(null);
                        changed(list, dlg);
                    }
                }));
            }
            list.addView(row);
        }
    }

    private Button small(String text, View.OnClickListener l) {
        Button b = Ui.button(this, text, Ui.PANEL, l);
        b.setMinimumHeight(Ui.dp(this, 36));
        b.setTextSize(12);
        b.setLayoutParams(Ui.lpMargins(this, ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, 0, 4, 0, 0, 0));
        return b;
    }

    private void changed(LinearLayout list, AlertDialog dlg) {
        save();
        view.invalidate();
        populateLayers(list, dlg);
        rebuildSelectionBar();
    }
}
