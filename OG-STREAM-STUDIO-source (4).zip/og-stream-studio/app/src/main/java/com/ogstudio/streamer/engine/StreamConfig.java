package com.ogstudio.streamer.engine;

import com.ogstudio.streamer.model.Prefs;
import com.ogstudio.streamer.model.Scene;

/** Snapshot of everything the engine needs. Taken when Go Live is pressed. */
final class StreamConfig {
    String url;
    String key;
    int outW;
    int outH;
    int fps;
    int videoKbps;
    int audio;
    boolean softwareRender;
    boolean micClean;
    Scene scene;

    static StreamConfig from(Prefs p) {
        StreamConfig c = new StreamConfig();
        c.url = p.url();
        c.key = p.key();
        c.scene = p.loadScene();
        int[] size = p.outputSize(c.scene);
        c.outW = size[0];
        c.outH = size[1];
        c.fps = p.fps();
        c.videoKbps = Math.max(300, p.bitrateKbps());
        c.audio = p.audio();
        c.softwareRender = p.softwareRender();
        c.micClean = p.micClean();
        return c;
    }

    float scaleX() {
        return outW / (float) scene.logicalW();
    }

    float scaleY() {
        return outH / (float) scene.logicalH();
    }
}
