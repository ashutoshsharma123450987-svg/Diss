package com.ogstudio.streamer.engine;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.regex.Pattern;

/**
 * Hands finished clip files to OG CLIP STUDIO. Protected by the signature permission
 * com.ogstudio.streamer.permission.CLIP_CONTROL, so only an app signed with the same key can read.
 */
public class ClipProvider extends ContentProvider {
    public static final String AUTHORITY = "com.ogstudio.streamer.clips";
    private static final Pattern NAME = Pattern.compile("clip_\\d+\\.mp4");

    static Uri uriFor(File f) {
        return Uri.parse("content://" + AUTHORITY + "/" + f.getName());
    }

    private File fileFor(Uri uri) throws FileNotFoundException {
        String n = uri.getLastPathSegment();
        if (n == null || !NAME.matcher(n).matches()) throw new FileNotFoundException("bad name");
        File f = new File(ClipMuxer.dir(getContext()), n);
        if (!f.exists()) throw new FileNotFoundException(n);
        return f;
    }

    @Override
    public boolean onCreate() {
        return true;
    }

    @Override
    public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        return ParcelFileDescriptor.open(fileFor(uri), ParcelFileDescriptor.MODE_READ_ONLY);
    }

    @Override
    public String getType(Uri uri) {
        return "video/mp4";
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        try {
            return fileFor(uri).delete() ? 1 : 0;
        } catch (FileNotFoundException e) {
            return 0;
        }
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        return null;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        return null;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        return 0;
    }
}
