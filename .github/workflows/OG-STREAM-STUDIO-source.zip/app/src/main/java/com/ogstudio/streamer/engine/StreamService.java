package com.ogstudio.streamer.engine;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.graphics.RectF;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.SystemClock;

import com.ogstudio.streamer.R;
import com.ogstudio.streamer.model.Prefs;
import com.ogstudio.streamer.model.Source;
import com.ogstudio.streamer.render.SceneRenderer;
import com.ogstudio.streamer.rtmp.RtmpClient;
import com.ogstudio.streamer.ui.MainActivity;

/** Foreground service that runs the whole live stream. */
public class StreamService extends Service implements FailListener {
    public static final String ACTION_START = "com.ogstudio.streamer.START";
    public static final String ACTION_STOP = "com.ogstudio.streamer.STOP";
    public static final String EXTRA_CODE = "code";
    public static final String EXTRA_DATA = "data";

    public static final int IDLE = 0;
    public static final int STARTING = 1;
    public static final int LIVE = 2;
    public static final int ERROR = 3;

    // Read by the UI.
    public static volatile int state = IDLE;
    public static volatile String message = "";
    public static volatile long liveSinceMs;
    public static volatile int curKbps;
    public static volatile int curFps;
    public static volatile int droppedFrames;
    // Live volume controls (1.0 = normal). The Home screen changes these while streaming, the audio mixer reads them.
    public static volatile float micGain = 1.0f;
    public static volatile float gameGain = 0.8f;
    public static volatile boolean micMuted;
    public static volatile boolean gameMuted;

    private static final String CHANNEL = "og_stream";
    private static final int NOTIF_ID = 77;

    private final Object lock = new Object();
    private boolean active;
    private boolean stopping;
    private volatile boolean running;

    private MediaProjection projection;
    private RtmpClient rtmp;
    private ScreenCapture capture;
    private VideoPipeline video;
    private AudioPipeline audio;
    private SceneRenderer renderer;
    private PowerManager.WakeLock wake;
    private Thread statsThread;
    private StreamConfig cfg;

    public static boolean isActive() {
        return state == STARTING || state == LIVE;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Live stream", NotificationManager.IMPORTANCE_LOW);
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(ch);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            if (active) {
                stopStream("Stream stop ho gayi", false);
            } else {
                stopSelf();
            }
            return START_NOT_STICKY;
        }
        if (!ACTION_START.equals(action)) {
            if (!active) stopSelf();
            return START_NOT_STICKY;
        }
        synchronized (lock) {
            if (active) return START_NOT_STICKY;
            active = true;
            stopping = false;
        }

        state = STARTING;
        message = "Connecting...";
        droppedFrames = 0;
        curFps = 0;
        curKbps = 0;

        Prefs prefs = new Prefs(this);
        micGain = prefs.micVolume() / 100f;
        gameGain = prefs.gameVolume() / 100f;
        micMuted = false;
        gameMuted = false;
        cfg = StreamConfig.from(prefs);
        boolean micOk = checkSelfPermission("android.permission.RECORD_AUDIO") == PackageManager.PERMISSION_GRANTED;
        if (!micOk) cfg.audio = Prefs.AUDIO_OFF;

        startForegroundCompat(micOk && cfg.audio != Prefs.AUDIO_OFF);

        try {
            int code = intent.getIntExtra(EXTRA_CODE, 0);
            Intent data = intent.getParcelableExtra(EXTRA_DATA);
            MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            projection = mpm.getMediaProjection(code, data);
            if (projection == null) throw new IllegalStateException("Screen permission nahi mili");
        } catch (Exception e) {
            stopStream("Screen capture start nahi hua: " + e.getMessage(), true);
            return START_NOT_STICKY;
        }

        running = true;
        new Thread(new Runnable() {
            @Override
            public void run() {
                startPipeline();
            }
        }, "og-stream-start").start();
        return START_NOT_STICKY;
    }

    private void startForegroundCompat(boolean withMic) {
        Notification n = buildNotification("Connecting...");
        if (Build.VERSION.SDK_INT >= 29) {
            int type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION;
            if (withMic && Build.VERSION.SDK_INT >= 30) type |= ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE;
            startForeground(NOTIF_ID, n, type);
        } else {
            startForeground(NOTIF_ID, n);
        }
    }

    private Notification buildNotification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent openPi = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Intent stop = new Intent(this, StreamService.class);
        stop.setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 1, stop,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL)
                : new Notification.Builder(this);
        b.setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("OG STREAM STUDIO")
                .setContentText(text)
                .setContentIntent(openPi)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(null, "Stop", stopPi).build());
        return b.build();
    }

    private void updateNotification(String text) {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.notify(NOTIF_ID, buildNotification(text));
        } catch (Exception ignored) {
        }
    }

    // ------------------------------------------------------------------ start

    private void startPipeline() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "OGStream:live");
            wake.acquire(12L * 60L * 60L * 1000L);

            renderer = new SceneRenderer(this);

            rtmp = new RtmpClient(cfg.url, cfg.key);
            rtmp.setListener(new RtmpClient.Listener() {
                @Override
                public void onError(String reason) {
                    onFail(reason);
                }
            });
            rtmp.connect(10000);
            if (!running) return;

            long t0Us = System.nanoTime() / 1000L;
            boolean wantAudio = cfg.audio != Prefs.AUDIO_OFF;
            rtmp.sendMetadata(cfg.outW, cfg.outH, cfg.fps, cfg.videoKbps,
                    wantAudio ? AudioPipeline.BITRATE / 1000 : 0, AudioPipeline.SAMPLE_RATE, false);

            Source screen = cfg.scene.firstScreen();
            if (screen != null) {
                RectF b = renderer.bounds(screen);
                capture = new ScreenCapture(this, projection, b.width() * cfg.scaleX(), b.height() * cfg.scaleY());
                capture.setOnStopped(new Runnable() {
                    @Override
                    public void run() {
                        onFail("Screen sharing band ho gayi");
                    }
                });
                capture.start();
            }

            String audioNote = "";
            if (wantAudio) {
                audio = new AudioPipeline(cfg, projection, rtmp, t0Us, this);
                boolean ok = audio.start();
                audioNote = audio.warning;
                if (!ok) {
                    audio = null;
                    audioNote += "Bina awaaz ke stream chal rahi hai.";
                }
            }

            video = new VideoPipeline(cfg, rtmp, capture, renderer, t0Us, this);
            video.start();

            if (!running) return;
            liveSinceMs = SystemClock.elapsedRealtime();
            state = LIVE;
            message = audioNote.length() > 0 ? audioNote : "Live";
            startStats();
        } catch (Exception e) {
            onFail(e.getMessage() == null ? e.toString() : e.getMessage());
        }
    }

    private void startStats() {
        statsThread = new Thread(new Runnable() {
            @Override
            public void run() {
                long lastBytes = rtmp.getBytesSent();
                int lastFrames = 0;
                while (running) {
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        return;
                    }
                    if (!running) return;
                    long b = rtmp.getBytesSent();
                    int f = video.framesSent.get();
                    curKbps = (int) ((b - lastBytes) * 8 / 1000);
                    curFps = f - lastFrames;
                    lastBytes = b;
                    lastFrames = f;
                    droppedFrames = video.framesDropped.get();
                    video.tick();
                    long secs = (SystemClock.elapsedRealtime() - liveSinceMs) / 1000;
                    updateNotification(String.format("LIVE %02d:%02d  %d fps  %d kbps", secs / 60, secs % 60, curFps, curKbps));
                }
            }
        }, "og-stats");
        statsThread.start();
    }

    // ------------------------------------------------------------------ stop

    @Override
    public void onFail(String reason) {
        stopStream(reason, true);
    }

    private void stopStream(String reason, boolean error) {
        synchronized (lock) {
            if (!active || stopping) return;
            stopping = true;
        }
        running = false;
        state = error ? ERROR : IDLE;
        message = reason == null ? "" : reason;
        new Thread(new Runnable() {
            @Override
            public void run() {
                teardown();
                synchronized (lock) {
                    active = false;
                    stopping = false;
                }
                try {
                    stopForeground(true);
                } catch (Exception ignored) {
                }
                stopSelf();
            }
        }, "og-stream-stop").start();
    }

    private void teardown() {
        if (statsThread != null) statsThread.interrupt();
        try {
            if (video != null) video.stop();
        } catch (Exception ignored) {
        }
        try {
            if (audio != null) audio.stop();
        } catch (Exception ignored) {
        }
        try {
            if (capture != null) capture.stop();
        } catch (Exception ignored) {
        }
        try {
            if (projection != null) projection.stop();
        } catch (Exception ignored) {
        }
        try {
            if (rtmp != null) rtmp.close();
        } catch (Exception ignored) {
        }
        if (renderer != null) renderer.release();
        try {
            if (wake != null && wake.isHeld()) wake.release();
        } catch (Exception ignored) {
        }
        video = null;
        audio = null;
        capture = null;
        projection = null;
        rtmp = null;
        wake = null;
    }

    @Override
    public void onDestroy() {
        if (active && !stopping) stopStream("Stream stop ho gayi", false);
        super.onDestroy();
    }
}
