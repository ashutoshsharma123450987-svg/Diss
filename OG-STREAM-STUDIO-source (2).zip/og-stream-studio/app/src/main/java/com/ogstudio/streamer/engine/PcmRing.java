package com.ogstudio.streamer.engine;

/** Thread-safe ring buffer of 16-bit samples. When full, the oldest samples are dropped. */
final class PcmRing {
    private final short[] buf;
    private int head;
    private int size;

    PcmRing(int capacity) {
        buf = new short[capacity];
    }

    synchronized void write(short[] src, int off, int n) {
        int cap = buf.length;
        if (n > cap) {
            off += n - cap;
            n = cap;
        }
        int over = size + n - cap;
        if (over > 0) {
            head = (head + over) % cap;
            size -= over;
        }
        int tail = (head + size) % cap;
        int first = Math.min(n, cap - tail);
        System.arraycopy(src, off, buf, tail, first);
        if (n > first) System.arraycopy(src, off + first, buf, 0, n - first);
        size += n;
    }

    /** Reads exactly n samples, or nothing (returns false) if fewer are available. */
    synchronized boolean read(short[] dst, int n) {
        if (size < n) return false;
        int cap = buf.length;
        int first = Math.min(n, cap - head);
        System.arraycopy(buf, head, dst, 0, first);
        if (n > first) System.arraycopy(buf, 0, dst, first, n - first);
        head = (head + n) % cap;
        size -= n;
        return true;
    }

    synchronized int size() {
        return size;
    }

    /** Throws away the oldest samples so that at most keep samples remain. */
    synchronized void trimTo(int keep) {
        if (size > keep) {
            int drop = size - keep;
            head = (head + drop) % buf.length;
            size = keep;
        }
    }
}
