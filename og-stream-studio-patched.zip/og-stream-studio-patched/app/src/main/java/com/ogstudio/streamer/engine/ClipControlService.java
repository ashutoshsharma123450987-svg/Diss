package com.ogstudio.streamer.engine;

import android.app.Service;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;

import com.ogstudio.streamer.model.Prefs;

import java.io.File;

/**
 * Bound service (Messenger) that OG CLIP STUDIO talks to. Protected by a signature permission in the manifest.
 *
 * Requests (what):  1 STATUS, 2 CLIP (arg1 = seconds), 3 SET_WINDOW (arg1 = seconds)
 * Replies   (what): 101 status bundle, 102 clip bundle (uri, durationMs, width, height, error)
 */
public class ClipControlService extends Service {
    public static final int MSG_STATUS = 1;
    public static final int MSG_CLIP = 2;
    public static final int MSG_SET_WINDOW = 3;
    public static final int MSG_STATUS_REPLY = 101;
    public static final int MSG_CLIP_REPLY = 102;

    private HandlerThread thread;
    private Messenger messenger;

    @Override
    public void onCreate() {
        super.onCreate();
        thread = new HandlerThread("og-clip-ipc");
        thread.start();
        messenger = new Messenger(new Handler(thread.getLooper()) {
            @Override
            public void handleMessage(Message m) {
                try {
                    switch (m.what) {
                        case MSG_STATUS:
                            reply(m, MSG_STATUS_REPLY, status());
                            break;
                        case MSG_SET_WINDOW:
                            setWindow(m.arg1);
                            reply(m, MSG_STATUS_REPLY, status());
                            break;
                        case MSG_CLIP:
                            reply(m, MSG_CLIP_REPLY, clip(m.arg1));
                            break;
                        default:
                            super.handleMessage(m);
                    }
                } catch (Throwable t) {
                    Bundle b = new Bundle();
                    b.putString("error", String.valueOf(t.getMessage()));
                    try {
                        reply(m, m.what == MSG_STATUS || m.what == MSG_SET_WINDOW ? MSG_STATUS_REPLY : MSG_CLIP_REPLY, b);
                    } catch (Throwable ignored) {
                    }
                }
            }
        });
    }

    @Override
    public IBinder onBind(Intent intent) {
        return messenger.getBinder();
    }

    @Override
    public void onDestroy() {
        if (thread != null) thread.quitSafely();
        super.onDestroy();
    }

    private static void reply(Message req, int what, Bundle data) throws RemoteException {
        if (req.replyTo == null) return;
        Message r = Message.obtain(null, what);
        r.setData(data);
        req.replyTo.send(r);
    }

    private Bundle status() {
        Bundle b = new Bundle();
        ReplayRing r = ReplayTap.ring;
        b.putBoolean("enabled", new Prefs(this).replayBuffer());
        b.putBoolean("live", StreamService.state == StreamService.LIVE);
        b.putBoolean("buffering", r != null && StreamService.state == StreamService.LIVE);
        b.putLong("bufferedMs", r == null ? 0 : r.bufferedUs() / 1000L);
        b.putLong("bufferedBytes", r == null ? 0 : r.bufferedBytes());
        b.putInt("windowSeconds", r == null ? new Prefs(this).replaySeconds() : r.windowSeconds());
        b.putInt("width", ReplayTap.width);
        b.putInt("height", ReplayTap.height);
        b.putInt("fps", ReplayTap.fps);
        b.putInt("kbps", ReplayTap.kbps);
        b.putBoolean("audio", ReplayTap.asc != null);
        return b;
    }

    private void setWindow(int seconds) {
        int s = Math.max(15, Math.min(180, seconds));
        new Prefs(this).setReplaySeconds(s);
        ReplayRing r = ReplayTap.ring;
        if (r != null) r.setWindowSeconds(s);
    }

    private Bundle clip(int seconds) {
        Bundle b = new Bundle();
        ReplayRing r = ReplayTap.ring;
        byte[] sps = ReplayTap.sps;
        byte[] pps = ReplayTap.pps;
        if (r == null) {
            b.putString("error", "Replay buffer is off. Turn it on in OG STREAM STUDIO settings and go live.");
            return b;
        }
        if (sps == null || pps == null) {
            b.putString("error", "Video is not ready yet.");
            return b;
        }
        ReplayRing.Snapshot snap = r.snapshot(Math.max(1, seconds) * 1000000L);
        if (snap == null) {
            b.putString("error", "Nothing buffered yet.");
            return b;
        }
        try {
            File f = ClipMuxer.write(this, snap, sps, pps, ReplayTap.asc, ReplayTap.width, ReplayTap.height);
            b.putString("uri", ClipProvider.uriFor(f).toString());
            b.putLong("durationMs", snap.durationUs() / 1000L);
            b.putInt("width", ReplayTap.width);
            b.putInt("height", ReplayTap.height);
            b.putBoolean("audio", ReplayTap.asc != null && !snap.audio.isEmpty());
        } catch (Exception e) {
            b.putString("error", "Could not write clip: " + e.getMessage());
        }
        return b;
    }
}
