package com.ogstudio.streamer.engine;

import android.content.Context;
import android.graphics.Bitmap;
import android.media.Image;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaExtractor;
import android.media.MediaFormat;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ShortBuffer;

/**
 * Plays the "STREAMING SOON" video (assets/brb.mp4) in a loop while BRB mode is on: the pictures go to
 * {@link #frame} (drawn inside the screen box) and the song goes into the audio mixer through a ring.
 * It only runs between start() and stop(), so it costs nothing during normal streaming.
 * Every part is optional: if the video or the sound cannot be decoded on a phone, the rest still works.
 */
final class BrbPlayer {
    /** Latest video picture, or null when BRB is off or the video cannot be shown. */
    static volatile Bitmap frame;

    private static final String ASSET = "brb.mp4";
    private static final String CACHE = "brb_v1.mp4";

    private final Context ctx;
    private final PcmRing musicRing;
    private int gen;

    BrbPlayer(Context ctx, PcmRing musicRing) {
        this.ctx = ctx.getApplicationContext();
        this.musicRing = musicRing;
    }

    private synchronized boolean alive(int g) {
        return g == gen;
    }

    synchronized void start() {
        final int g = ++gen;
        new Thread(new Runnable() {
            @Override
            public void run() {
                String path = ensureFile();
                if (path == null || !alive(g)) return;
                runVideo(path, g);
            }
        }, "og-brb-video").start();
        if (musicRing != null) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    String path = ensureFile();
                    if (path == null || !alive(g)) return;
                    runAudio(path, g);
                }
            }, "og-brb-audio").start();
        }
    }

    /** Returns at once; the player threads notice and shut themselves down. */
    synchronized void stop() {
        gen++;
        frame = null;
        if (musicRing != null) musicRing.trimTo(0);
    }

    private String ensureFile() {
        try {
            File f = new File(ctx.getCacheDir(), CACHE);
            if (f.exists() && f.length() > 0) return f.getPath();
            InputStream in = ctx.getAssets().open(ASSET);
            FileOutputStream out = new FileOutputStream(f);
            byte[] buf = new byte[32768];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            out.close();
            in.close();
            return f.getPath();
        } catch (Throwable t) {
            return null;
        }
    }

    private static int findTrack(MediaExtractor ex, String prefix) {
        for (int i = 0; i < ex.getTrackCount(); i++) {
            String mime = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME);
            if (mime != null && mime.startsWith(prefix)) return i;
        }
        return -1;
    }

    private static void sleepMs(long ms) throws InterruptedException {
        if (ms > 0) Thread.sleep(ms);
    }

    // ------------------------------------------------------------------ video

    private void runVideo(String path, int g) {
        MediaExtractor ex = null;
        MediaCodec dec = null;
        try {
            ex = new MediaExtractor();
            ex.setDataSource(path);
            int track = findTrack(ex, "video/");
            if (track < 0) return;
            ex.selectTrack(track);
            MediaFormat fmt = ex.getTrackFormat(track);
            dec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME));
            fmt.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible);
            dec.configure(fmt, null, null, 0);
            dec.start();

            Bitmap[] bmps = new Bitmap[3];
            int next = 0;
            int[] px = null;
            byte[] yb = null;
            byte[] ub = null;
            byte[] vb = null;
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            boolean inputDone = false;
            long startNs = -1;
            long basePts = 0;

            while (alive(g)) {
                if (!inputDone) {
                    int ii = dec.dequeueInputBuffer(5000);
                    if (ii >= 0) {
                        ByteBuffer ib = dec.getInputBuffer(ii);
                        int n = ex.readSampleData(ib, 0);
                        if (n < 0) {
                            dec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                            inputDone = true;
                        } else {
                            dec.queueInputBuffer(ii, 0, n, ex.getSampleTime(), 0);
                            ex.advance();
                        }
                    }
                }
                int oi = dec.dequeueOutputBuffer(info, 5000);
                if (oi < 0) continue;
                boolean end = (info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;
                if (info.size > 0 && alive(g)) {
                    if (startNs < 0) {
                        startNs = System.nanoTime();
                        basePts = info.presentationTimeUs;
                    }
                    long waitMs = (startNs + (info.presentationTimeUs - basePts) * 1000L - System.nanoTime()) / 1000000L;
                    if (waitMs > 0) sleepMs(Math.min(waitMs, 200));
                    if (waitMs > -80) { // skip the picture if we are far behind
                        Image img = dec.getOutputImage(oi);
                        if (img != null) {
                            try {
                                android.graphics.Rect cr = img.getCropRect();
                                int w = cr.width();
                                int h = cr.height();
                                Image.Plane[] p = img.getPlanes();
                                if (px == null || px.length != w * h) {
                                    px = new int[w * h];
                                    for (int i = 0; i < 3; i++) bmps[i] = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                                }
                                yb = fill(p[0].getBuffer(), yb);
                                ub = fill(p[1].getBuffer(), ub);
                                vb = fill(p[2].getBuffer(), vb);
                                MediaTools.yuvToArgb(yb, p[0].getRowStride(), ub, p[1].getRowStride(), p[1].getPixelStride(),
                                        vb, p[2].getRowStride(), p[2].getPixelStride(), w, h, px);
                                Bitmap b = bmps[next];
                                next = (next + 1) % 3;
                                b.setPixels(px, 0, w, 0, 0, w, h);
                                if (alive(g)) frame = b;
                            } finally {
                                img.close();
                            }
                        }
                    }
                }
                dec.releaseOutputBuffer(oi, false);
                if (end) { // loop the video
                    dec.flush();
                    ex.seekTo(0, MediaExtractor.SEEK_TO_CLOSEST_SYNC);
                    inputDone = false;
                    startNs = -1;
                }
            }
        } catch (Throwable t) {
            // the video cannot be shown on this phone: the built-in animation is used instead
        } finally {
            try {
                if (dec != null) {
                    dec.stop();
                    dec.release();
                }
            } catch (Throwable ignored) {
            }
            try {
                if (ex != null) ex.release();
            } catch (Throwable ignored) {
            }
            if (!alive(g)) frame = null;
        }
    }

    /** Copies a whole plane buffer into a (re-used) byte array. */
    private static byte[] fill(ByteBuffer b, byte[] reuse) {
        int n = b.remaining();
        if (reuse == null || reuse.length < n) reuse = new byte[n];
        b.get(reuse, 0, n);
        return reuse;
    }

    // ------------------------------------------------------------------ audio

    private void runAudio(String path, int g) {
        MediaExtractor ex = null;
        MediaCodec dec = null;
        try {
            ex = new MediaExtractor();
            ex.setDataSource(path);
            int track = findTrack(ex, "audio/");
            if (track < 0) return;
            ex.selectTrack(track);
            MediaFormat fmt = ex.getTrackFormat(track);
            dec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME));
            dec.configure(fmt, null, null, 0);
            dec.start();

            int srcRate = fmt.containsKey(MediaFormat.KEY_SAMPLE_RATE) ? fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE) : 44100;
            int ch = fmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT) ? fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT) : 2;
            MediaTools.Resampler rs = new MediaTools.Resampler(srcRate, AudioPipeline.SAMPLE_RATE);
            short[] in = new short[8192];
            short[] out = new short[rs.maxOut(8192) + 16];
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            boolean inputDone = false;
            long startNs = -1;
            long basePts = 0;

            while (alive(g)) {
                if (!inputDone) {
                    int ii = dec.dequeueInputBuffer(5000);
                    if (ii >= 0) {
                        ByteBuffer ib = dec.getInputBuffer(ii);
                        int n = ex.readSampleData(ib, 0);
                        if (n < 0) {
                            dec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                            inputDone = true;
                        } else {
                            dec.queueInputBuffer(ii, 0, n, ex.getSampleTime(), 0);
                            ex.advance();
                        }
                    }
                }
                int oi = dec.dequeueOutputBuffer(info, 5000);
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    MediaFormat of = dec.getOutputFormat();
                    if (of.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) ch = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                    if (of.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                        int r = of.getInteger(MediaFormat.KEY_SAMPLE_RATE);
                        if (r != srcRate) {
                            srcRate = r;
                            rs = new MediaTools.Resampler(srcRate, AudioPipeline.SAMPLE_RATE);
                        }
                    }
                    continue;
                }
                if (oi < 0) continue;
                boolean end = (info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;
                if (info.size > 0) {
                    if (startNs < 0) {
                        startNs = System.nanoTime();
                        basePts = info.presentationTimeUs;
                    }
                    // stay about 150 ms ahead of real time, no more (the ring is small)
                    long waitMs = (startNs + (info.presentationTimeUs - basePts) * 1000L - System.nanoTime()) / 1000000L - 150;
                    while (waitMs > 0 && alive(g)) {
                        sleepMs(Math.min(waitMs, 50));
                        waitMs -= 50;
                    }
                    if (alive(g)) {
                        ByteBuffer ob = dec.getOutputBuffer(oi);
                        ob.position(info.offset);
                        ob.limit(info.offset + info.size);
                        ShortBuffer sb = ob.order(java.nio.ByteOrder.nativeOrder()).asShortBuffer();
                        int total = sb.remaining();
                        while (total > 0 && alive(g)) {
                            int take = Math.min(total, (in.length / Math.max(1, ch)) * Math.max(1, ch));
                            sb.get(in, 0, take);
                            total -= take;
                            int frames = take / Math.max(1, ch);
                            int n = rs.process(in, frames, Math.max(1, ch), out);
                            musicRing.write(out, 0, n);
                        }
                    }
                }
                dec.releaseOutputBuffer(oi, false);
                if (end) { // loop the song
                    dec.flush();
                    ex.seekTo(0, MediaExtractor.SEEK_TO_CLOSEST_SYNC);
                    inputDone = false;
                    startNs = -1;
                }
            }
        } catch (Throwable t) {
            // no sound from the BRB video on this phone
        } finally {
            try {
                if (dec != null) {
                    dec.stop();
                    dec.release();
                }
            } catch (Throwable ignored) {
            }
            try {
                if (ex != null) ex.release();
            } catch (Throwable ignored) {
            }
        }
    }
}
