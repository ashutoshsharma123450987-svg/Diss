package com.ogstudio.streamer.render;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;

import com.ogstudio.streamer.model.Scene;
import com.ogstudio.streamer.model.Source;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

/**
 * Draws a scene onto any Canvas in logical canvas pixels. The editor and the live stream
 * use the same code, so what you see in the editor is what viewers get.
 * Not thread safe: use one instance per thread.
 */
public final class SceneRenderer {
    private final Context ctx;
    private final Map<String, Bitmap> images = new HashMap<String, Bitmap>();
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bmpPaint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
    private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Rect src = new Rect();
    private final RectF dst = new RectF();

    public SceneRenderer(Context c) {
        ctx = c.getApplicationContext();
    }

    public void release() {
        images.clear();
    }

    public Bitmap image(String file) {
        if (file == null || file.length() == 0) return null;
        Bitmap b = images.get(file);
        if (b == null) {
            b = BitmapFactory.decodeFile(new File(ctx.getFilesDir(), file).getPath());
            if (b != null) images.put(file, b);
        }
        return b;
    }

    public void forget(String file) {
        images.remove(file);
    }

    /** Bounds of a source in logical canvas pixels. */
    public RectF bounds(Source s) {
        switch (s.type) {
            case Source.TEXT: {
                prepareText(s);
                String[] lines = lines(s);
                float maxW = 1f;
                for (String l : lines) maxW = Math.max(maxW, textPaint.measureText(l));
                Paint.FontMetrics fm = textPaint.getFontMetrics();
                float lh = fm.descent - fm.ascent;
                float pad = s.box ? s.w * 0.3f : 0f;
                return new RectF(s.x, s.y, s.x + maxW + pad * 2, s.y + lh * lines.length + pad * 2);
            }
            case Source.IMAGE: {
                float ar = s.ar;
                Bitmap b = image(s.imageFile);
                if (b != null && b.getHeight() > 0) ar = b.getWidth() / (float) b.getHeight();
                return new RectF(s.x, s.y, s.x + s.w, s.y + s.w / ar);
            }
            default:
                return new RectF(s.x, s.y, s.x + s.w, s.y + s.w / s.ar);
        }
    }

    private static String[] lines(Source s) {
        String t = s.text == null || s.text.length() == 0 ? " " : s.text;
        return t.split("\n", -1);
    }

    private void prepareText(Source s) {
        textPaint.setTextSize(Math.max(4f, s.w));
        textPaint.setTypeface(Typeface.create(Typeface.DEFAULT, s.bold ? Typeface.BOLD : Typeface.NORMAL));
    }

    /**
     * Draws all layers.
     *
     * @param frame   latest screen capture or null (a placeholder is drawn then)
     * @param frameW  visible width of the frame inside the bitmap
     * @param frameH  visible height of the frame inside the bitmap
     */
    public void drawScene(Canvas c, Scene sc, Bitmap frame, int frameW, int frameH) {
        for (Source s : sc.sources) {
            switch (s.type) {
                case Source.SCREEN:
                    drawScreen(c, s, frame, frameW, frameH);
                    break;
                case Source.TEXT:
                    drawText(c, s);
                    break;
                default:
                    drawImage(c, s);
                    break;
            }
        }
    }

    private void drawScreen(Canvas c, Source s, Bitmap frame, int fw, int fh) {
        RectF r = bounds(s);
        if (frame != null && fw > 0 && fh > 0) {
            float far = fw / (float) fh;
            float dw;
            float dh;
            if (r.width() / r.height() > far) {
                dh = r.height();
                dw = dh * far;
            } else {
                dw = r.width();
                dh = dw / far;
            }
            dst.set(r.centerX() - dw / 2f, r.centerY() - dh / 2f, r.centerX() + dw / 2f, r.centerY() + dh / 2f);
            src.set(0, 0, fw, fh);
            c.drawBitmap(frame, src, dst, bmpPaint);
        } else {
            fillPaint.setStyle(Paint.Style.FILL);
            fillPaint.setColor(0xFF12306B);
            c.drawRect(r, fillPaint);
            fillPaint.setColor(0xFFFFFFFF);
            fillPaint.setTextAlign(Paint.Align.CENTER);
            fillPaint.setTextSize(Math.max(12f, Math.min(r.height() / 8f, 44f)));
            c.drawText("Screen capture", r.centerX(), r.centerY() + fillPaint.getTextSize() / 3f, fillPaint);
            fillPaint.setTextAlign(Paint.Align.LEFT);
        }
    }

    private void drawImage(Canvas c, Source s) {
        Bitmap b = image(s.imageFile);
        RectF r = bounds(s);
        if (b != null) {
            c.drawBitmap(b, null, r, bmpPaint);
        } else {
            fillPaint.setStyle(Paint.Style.FILL);
            fillPaint.setColor(0x55FFFFFF);
            c.drawRect(r, fillPaint);
        }
    }

    private void drawText(Canvas c, Source s) {
        prepareText(s);
        RectF r = bounds(s);
        float pad = s.box ? s.w * 0.3f : 0f;
        if (s.box) {
            fillPaint.setStyle(Paint.Style.FILL);
            fillPaint.setColor(0x99000000);
            float rad = s.w * 0.25f;
            c.drawRoundRect(r, rad, rad, fillPaint);
        }
        textPaint.setColor(s.color);
        if (!s.box) textPaint.setShadowLayer(Math.max(1f, s.w * 0.06f), 0, s.w * 0.03f, 0xCC000000);
        else textPaint.clearShadowLayer();
        Paint.FontMetrics fm = textPaint.getFontMetrics();
        float lh = fm.descent - fm.ascent;
        String[] ls = lines(s);
        float y = r.top + pad - fm.ascent;
        for (String l : ls) {
            c.drawText(l, r.left + pad, y, textPaint);
            y += lh;
        }
        textPaint.clearShadowLayer();
    }
}
