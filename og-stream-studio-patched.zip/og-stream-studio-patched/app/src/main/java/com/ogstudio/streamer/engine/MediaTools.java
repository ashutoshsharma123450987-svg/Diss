package com.ogstudio.streamer.engine;

/** Small pure-Java helpers for the BRB video: colour conversion and sample-rate conversion. */
final class MediaTools {
    private MediaTools() {
    }

    /**
     * Converts a planar YUV 4:2:0 picture (BT.709, limited range) to ARGB ints.
     * yPix, uPix and vPix are the byte distance between two neighbouring samples of that plane
     * (1 for planar, 2 for semi-planar layouts).
     */
    static void yuvToArgb(byte[] y, int yStride, byte[] u, int uStride, int uPix, byte[] v, int vStride, int vPix,
                          int w, int h, int[] out) {
        int o = 0;
        for (int row = 0; row < h; row++) {
            int yo = row * yStride;
            int uo = (row >> 1) * uStride;
            int vo = (row >> 1) * vStride;
            for (int col = 0; col < w; col++) {
                int yy = ((y[yo + col] & 0xff) - 16) * 298;
                int uu = (u[uo + (col >> 1) * uPix] & 0xff) - 128;
                int vv = (v[vo + (col >> 1) * vPix] & 0xff) - 128;
                int r = (yy + 459 * vv) >> 8;
                int g = (yy - 55 * uu - 136 * vv) >> 8;
                int b = (yy + 541 * uu) >> 8;
                if (r < 0) r = 0;
                else if (r > 255) r = 255;
                if (g < 0) g = 0;
                else if (g > 255) g = 255;
                if (b < 0) b = 0;
                else if (b > 255) b = 255;
                out[o++] = 0xFF000000 | (r << 16) | (g << 8) | b;
            }
        }
    }

    /** Streaming linear resampler to stereo. Keeps its position between calls, so there are no clicks. */
    static final class Resampler {
        private final double step;
        private double pos;
        private short prevL;
        private short prevR;

        Resampler(int srcRate, int dstRate) {
            step = srcRate / (double) dstRate;
        }

        /**
         * @param in     interleaved input samples
         * @param frames number of input frames
         * @param ch     input channels (1, 2 or more; only the first two are used)
         * @param out    output buffer (interleaved stereo), must be big enough
         * @return number of SHORTS written to out
         */
        int process(short[] in, int frames, int ch, short[] out) {
            if (frames <= 0) return 0;
            int n = 0;
            while (pos < frames) {
                int i0 = (int) pos;
                double fr = pos - i0;
                // index 0 of the virtual array is the previous frame, 1..frames are the new ones
                short l0 = i0 == 0 ? prevL : in[(i0 - 1) * ch];
                short r0 = i0 == 0 ? prevR : in[(i0 - 1) * ch + (ch > 1 ? 1 : 0)];
                short l1 = in[i0 * ch];
                short r1 = in[i0 * ch + (ch > 1 ? 1 : 0)];
                out[n++] = (short) (l0 + (l1 - l0) * fr);
                out[n++] = (short) (r0 + (r1 - r0) * fr);
                pos += step;
            }
            pos -= frames;
            prevL = in[(frames - 1) * ch];
            prevR = in[(frames - 1) * ch + (ch > 1 ? 1 : 0)];
            return n;
        }

        /** Upper bound of output shorts for a given number of input frames. */
        int maxOut(int frames) {
            return (int) (frames / step + 4) * 2;
        }
    }
}
