package com.ogstudio.streamer.ui;

import android.app.Activity;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.ogstudio.streamer.model.Prefs;
import com.ogstudio.streamer.model.Scene;

/** Stream URL / key, quality, audio and the other things you must set before going live. */
public class SettingsActivity extends Activity {
    private Prefs prefs;
    private EditText url;
    private EditText key;
    private Spinner aspect;
    private Spinner quality;
    private Spinner fps;
    private EditText bitrate;
    private Spinner audio;
    private Spinner orientation;
    private CheckBox software;
    private CheckBox micClean;
    private int lastQuality;

    private static final String[] ASPECTS = {"9:16 (portrait, phone)", "16:9 (landscape)"};
    private static final String[] QUALITIES = {"480p (halka, low-end phone ke liye)", "720p"};
    private static final String[] FPS = {"15", "20", "24", "30"};
    private static final int[] FPS_VALUES = {15, 20, 24, 30};
    private static final String[] AUDIO = {"Game audio + Mic", "Sirf game audio", "Sirf mic", "Koi awaaz nahi"};
    private static final int[] AUDIO_VALUES = {Prefs.AUDIO_BOTH, Prefs.AUDIO_GAME, Prefs.AUDIO_MIC, Prefs.AUDIO_OFF};
    private static final String[] ORIENT = {"Landscape (aadha lete hue)", "Portrait (seedha)"};

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = new Prefs(this);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Ui.BG);
        LinearLayout col = Ui.column(this);
        int pad = Ui.dp(this, 16);
        col.setPadding(pad, pad, pad, pad);
        scroll.addView(col, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        col.addView(Ui.label(this, "Settings", 22, Ui.TEXT, true));

        section(col, "Stream URL");
        url = edit(prefs.url(), false);
        col.addView(url, fullWidth());
        hint(col, "YouTube ke liye: rtmp://a.rtmp.youtube.com/live2");

        section(col, "Stream Key");
        key = edit(prefs.key(), true);
        col.addView(key, fullWidth());
        hint(col, "YouTube Studio > Go Live > Stream key. Ye key kisi ko mat dikhana.");

        section(col, "Canvas (stream ka size)");
        aspect = spinner(ASPECTS, prefs.canvasAspect());
        col.addView(aspect, fullWidth());
        hint(col, "Canvas badalne par scene reset ho jaata hai.");

        section(col, "Quality");
        quality = spinner(QUALITIES, prefs.quality());
        col.addView(quality, fullWidth());

        section(col, "FPS");
        int fpsIdx = 2;
        for (int i = 0; i < FPS_VALUES.length; i++) if (FPS_VALUES[i] == prefs.fps()) fpsIdx = i;
        fps = spinner(FPS, fpsIdx);
        col.addView(fps, fullWidth());

        section(col, "Bitrate (kbps)");
        bitrate = edit(String.valueOf(prefs.bitrateKbps()), false);
        bitrate.setInputType(InputType.TYPE_CLASS_NUMBER);
        col.addView(bitrate, fullWidth());
        hint(col, "480p ke liye 1000-1500, 720p ke liye 2000-3000. Net slow ho to kam rakho.");
        lastQuality = prefs.quality();
        quality.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                // only when the user really changed quality, not on the first automatic callback
                if (pos != lastQuality) {
                    lastQuality = pos;
                    bitrate.setText(pos == 0 ? "1200" : "2500");
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> p) {
            }
        });

        section(col, "Awaaz");
        int audioIdx = 0;
        for (int i = 0; i < AUDIO_VALUES.length; i++) if (AUDIO_VALUES[i] == prefs.audio()) audioIdx = i;
        audio = spinner(AUDIO, audioIdx);
        col.addView(audio, fullWidth());
        hint(col, "Game audio ke liye Android 10 ya upar chahiye.");

        micClean = new CheckBox(this);
        micClean.setText("Mic saaf (echo / shor hatao)");
        micClean.setTextColor(Ui.TEXT);
        micClean.setChecked(prefs.micClean());
        col.addView(micClean, Ui.lpMargins(this, ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0, 8, 0, 0));
        hint(col, "Agar phone ke speaker ki game awaaz mic me ghus kar chanchan sunai de to ON karo. Sabse achha upay: earphone lagao.");

        section(col, "Game kaise khelte ho");
        orientation = spinner(ORIENT, prefs.gameLandscape() ? 0 : 1);
        col.addView(orientation, fullWidth());
        hint(col, "Scene reset karne par screen box isi ke hisaab se banta hai.");

        software = new CheckBox(this);
        software.setText("Software drawing (agar stream me video kaali dikhe to ON karo)");
        software.setTextColor(Ui.TEXT);
        software.setChecked(prefs.softwareRender());
        col.addView(software, Ui.lpMargins(this, ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0, 16, 0, 0));

        Button save = Ui.button(this, "Save", Ui.ACCENT, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                save();
                finish();
            }
        });
        col.addView(save, Ui.lpMargins(this, ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 52), 0, 0, 24, 0, 0));

        setContentView(scroll);
    }

    private void section(LinearLayout col, String text) {
        TextView t = Ui.label(this, text, 14, Ui.ACCENT, true);
        col.addView(t, Ui.lpMargins(this, ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0, 18, 0, 4));
    }

    private void hint(LinearLayout col, String text) {
        col.addView(Ui.label(this, text, 12, Ui.MUTED, false));
    }

    private LinearLayout.LayoutParams fullWidth() {
        return Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0);
    }

    private EditText edit(String value, boolean secret) {
        EditText e = new EditText(this);
        e.setText(value);
        e.setTextColor(Ui.TEXT);
        e.setSingleLine(true);
        e.setBackground(Ui.rounded(this, Ui.PANEL, 8));
        e.setPadding(Ui.dp(this, 12), Ui.dp(this, 10), Ui.dp(this, 12), Ui.dp(this, 10));
        if (secret) {
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        } else {
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        }
        return e;
    }

    private Spinner spinner(String[] items, int selected) {
        Spinner s = new Spinner(this);
        s.setBackground(Ui.rounded(this, Ui.PANEL, 8));
        s.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, items));
        s.setSelection(selected);
        return s;
    }

    private void save() {
        int br = 1200;
        try {
            br = Integer.parseInt(bitrate.getText().toString().trim());
        } catch (NumberFormatException ignored) {
        }
        br = Math.max(300, Math.min(8000, br));
        boolean gameLandscape = orientation.getSelectedItemPosition() == 0;
        int newAspect = aspect.getSelectedItemPosition() == 1 ? Scene.LANDSCAPE : Scene.PORTRAIT;
        boolean aspectChanged = newAspect != prefs.canvasAspect();

        prefs.save(url.getText().toString().trim(), key.getText().toString().trim(),
                quality.getSelectedItemPosition(), FPS_VALUES[fps.getSelectedItemPosition()], br,
                AUDIO_VALUES[audio.getSelectedItemPosition()], gameLandscape, software.isChecked());
        prefs.setCanvasAspect(newAspect);
        prefs.setMicClean(micClean.isChecked());
        if (aspectChanged) {
            prefs.saveScene(Scene.createDefault(newAspect, prefs.defaultGameAr()));
            Toast.makeText(this, "Canvas badla, scene reset ho gaya", Toast.LENGTH_SHORT).show();
        }
    }
}
