package com.ogstudio.streamer.engine;

import android.content.Context;

import com.ogstudio.streamer.model.Prefs;

/**
 * Hook between the stream encoders and the replay buffer for OG CLIP STUDIO.
 * Does nothing unless the "Replay buffer" setting is ON. The encoded frames are only referenced, never copied,
 * so the extra cost while streaming is one small object per frame.
 */
final class ReplayTap {
    private ReplayTap() {}

    static final long MAX_BYTES = 192L * 1024 * 1024;

    static volatile ReplayRing ring;
    static volatile byte[] sps;
    static volatile byte[] pps;
    static volatile byte[] asc;
    static volatile int width;
    static volatile int height;
    static volatile int fps;
    static volatile int kbps;
    static volatile boolean wantAudio;

    static void start(Context c, int w, int h, int f, int kb, boolean audio) {
        stop();
        Prefs p = new Prefs(c);
        if (!p.replayBuffer()) return;
        width = w;
        height = h;
        fps = f;
        kbps = kb;
        wantAudio = audio;
        ring = new ReplayRing(p.replaySeconds(), MAX_BYTES);
    }

    static void stop() {
        ring = null;
        sps = null;
        pps = null;
        asc = null;
    }

    static boolean active() {
        return ring != null;
    }

    static void videoConfig(byte[] s, byte[] p) {
        sps = s;
        pps = p;
    }

    static void audioConfig(byte[] a) {
        asc = a;
    }

    /** Called with every encoded video frame BEFORE the network drop logic, so the buffer stays complete. */
    static void video(byte[] data, boolean key, long ptsUs) {
        ReplayRing r = ring;
        if (r != null) r.addVideo(data, ptsUs, key);
    }

    static void audio(byte[] data, long ptsUs) {
        ReplayRing r = ring;
        if (r != null) r.addAudio(data, ptsUs);
    }
}
