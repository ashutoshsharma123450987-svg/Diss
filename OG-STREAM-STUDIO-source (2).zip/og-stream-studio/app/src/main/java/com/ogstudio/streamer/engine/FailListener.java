package com.ogstudio.streamer.engine;

/** Called when some part of the pipeline dies and the stream must stop. */
interface FailListener {
    void onFail(String reason);
}
