package com.ogstudio.streamer.engine;

import android.content.Context;
import android.media.MediaCodec;
import android.media.MediaFormat;
import android.media.MediaMuxer;

import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.List;

/** Writes a ReplayRing snapshot to an MP4 in cache/clips by copying the encoded samples (no re-encode). */
final class ClipMuxer {
    private ClipMuxer() {}

    static File dir(Context c) {
        File d = new File(c.getCacheDir(), "clips");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    /** Deletes clip files older than 30 minutes (the clip app copies them right away). */
    static void cleanOld(Context c) {
        File[] fs = dir(c).listFiles();
        if (fs == null) return;
        long limit = System.currentTimeMillis() - 30L * 60L * 1000L;
        for (File f : fs) if (f.lastModified() < limit) f.delete();
    }

    private static byte[] withStartCode(byte[] nal) {
        byte[] r = new byte[nal.length + 4];
        r[3] = 1;
        System.arraycopy(nal, 0, r, 4, nal.length);
        return r;
    }

    static File write(Context c, ReplayRing.Snapshot snap, byte[] sps, byte[] pps, byte[] asc,
                      int w, int h) throws IOException {
        cleanOld(c);
        File out = new File(dir(c), "clip_" + System.currentTimeMillis() + ".mp4");
        MediaMuxer mux = new MediaMuxer(out.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
        boolean started = false;
        try {
            MediaFormat vf = MediaFormat.createVideoFormat("video/avc", w, h);
            vf.setByteBuffer("csd-0", ByteBuffer.wrap(withStartCode(sps)));
            vf.setByteBuffer("csd-1", ByteBuffer.wrap(withStartCode(pps)));
            int vTrack = mux.addTrack(vf);
            boolean withAudio = asc != null && !snap.audio.isEmpty();
            int aTrack = -1;
            if (withAudio) {
                MediaFormat af = MediaFormat.createAudioFormat("audio/mp4a-latm", AudioPipelineRate.SAMPLE_RATE, 2);
                af.setByteBuffer("csd-0", ByteBuffer.wrap(asc));
                aTrack = mux.addTrack(af);
            }
            mux.start();
            started = true;

            long base = snap.startUs();
            List<ReplayRing.Sample> v = snap.video;
            List<ReplayRing.Sample> a = snap.audio;
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            int vi = 0;
            int ai = 0;
            while (vi < v.size() || (withAudio && ai < a.size())) {
                boolean takeVideo;
                if (vi >= v.size()) takeVideo = false;
                else if (!withAudio || ai >= a.size()) takeVideo = true;
                else takeVideo = v.get(vi).ptsUs <= a.get(ai).ptsUs;
                ReplayRing.Sample s = takeVideo ? v.get(vi++) : a.get(ai++);
                int flags = (takeVideo && s.key) ? MediaCodec.BUFFER_FLAG_KEY_FRAME : 0;
                info.set(0, s.data.length, Math.max(0L, s.ptsUs - base), flags);
                mux.writeSampleData(takeVideo ? vTrack : aTrack, ByteBuffer.wrap(s.data), info);
            }
        } finally {
            try {
                if (started) mux.stop();
            } catch (Exception ignored) {
            }
            try {
                mux.release();
            } catch (Exception ignored) {
            }
        }
        return out;
    }

    /** Sample rate used by AudioPipeline (kept in one place for the muxer header). */
    static final class AudioPipelineRate {
        static final int SAMPLE_RATE = 48000;
    }
}
