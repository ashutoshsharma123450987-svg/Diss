package com.ogstudio.streamer.model;

import org.json.JSONException;
import org.json.JSONObject;

/** One layer on the canvas: the phone screen, a text, or an image. Units are logical canvas pixels. */
public final class Source {
    public static final int SCREEN = 0;
    public static final int TEXT = 1;
    public static final int IMAGE = 2;

    public final int type;
    public float x;
    public float y;
    /** Width for screen and image. Text size for text. */
    public float w = 200f;
    /** Width / height for screen and image. */
    public float ar = 16f / 9f;
    public boolean locked;
    public String text = "";
    public String imageFile = "";
    public int color = 0xFFFFFFFF;
    public boolean bold = true;
    public boolean box;

    public Source(int type) {
        this.type = type;
    }

    public String label() {
        switch (type) {
            case SCREEN:
                return "Screen capture";
            case TEXT: {
                String t = text.replace('\n', ' ');
                if (t.length() > 18) t = t.substring(0, 18) + "...";
                return "Text: " + t;
            }
            default:
                return "Image";
        }
    }

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("type", type);
        o.put("x", x);
        o.put("y", y);
        o.put("w", w);
        o.put("ar", ar);
        o.put("locked", locked);
        o.put("text", text);
        o.put("image", imageFile);
        o.put("color", color);
        o.put("bold", bold);
        o.put("box", box);
        return o;
    }

    public static Source fromJson(JSONObject o) {
        Source s = new Source(o.optInt("type", SCREEN));
        s.x = (float) o.optDouble("x", 0);
        s.y = (float) o.optDouble("y", 0);
        s.w = (float) o.optDouble("w", 200);
        s.ar = (float) o.optDouble("ar", 16.0 / 9.0);
        s.locked = o.optBoolean("locked", false);
        s.text = o.optString("text", "");
        s.imageFile = o.optString("image", "");
        s.color = o.optInt("color", 0xFFFFFFFF);
        s.bold = o.optBoolean("bold", true);
        s.box = o.optBoolean("box", false);
        if (s.ar <= 0.05f) s.ar = 1f;
        return s;
    }
}
