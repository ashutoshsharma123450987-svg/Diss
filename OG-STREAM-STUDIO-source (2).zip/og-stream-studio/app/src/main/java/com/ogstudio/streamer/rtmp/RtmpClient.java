package com.ogstudio.streamer.rtmp;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

import javax.net.ssl.SSLSocketFactory;

/**
 * Small RTMP publisher (plain RTMP and RTMPS). No third party code.
 * Usage: connect(), sendMetadata(), then push config + frames. Frames are queued
 * and written by an internal thread, so callers never block on the network.
 */
public final class RtmpClient {

    public interface Listener {
        void onError(String reason);
    }

    private static final int T_SET_CHUNK = 1;
    private static final int T_ACK = 3;
    private static final int T_USER = 4;
    private static final int T_WIN_ACK = 5;
    private static final int T_AUDIO = 8;
    private static final int T_VIDEO = 9;
    private static final int T_DATA = 18;
    private static final int T_CMD = 20;

    private static final int CS_CONTROL = 2;
    private static final int CS_CMD = 3;
    private static final int CS_AUDIO = 4;
    private static final int CS_DATA = 5;
    private static final int CS_VIDEO = 6;

    private static final class Msg {
        final int csid;
        final int type;
        final long ts;
        final byte[] data;

        Msg(int csid, int type, long ts, byte[] data) {
            this.csid = csid;
            this.type = type;
            this.ts = ts;
            this.data = data;
        }
    }

    private static final class Chunk {
        int len;
        int type;
        int msid;
        byte[] buf;
        int got;
        boolean ext;
    }

    private final boolean tls;
    private final String host;
    private final int port;
    private final String app;
    private final String tcUrl;
    private final String key;

    private Socket socket;
    private InputStream in;
    private OutputStream out;
    private final Object writeLock = new Object();
    private final Map<Integer, Chunk> chunks = new HashMap<Integer, Chunk>();

    private int inChunk = 128;
    private volatile int outChunk = 128;
    private long totalIn;
    private long lastAckAt;
    private long ackWindow = 2500000L;
    private int streamId;

    private final LinkedBlockingQueue<Msg> queue = new LinkedBlockingQueue<Msg>();
    private final AtomicLong queuedBytes = new AtomicLong();
    private final AtomicLong bytesSent = new AtomicLong();
    private volatile boolean closed;
    private volatile Listener listener;
    private Thread sender;
    private Thread reader;

    public RtmpClient(String url, String streamKey) throws IOException {
        String u = url == null ? "" : url.trim();
        int s = u.indexOf("://");
        if (s < 0) throw new IOException("Stream URL galat hai (rtmp://... hona chahiye)");
        String scheme = u.substring(0, s).toLowerCase();
        tls = scheme.equals("rtmps");
        if (!tls && !scheme.equals("rtmp")) throw new IOException("Sirf rtmp:// ya rtmps:// chalta hai");
        String rest = u.substring(s + 3);
        int slash = rest.indexOf('/');
        if (slash < 0) throw new IOException("Stream URL me app name nahi hai (jaise /live2)");
        String hostPort = rest.substring(0, slash);
        String path = rest.substring(slash + 1);
        while (path.endsWith("/")) path = path.substring(0, path.length() - 1);
        int colon = hostPort.lastIndexOf(':');
        if (colon > 0) {
            host = hostPort.substring(0, colon);
            try {
                port = Integer.parseInt(hostPort.substring(colon + 1));
            } catch (NumberFormatException e) {
                throw new IOException("Stream URL ka port galat hai");
            }
        } else {
            host = hostPort;
            port = tls ? 443 : 1935;
        }
        String k = streamKey == null ? "" : streamKey.trim();
        if (k.length() == 0) {
            int ls = path.lastIndexOf('/');
            if (ls < 0) throw new IOException("Stream key khali hai");
            k = path.substring(ls + 1);
            path = path.substring(0, ls);
        }
        if (host.length() == 0 || path.length() == 0) throw new IOException("Stream URL galat hai");
        app = path;
        key = k;
        tcUrl = scheme + "://" + hostPort + "/" + app;
    }

    public void setListener(Listener l) {
        listener = l;
    }

    public long getQueuedBytes() {
        return queuedBytes.get();
    }

    public long getBytesSent() {
        return bytesSent.get();
    }

    public boolean isClosed() {
        return closed;
    }

    // ------------------------------------------------------------------ connect

    /** Blocks until the server accepted the publish request. */
    public void connect(int timeoutMs) throws IOException {
        try {
            Socket plain = new Socket();
            plain.connect(new InetSocketAddress(host, port), timeoutMs);
            plain.setTcpNoDelay(true);
            plain.setSoTimeout(timeoutMs);
            if (tls) {
                socket = ((SSLSocketFactory) SSLSocketFactory.getDefault()).createSocket(plain, host, port, true);
            } else {
                socket = plain;
            }
            in = new BufferedInputStream(socket.getInputStream(), 16384);
            out = new BufferedOutputStream(socket.getOutputStream(), 65536);

            handshake();

            byte[] connectCmd = new Amf0.Writer()
                    .string("connect").number(1)
                    .objectStart()
                    .prop("app", app)
                    .prop("type", "nonprivate")
                    .prop("flashVer", "FMLE/3.0 (compatible; FMSc/1.0)")
                    .prop("tcUrl", tcUrl)
                    .prop("fpad", false)
                    .prop("capabilities", 15)
                    .prop("audioCodecs", 3191)
                    .prop("videoCodecs", 252)
                    .prop("videoFunction", 1)
                    .objectEnd()
                    .toByteArray();
            writeMessage(CS_CMD, T_CMD, 0, 0, connectCmd, 0, connectCmd.length);
            awaitResult(1);

            // bigger chunks = less overhead
            byte[] cs = new byte[]{0, 0, 0x10, 0};
            writeMessage(CS_CONTROL, T_SET_CHUNK, 0, 0, cs, 0, 4);
            outChunk = 4096;

            byte[] rel = new Amf0.Writer().string("releaseStream").number(2).nul().string(key).toByteArray();
            writeMessage(CS_CMD, T_CMD, 0, 0, rel, 0, rel.length);
            byte[] fcp = new Amf0.Writer().string("FCPublish").number(3).nul().string(key).toByteArray();
            writeMessage(CS_CMD, T_CMD, 0, 0, fcp, 0, fcp.length);
            byte[] cre = new Amf0.Writer().string("createStream").number(4).nul().toByteArray();
            writeMessage(CS_CMD, T_CMD, 0, 0, cre, 0, cre.length);
            List<Object> res = awaitResult(4);
            if (res.size() < 4 || !(res.get(3) instanceof Double)) {
                throw new IOException("Server ne stream id nahi diya");
            }
            streamId = ((Double) res.get(3)).intValue();

            byte[] pub = new Amf0.Writer().string("publish").number(5).nul().string(key).string("live").toByteArray();
            writeMessage(CS_CMD, T_CMD, streamId, 0, pub, 0, pub.length);
            awaitPublishStart();

            socket.setSoTimeout(0);
        } catch (IOException e) {
            closeQuietly();
            throw e;
        }

        sender = new Thread(new Runnable() {
            @Override
            public void run() {
                senderLoop();
            }
        }, "rtmp-send");
        reader = new Thread(new Runnable() {
            @Override
            public void run() {
                readerLoop();
            }
        }, "rtmp-read");
        sender.start();
        reader.start();
    }

    private void handshake() throws IOException {
        byte[] c1 = new byte[1536];
        new SecureRandom().nextBytes(c1);
        for (int i = 0; i < 8; i++) c1[i] = 0; // time + zero
        out.write(3);
        out.write(c1);
        out.flush();
        int s0 = rb();
        if (s0 != 3) throw new IOException("RTMP handshake fail (version " + s0 + ")");
        byte[] s1 = new byte[1536];
        rf(s1, 0, s1.length);
        out.write(s1); // C2 = echo of S1
        out.flush();
        byte[] s2 = new byte[1536];
        rf(s2, 0, s2.length);
    }

    private List<Object> awaitResult(int txn) throws IOException {
        while (true) {
            Msg m = readMessage();
            List<Object> cmd = handle(m);
            if (cmd == null || cmd.isEmpty() || !(cmd.get(0) instanceof String)) continue;
            String name = (String) cmd.get(0);
            if ("_result".equals(name) && cmd.size() > 1 && cmd.get(1) instanceof Double
                    && ((Double) cmd.get(1)).intValue() == txn) {
                return cmd;
            }
            if ("_error".equals(name)) {
                throw new IOException("Server error: " + describe(cmd));
            }
            if ("onStatus".equals(name)) {
                String code = statusCode(cmd);
                if (code != null && isFailure(code)) throw new IOException("Server: " + code);
            }
        }
    }

    private void awaitPublishStart() throws IOException {
        while (true) {
            Msg m = readMessage();
            List<Object> cmd = handle(m);
            if (cmd == null || cmd.isEmpty() || !(cmd.get(0) instanceof String)) continue;
            String name = (String) cmd.get(0);
            if ("onStatus".equals(name)) {
                String code = statusCode(cmd);
                if (code == null) continue;
                if ("NetStream.Publish.Start".equals(code)) return;
                if (isFailure(code)) {
                    throw new IOException("Server: " + code + " (stream key ya URL check karo)");
                }
            } else if ("_error".equals(name)) {
                throw new IOException("Server error: " + describe(cmd));
            }
        }
    }

    private static boolean isFailure(String code) {
        return code.contains("Failed") || code.contains("Rejected") || code.contains("BadName")
                || code.contains("Closed") || code.contains("AppShutdown");
    }

    @SuppressWarnings("unchecked")
    private static String statusCode(List<Object> cmd) {
        for (Object o : cmd) {
            if (o instanceof Map) {
                Object c = ((Map<String, Object>) o).get("code");
                if (c instanceof String) return (String) c;
            }
        }
        return null;
    }

    private static String describe(List<Object> cmd) {
        StringBuilder sb = new StringBuilder();
        for (Object o : cmd) sb.append(o).append(' ');
        return sb.toString().trim();
    }

    // ------------------------------------------------------------------ public send API

    public void sendMetadata(int width, int height, int fps, int videoKbps, int audioKbps,
                             int sampleRate, boolean stereo) {
        byte[] d = new Amf0.Writer()
                .string("@setDataFrame").string("onMetaData")
                .ecmaArrayStart(11)
                .prop("duration", 0)
                .prop("width", width)
                .prop("height", height)
                .prop("videodatarate", videoKbps)
                .prop("framerate", fps)
                .prop("videocodecid", 7)
                .prop("audiodatarate", audioKbps)
                .prop("audiosamplerate", sampleRate)
                .prop("audiosamplesize", 16)
                .prop("stereo", stereo)
                .prop("audiocodecid", 10)
                .objectEnd()
                .toByteArray();
        enqueue(new Msg(CS_DATA, T_DATA, 0, d));
    }

    public void sendVideoConfig(byte[] sps, byte[] pps) {
        byte[] rec = H264Util.avcConfig(sps, pps);
        byte[] p = new byte[5 + rec.length];
        p[0] = 0x17; // key frame, AVC
        p[1] = 0; // sequence header
        System.arraycopy(rec, 0, p, 5, rec.length);
        enqueue(new Msg(CS_VIDEO, T_VIDEO, 0, p));
    }

    /** annexB holds one access unit (start code separated NAL units). */
    public void sendVideoFrame(byte[] annexB, int off, int len, boolean keyFrame, long tsMs) {
        List<H264Util.Nal> nals = H264Util.split(annexB, off, len);
        int size = 5;
        for (H264Util.Nal n : nals) size += 4 + n.len;
        if (size == 5) return;
        byte[] p = new byte[size];
        p[0] = (byte) (keyFrame ? 0x17 : 0x27);
        p[1] = 1; // NALU
        int pos = 5;
        for (H264Util.Nal n : nals) {
            p[pos++] = (byte) (n.len >> 24);
            p[pos++] = (byte) (n.len >> 16);
            p[pos++] = (byte) (n.len >> 8);
            p[pos++] = (byte) n.len;
            System.arraycopy(annexB, n.off, p, pos, n.len);
            pos += n.len;
        }
        enqueue(new Msg(CS_VIDEO, T_VIDEO, tsMs, p));
    }

    public void sendAudioConfig(byte[] asc) {
        byte[] p = new byte[2 + asc.length];
        p[0] = (byte) 0xAF;
        p[1] = 0;
        System.arraycopy(asc, 0, p, 2, asc.length);
        enqueue(new Msg(CS_AUDIO, T_AUDIO, 0, p));
    }

    public void sendAudioFrame(byte[] aac, int off, int len, long tsMs) {
        byte[] p = new byte[2 + len];
        p[0] = (byte) 0xAF;
        p[1] = 1;
        System.arraycopy(aac, off, p, 2, len);
        enqueue(new Msg(CS_AUDIO, T_AUDIO, tsMs, p));
    }

    private void enqueue(Msg m) {
        if (closed) return;
        queuedBytes.addAndGet(m.data.length);
        queue.add(m);
    }

    public void close() {
        closed = true;
        closeQuietly();
        if (sender != null) sender.interrupt();
        if (reader != null) reader.interrupt();
    }

    private void closeQuietly() {
        try {
            if (socket != null) socket.close();
        } catch (IOException ignored) {
        }
    }

    private void fail(String reason) {
        if (closed) return;
        closed = true;
        closeQuietly();
        Listener l = listener;
        if (l != null) l.onError(reason);
    }

    // ------------------------------------------------------------------ threads

    private void senderLoop() {
        try {
            while (!closed) {
                Msg m = queue.poll(500, TimeUnit.MILLISECONDS);
                if (m == null) continue;
                try {
                    writeMessage(m.csid, m.type, streamId, m.ts, m.data, 0, m.data.length);
                    bytesSent.addAndGet(m.data.length);
                } finally {
                    queuedBytes.addAndGet(-m.data.length);
                }
            }
        } catch (IOException e) {
            fail("Network error: " + e.getMessage());
        } catch (InterruptedException ignored) {
        }
    }

    private void readerLoop() {
        try {
            while (!closed) {
                Msg m = readMessage();
                List<Object> cmd = handle(m);
                if (cmd != null && !cmd.isEmpty() && "onStatus".equals(cmd.get(0))) {
                    String code = statusCode(cmd);
                    if (code != null && isFailure(code)) {
                        fail("Server: " + code);
                        return;
                    }
                }
                maybeAck();
            }
        } catch (IOException e) {
            fail("Connection lost: " + e.getMessage());
        }
    }

    // ------------------------------------------------------------------ protocol

    private void maybeAck() throws IOException {
        if (totalIn - lastAckAt >= ackWindow) {
            lastAckAt = totalIn;
            byte[] b = new byte[4];
            b[0] = (byte) (totalIn >> 24);
            b[1] = (byte) (totalIn >> 16);
            b[2] = (byte) (totalIn >> 8);
            b[3] = (byte) totalIn;
            writeMessage(CS_CONTROL, T_ACK, 0, 0, b, 0, 4);
        }
    }

    /** Handles protocol messages. Returns the decoded command for AMF0 commands, else null. */
    private List<Object> handle(Msg m) throws IOException {
        switch (m.type) {
            case T_SET_CHUNK:
                if (m.data.length >= 4) {
                    int n = ((m.data[0] & 0x7f) << 24) | ((m.data[1] & 0xff) << 16)
                            | ((m.data[2] & 0xff) << 8) | (m.data[3] & 0xff);
                    if (n > 0) inChunk = n;
                }
                return null;
            case T_WIN_ACK:
                if (m.data.length >= 4) {
                    long w = ((long) (m.data[0] & 0xff) << 24) | ((m.data[1] & 0xff) << 16)
                            | ((m.data[2] & 0xff) << 8) | (m.data[3] & 0xff);
                    if (w > 0) ackWindow = w;
                }
                return null;
            case T_USER:
                if (m.data.length >= 6 && m.data[0] == 0 && m.data[1] == 6) {
                    // ping request -> ping response
                    byte[] r = new byte[6];
                    r[0] = 0;
                    r[1] = 7;
                    System.arraycopy(m.data, 2, r, 2, 4);
                    writeMessage(CS_CONTROL, T_USER, 0, 0, r, 0, 6);
                }
                return null;
            case T_CMD:
                return Amf0.decode(m.data, 0, m.data.length);
            default:
                return null;
        }
    }

    private void writeMessage(int csid, int type, int msid, long ts, byte[] data, int off, int len)
            throws IOException {
        long t = ts & 0xFFFFFFFFL;
        boolean ext = t >= 0xFFFFFFL;
        synchronized (writeLock) {
            int pos = 0;
            boolean first = true;
            int chunkSize = outChunk;
            while (first || pos < len) {
                int n = Math.min(chunkSize, len - pos);
                if (first) {
                    out.write(csid & 0x3f); // fmt 0
                    w24(ext ? 0xFFFFFF : (int) t);
                    w24(len);
                    out.write(type);
                    out.write(msid & 0xff);
                    out.write((msid >> 8) & 0xff);
                    out.write((msid >> 16) & 0xff);
                    out.write((msid >> 24) & 0xff);
                } else {
                    out.write(0xC0 | (csid & 0x3f)); // fmt 3
                }
                if (ext) w32(t);
                if (n > 0) out.write(data, off + pos, n);
                pos += n;
                first = false;
            }
            out.flush();
        }
    }

    private void w24(int v) throws IOException {
        out.write((v >> 16) & 0xff);
        out.write((v >> 8) & 0xff);
        out.write(v & 0xff);
    }

    private void w32(long v) throws IOException {
        out.write((int) (v >> 24) & 0xff);
        out.write((int) (v >> 16) & 0xff);
        out.write((int) (v >> 8) & 0xff);
        out.write((int) v & 0xff);
    }

    private Msg readMessage() throws IOException {
        while (true) {
            int b = rb();
            int fmt = b >> 6;
            int csid = b & 0x3f;
            if (csid == 0) {
                csid = 64 + rb();
            } else if (csid == 1) {
                int lo = rb();
                int hi = rb();
                csid = 64 + lo + (hi << 8);
            }
            Chunk cs = chunks.get(csid);
            if (cs == null) {
                cs = new Chunk();
                chunks.put(csid, cs);
            }
            if (fmt != 3) {
                int ts = r24();
                if (fmt <= 1) {
                    cs.len = r24();
                    cs.type = rb();
                }
                if (fmt == 0) {
                    cs.msid = rb() | (rb() << 8) | (rb() << 16) | (rb() << 24);
                }
                cs.ext = ts == 0xFFFFFF;
                if (cs.ext) r32();
                cs.buf = new byte[cs.len];
                cs.got = 0;
            } else {
                if (cs.ext) r32();
                if (cs.buf == null) {
                    cs.buf = new byte[cs.len];
                    cs.got = 0;
                }
            }
            int n = Math.min(inChunk, cs.len - cs.got);
            if (n > 0) {
                rf(cs.buf, cs.got, n);
                cs.got += n;
            }
            if (cs.got >= cs.len) {
                Msg m = new Msg(csid, cs.type, 0, cs.buf);
                cs.buf = null;
                cs.got = 0;
                return m;
            }
        }
    }

    private int rb() throws IOException {
        int b = in.read();
        if (b < 0) throw new IOException("connection closed by server");
        totalIn++;
        return b;
    }

    private void rf(byte[] buf, int off, int len) throws IOException {
        int done = 0;
        while (done < len) {
            int r = in.read(buf, off + done, len - done);
            if (r < 0) throw new IOException("connection closed by server");
            done += r;
        }
        totalIn += len;
    }

    private int r24() throws IOException {
        return (rb() << 16) | (rb() << 8) | rb();
    }

    private long r32() throws IOException {
        return ((long) rb() << 24) | (rb() << 16) | (rb() << 8) | rb();
    }
}
