package com.ogstudio.streamer.model;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.DisplayMetrics;

/** All saved settings plus the saved scene. */
public final class Prefs {
    public static final int AUDIO_OFF = 0;
    public static final int AUDIO_MIC = 1;
    public static final int AUDIO_GAME = 2;
    public static final int AUDIO_BOTH = 3;

    private static final String FILE = "og_stream_studio";

    private final Context ctx;
    private final SharedPreferences sp;

    public Prefs(Context c) {
        ctx = c.getApplicationContext();
        sp = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    public String url() {
        return sp.getString("url", "rtmp://a.rtmp.youtube.com/live2");
    }

    public String key() {
        return sp.getString("key", "");
    }

    /** 0 = 480p, 1 = 720p. */
    public int quality() {
        return sp.getInt("quality", 0);
    }

    public int fps() {
        return sp.getInt("fps", 24);
    }

    public int bitrateKbps() {
        return sp.getInt("bitrate", quality() == 0 ? 1200 : 2500);
    }

    public int audio() {
        return sp.getInt("audio", AUDIO_BOTH);
    }

    public boolean gameLandscape() {
        return sp.getBoolean("gameLandscape", true);
    }

    public boolean softwareRender() {
        return sp.getBoolean("swRender", false);
    }

    public void save(String url, String key, int quality, int fps, int bitrate, int audio,
                     boolean gameLandscape, boolean swRender) {
        sp.edit()
                .putString("url", url)
                .putString("key", key)
                .putInt("quality", quality)
                .putInt("fps", fps)
                .putInt("bitrate", bitrate)
                .putInt("audio", audio)
                .putBoolean("gameLandscape", gameLandscape)
                .putBoolean("swRender", swRender)
                .apply();
    }

    /** Output video width / height in pixels for the given scene. */
    public int[] outputSize(Scene sc) {
        int shortSide = quality() == 0 ? 480 : 720;
        int longSide = quality() == 0 ? 848 : 1280;
        return sc.aspect == Scene.PORTRAIT ? new int[]{shortSide, longSide} : new int[]{longSide, shortSide};
    }

    public float defaultGameAr() {
        DisplayMetrics dm = ctx.getResources().getDisplayMetrics();
        float a = Math.max(dm.widthPixels, dm.heightPixels) / (float) Math.min(dm.widthPixels, dm.heightPixels);
        return gameLandscape() ? a : 1f / a;
    }

    public int canvasAspect() {
        return sp.getInt("aspect", Scene.PORTRAIT);
    }

    public void setCanvasAspect(int aspect) {
        sp.edit().putInt("aspect", aspect).apply();
    }

    public Scene loadScene() {
        Scene sc = null;
        String j = sp.getString("scene", null);
        if (j != null) sc = Scene.fromJson(j);
        if (sc == null || sc.aspect != canvasAspect() || sc.firstScreen() == null) {
            sc = Scene.createDefault(canvasAspect(), defaultGameAr());
            saveScene(sc);
        }
        return sc;
    }

    public void saveScene(Scene sc) {
        sp.edit().putString("scene", sc.toJson()).apply();
    }
}
