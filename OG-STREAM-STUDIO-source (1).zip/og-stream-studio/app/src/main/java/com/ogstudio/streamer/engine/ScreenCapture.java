package com.ogstudio.streamer.engine;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.DisplayMetrics;
import android.view.Display;

import java.nio.ByteBuffer;

/**
 * Captures the phone screen with MediaProjection into a Bitmap that the render loop draws
 * inside the "Screen capture" box. The capture size follows the box size, so a small box
 * costs less CPU. If the phone rotates, the capture is resized automatically.
 */
final class ScreenCapture {
    /** Guards bitmap, frameW and frameH. */
    final Object lock = new Object();
    Bitmap bitmap;
    int frameW;
    int frameH;
    /** Part of the bitmap that really shows the phone screen (the rest is black bars). Guarded by lock. */
    final Rect crop = new Rect();

    private final Context ctx;
    private final MediaProjection projection;
    private final float boxW;
    private final float boxH;
    private final boolean landscape;
    private final DisplayManager displayManager;

    private HandlerThread thread;
    private Handler handler;
    private ImageReader reader;
    private VirtualDisplay display;
    private int longSide;
    private int shortSide;
    /** Current screen size including rotation, refreshed about once a second. */
    private volatile int curW;
    private volatile int curH;
    private int dpi;
    private ByteBuffer scratch;
    private Runnable onStopped;
    private volatile boolean stopped;

    private final MediaProjection.Callback projectionCallback = new MediaProjection.Callback() {
        @Override
        public void onStop() {
            Runnable r = onStopped;
            if (!stopped && r != null) r.run();
        }
    };

    private final DisplayManager.DisplayListener displayListener = new DisplayManager.DisplayListener() {
        @Override
        public void onDisplayAdded(int displayId) {
        }

        @Override
        public void onDisplayRemoved(int displayId) {
        }

        @Override
        public void onDisplayChanged(int displayId) {
            if (displayId == Display.DEFAULT_DISPLAY && handler != null) handler.post(resizeTask);
        }
    };

    private final Runnable resizeTask = new Runnable() {
        @Override
        public void run() {
            resizeIfNeeded();
        }
    };

    /** Checks the screen size every second as well, in case the rotation event is missed. */
    private final Runnable pollTask = new Runnable() {
        @Override
        public void run() {
            if (stopped || handler == null) return;
            resizeIfNeeded();
            handler.postDelayed(this, 1000);
        }
    };

    private final ImageReader.OnImageAvailableListener imageListener = new ImageReader.OnImageAvailableListener() {
        @Override
        public void onImageAvailable(ImageReader r) {
            onImage(r);
        }
    };

    ScreenCapture(Context ctx, MediaProjection projection, float boxWidthPx, float boxHeightPx, boolean gameLandscape) {
        this.landscape = gameLandscape;
        this.ctx = ctx.getApplicationContext();
        this.projection = projection;
        this.boxW = boxWidthPx;
        this.boxH = boxHeightPx;
        this.displayManager = (DisplayManager) this.ctx.getSystemService(Context.DISPLAY_SERVICE);
    }

    void setOnStopped(Runnable r) {
        onStopped = r;
    }

    void start() {
        thread = new HandlerThread("og-capture");
        thread.start();
        handler = new Handler(thread.getLooper());
        projection.registerCallback(projectionCallback, handler);

        DisplayMetrics m = realMetrics();
        curW = m.widthPixels;
        curH = m.heightPixels;
        longSide = Math.max(curW, curH);
        shortSide = Math.min(curW, curH);
        dpi = m.densityDpi;
        int[] size = captureSize();
        reader = ImageReader.newInstance(size[0], size[1], PixelFormat.RGBA_8888, 2);
        reader.setOnImageAvailableListener(imageListener, handler);
        display = projection.createVirtualDisplay("OGStreamCapture", size[0], size[1], dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, handler);
        displayManager.registerDisplayListener(displayListener, handler);
        handler.postDelayed(pollTask, 1000);
    }

    void stop() {
        stopped = true;
        if (handler != null) handler.removeCallbacks(pollTask);
        try {
            displayManager.unregisterDisplayListener(displayListener);
        } catch (Exception ignored) {
        }
        try {
            projection.unregisterCallback(projectionCallback);
        } catch (Exception ignored) {
        }
        try {
            if (display != null) display.release();
        } catch (Exception ignored) {
        }
        try {
            if (reader != null) reader.close();
        } catch (Exception ignored) {
        }
        if (thread != null) thread.quitSafely();
        synchronized (lock) {
            if (bitmap != null) bitmap.recycle();
            bitmap = null;
        }
    }

    private DisplayMetrics realMetrics() {
        Display d = displayManager.getDisplay(Display.DEFAULT_DISPLAY);
        DisplayMetrics m = new DisplayMetrics();
        d.getRealMetrics(m);
        return m;
    }

    /**
     * The capture size is chosen ONCE, in the shape of the game (landscape or portrait, from Settings),
     * fitted into the box and never bigger than the real screen. It is never resized afterwards:
     * resizing a running capture left the picture tiny in a corner on some phones. If the phone
     * rotates, Android fits the picture inside the capture by itself and onImage() crops the bars.
     */
    private int[] captureSize() {
        int rw = landscape ? longSide : shortSide;
        int rh = landscape ? shortSide : longSide;
        float far = rw / (float) rh;
        float dw;
        float dh;
        if (boxW / boxH > far) {
            dh = boxH;
            dw = dh * far;
        } else {
            dw = boxW;
            dh = dw / far;
        }
        float s = Math.min(1f, Math.min(rw / dw, rh / dh));
        dw *= s;
        dh *= s;
        int w = Math.max(64, ((int) dw) & ~1);
        int h = Math.max(64, ((int) dh) & ~1);
        return new int[]{w, h};
    }

    /** Only reads the current screen size (for cropping). It never touches the capture itself. */
    private void resizeIfNeeded() {
        if (stopped) return;
        try {
            DisplayMetrics m = realMetrics();
            curW = m.widthPixels;
            curH = m.heightPixels;
        } catch (Exception ignored) {
        }
    }

    /** Finds the rectangle inside the frame that holds the screen picture, without the letterbox bars. */
    private void computeCrop(int w, int h) {
        int cw = curW;
        int ch = curH;
        if (cw <= 0 || ch <= 0) {
            crop.set(0, 0, w, h);
            return;
        }
        float car = cw / (float) ch;
        float far = w / (float) h;
        if (Math.abs(car - far) / far < 0.03f) {
            crop.set(0, 0, w, h);
        } else if (car > far) {
            int nh = Math.max(2, Math.round(w / car) & ~1);
            int y = ((h - nh) / 2) & ~1;
            crop.set(0, y, w, Math.min(h, y + nh));
        } else {
            int nw = Math.max(2, Math.round(h * car) & ~1);
            int x = ((w - nw) / 2) & ~1;
            crop.set(x, 0, Math.min(w, x + nw), h);
        }
    }

    private void onImage(ImageReader r) {
        Image img = null;
        try {
            img = r.acquireLatestImage();
            if (img == null || stopped) return;
            Image.Plane plane = img.getPlanes()[0];
            ByteBuffer buf = plane.getBuffer();
            int pixelStride = plane.getPixelStride();
            int bw = plane.getRowStride() / pixelStride;
            int w = img.getWidth();
            int h = img.getHeight();
            int need = bw * h * 4;
            buf.rewind();
            if (buf.remaining() < need) {
                if (scratch == null || scratch.capacity() < need) scratch = ByteBuffer.allocateDirect(need);
                scratch.clear();
                scratch.put(buf);
                scratch.limit(need);
                scratch.position(0);
                buf = scratch;
            }
            synchronized (lock) {
                if (stopped) return;
                if (bitmap == null || bitmap.getWidth() != bw || bitmap.getHeight() != h) {
                    if (bitmap != null) bitmap.recycle();
                    bitmap = Bitmap.createBitmap(bw, h, Bitmap.Config.ARGB_8888);
                }
                bitmap.copyPixelsFromBuffer(buf);
                frameW = w;
                frameH = h;
                computeCrop(w, h);
            }
        } catch (Exception ignored) {
            // skip this frame
        } finally {
            if (img != null) img.close();
        }
    }
}
