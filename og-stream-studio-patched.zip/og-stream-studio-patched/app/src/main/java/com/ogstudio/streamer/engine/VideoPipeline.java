package com.ogstudio.streamer.engine;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.Surface;

import com.ogstudio.streamer.render.SceneRenderer;
import com.ogstudio.streamer.rtmp.H264Util;
import com.ogstudio.streamer.rtmp.RtmpClient;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Draws the scene on the encoder's input surface at a steady frame rate, and sends the
 * encoded H.264 frames to the RTMP client. If the network is slow it lowers the bitrate
 * and drops frames instead of letting the stream fall behind.
 */
final class VideoPipeline {
    private static final int MIN_KBPS = 250;

    private final StreamConfig cfg;
    private final RtmpClient rtmp;
    private final ScreenCapture capture;
    private final SceneRenderer renderer;
    private final long t0Us;
    private final FailListener fail;

    final AtomicInteger framesSent = new AtomicInteger();
    final AtomicInteger framesDropped = new AtomicInteger();

    private MediaCodec encoder;
    private Surface surface;
    private Thread renderThread;
    private Thread drainThread;
    private volatile boolean running;
    private boolean useHardwareCanvas;
    private boolean configSent;
    private boolean dropUntilKey;
    private long lastTsMs;
    private volatile int currentKbps;
    private long lastAdjust;
    // Automatic fps safety: if the phone cannot draw frames fast enough, the frame rate is lowered.
    private static final int[] FPS_STEPS = {15, 20, 24, 30, 60};
    private volatile int renderFps;
    private volatile int renderedCount;
    private volatile int lateCount;
    private int badSecs;
    private int goodSecs;

    VideoPipeline(StreamConfig cfg, RtmpClient rtmp, ScreenCapture capture, SceneRenderer renderer,
                  long t0Us, FailListener fail) {
        this.cfg = cfg;
        this.rtmp = rtmp;
        this.capture = capture;
        this.renderer = renderer;
        this.t0Us = t0Us;
        this.fail = fail;
        this.currentKbps = cfg.videoKbps;
        this.renderFps = cfg.fps;
    }

    int currentKbps() {
        return currentKbps;
    }

    void start() throws IOException {
        encoder = createEncoder();
        surface = encoder.createInputSurface();
        encoder.start();
        useHardwareCanvas = Build.VERSION.SDK_INT >= 23 && !cfg.softwareRender;
        running = true;
        drainThread = new Thread(new Runnable() {
            @Override
            public void run() {
                drainLoop();
            }
        }, "og-video-drain");
        renderThread = new Thread(new Runnable() {
            @Override
            public void run() {
                renderLoop();
            }
        }, "og-render");
        drainThread.start();
        renderThread.start();
    }

    void stop() {
        running = false;
        join(renderThread);
        join(drainThread);
        try {
            if (encoder != null) {
                encoder.stop();
                encoder.release();
            }
        } catch (Exception ignored) {
        }
        if (surface != null) surface.release();
    }

    private static void join(Thread t) {
        if (t == null || t == Thread.currentThread()) return;
        try {
            t.join(1500);
        } catch (InterruptedException ignored) {
        }
    }

    private MediaCodec createEncoder() throws IOException {
        Exception last = null;
        for (int attempt = 0; attempt < 3; attempt++) {
            MediaCodec c = null;
            try {
                MediaFormat f = MediaFormat.createVideoFormat("video/avc", cfg.outW, cfg.outH);
                f.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
                f.setInteger(MediaFormat.KEY_BIT_RATE, cfg.videoKbps * 1000);
                f.setInteger(MediaFormat.KEY_FRAME_RATE, cfg.fps);
                f.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2);
                if (attempt == 0) {
                    f.setInteger(MediaFormat.KEY_BITRATE_MODE, MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_CBR);
                    f.setInteger(MediaFormat.KEY_PROFILE, MediaCodecInfo.CodecProfileLevel.AVCProfileBaseline);
                } else if (attempt == 1) {
                    f.setInteger(MediaFormat.KEY_BITRATE_MODE, MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR);
                }
                c = MediaCodec.createEncoderByType("video/avc");
                c.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
                return c;
            } catch (Exception e) {
                last = e;
                if (c != null) {
                    try {
                        c.release();
                    } catch (Exception ignored) {
                    }
                }
            }
        }
        throw new IOException("Video encoder start nahi hua: " + (last == null ? "" : last.getMessage()));
    }

    // ------------------------------------------------------------------ rendering

    private void renderLoop() {
        long next = System.nanoTime();
        float sx = cfg.scaleX();
        float sy = cfg.scaleY();
        int lw = cfg.scene.logicalW();
        int lh = cfg.scene.logicalH();
        // The whole draw + post happens under this lock, so the capture thread cannot
        // change the screen bitmap while the GPU is still reading it.
        Object frameLock = capture != null ? capture.lock : new Object();
        while (running) {
            synchronized (frameLock) {
                Canvas c = null;
                try {
                    c = useHardwareCanvas ? surface.lockHardwareCanvas() : surface.lockCanvas(null);
                } catch (Throwable t) {
                    if (useHardwareCanvas) {
                        useHardwareCanvas = false; // some phones cannot do this, use the normal canvas
                        continue;
                    }
                    fail.onFail("Video draw error: " + t.getMessage());
                    return;
                }
                if (c != null) {
                    try {
                        renderer.setBrb(StreamService.brb, System.nanoTime() / 1000000L);
                        Bitmap bf = BrbPlayer.frame != null ? BrbPlayer.frame : BrbPlayer.poster;
                        renderer.setBrbBitmap(bf, BrbPlayer.failed);
                        c.drawColor(Color.BLACK);
                        c.save();
                        c.scale(sx, sy);
                        c.clipRect(0, 0, lw, lh);
                        if (capture != null) {
                            renderer.drawScene(c, cfg.scene, capture.bitmap, capture.frameW, capture.frameH, capture.crop);
                        } else {
                            renderer.drawScene(c, cfg.scene, null, 0, 0);
                        }
                        c.restore();
                    } catch (Throwable t) {
                        // keep streaming even if one frame fails to draw
                    }
                    try {
                        surface.unlockCanvasAndPost(c);
                    } catch (Throwable t) {
                        if (running) fail.onFail("Video draw error: " + t.getMessage());
                        return;
                    }
                }
            }
            long periodNs = 1000000000L / Math.max(5, renderFps);
            renderedCount++;
            next += periodNs;
            long sleep = next - System.nanoTime();
            if (sleep > 0) {
                try {
                    Thread.sleep(sleep / 1000000L, (int) (sleep % 1000000L));
                } catch (InterruptedException e) {
                    return;
                }
            } else {
                lateCount++;
                if (sleep < -periodNs * 4) next = System.nanoTime();
            }
        }
    }

    // ------------------------------------------------------------------ encoded output

    private void drainLoop() {
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        while (running) {
            int idx;
            try {
                idx = encoder.dequeueOutputBuffer(info, 20000);
            } catch (Exception e) {
                if (running) fail.onFail("Video encoder error: " + e.getMessage());
                return;
            }
            if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                try {
                    MediaFormat f = encoder.getOutputFormat();
                    ByteBuffer b0 = f.getByteBuffer("csd-0");
                    ByteBuffer b1 = f.getByteBuffer("csd-1");
                    if (b0 != null && b1 != null) {
                        byte[] all = new byte[b0.remaining() + b1.remaining()];
                        int n0 = b0.remaining();
                        b0.get(all, 0, n0);
                        b1.get(all, n0, b1.remaining());
                        extractConfig(all);
                    }
                } catch (Exception ignored) {
                }
                continue;
            }
            if (idx < 0) continue;
            try {
                ByteBuffer out = encoder.getOutputBuffer(idx);
                if (out != null && info.size > 0) {
                    byte[] data = new byte[info.size];
                    out.position(info.offset);
                    out.limit(info.offset + info.size);
                    out.get(data);
                    if ((info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                        extractConfig(data);
                    } else {
                        boolean key = (info.flags & MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0;
                        handleFrame(data, key, info.presentationTimeUs);
                    }
                }
            } finally {
                try {
                    encoder.releaseOutputBuffer(idx, false);
                } catch (Exception ignored) {
                }
            }
        }
    }

    private void extractConfig(byte[] annexB) {
        if (configSent) return;
        List<H264Util.Nal> nals = H264Util.split(annexB, 0, annexB.length);
        byte[] sps = null;
        byte[] pps = null;
        for (H264Util.Nal n : nals) {
            if (n.type == 7 && sps == null) sps = Arrays.copyOfRange(annexB, n.off, n.off + n.len);
            if (n.type == 8 && pps == null) pps = Arrays.copyOfRange(annexB, n.off, n.off + n.len);
        }
        if (sps != null && pps != null && sps.length >= 4) {
            rtmp.sendVideoConfig(sps, pps);
            ReplayTap.videoConfig(sps, pps); // OG CLIP STUDIO replay buffer
            configSent = true;
        }
    }

    private void handleFrame(byte[] data, boolean key, long ptsUs) {
        if (!configSent && key) extractConfig(data); // some encoders put SPS/PPS inside the first key frame
        if (!configSent) return;
        // OG CLIP STUDIO: keep every encoded frame, before the network drop logic below
        ReplayTap.video(data, key, ptsUs);

        long q = rtmp.getQueuedBytes();
        long bytesPerSec = currentKbps * 125L;
        if (q > bytesPerSec * 25L) {
            fail.onFail("Internet bahut slow hai, stream band karni padi");
            return;
        }
        if (dropUntilKey) {
            if (!key || q > bytesPerSec * 3L / 2L) {
                framesDropped.incrementAndGet();
                return;
            }
            dropUntilKey = false;
        } else if (q > bytesPerSec * 3L) {
            dropUntilKey = true;
            framesDropped.incrementAndGet();
            requestKeyFrame();
            return;
        }

        long ts = Math.max(0, (ptsUs - t0Us) / 1000L);
        if (ts < lastTsMs) ts = lastTsMs;
        lastTsMs = ts;
        rtmp.sendVideoFrame(data, 0, data.length, key, ts);
        framesSent.incrementAndGet();
    }

    private void requestKeyFrame() {
        try {
            Bundle b = new Bundle();
            b.putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0);
            encoder.setParameters(b);
        } catch (Exception ignored) {
        }
    }

    /** Called about once a second. Lowers the bitrate when the network is slow, raises it back later. */
    void tick() {
        adjustFps();
        long now = SystemClock.elapsedRealtime();
        long q = rtmp.getQueuedBytes();
        long bytesPerSec = currentKbps * 125L;
        if (q > bytesPerSec) {
            if (now - lastAdjust > 3000 && currentKbps > MIN_KBPS) {
                setBitrate(Math.max(MIN_KBPS, (int) (currentKbps * 0.75f)));
                lastAdjust = now;
            }
        } else if (q < bytesPerSec / 4 && currentKbps < cfg.videoKbps && now - lastAdjust > 8000) {
            setBitrate(Math.min(cfg.videoKbps, (int) (currentKbps * 1.15f) + 1));
            lastAdjust = now;
        }
    }

    private void adjustFps() {
        int r = renderedCount;
        int l = lateCount;
        renderedCount = 0;
        lateCount = 0;
        if (r <= 0) return;
        if (l * 100 / r > 40) {
            badSecs++;
            goodSecs = 0;
        } else {
            badSecs = 0;
            if (l == 0) goodSecs++;
        }
        int cur = renderFps;
        if (badSecs >= 3 && cur > 15) {
            int lower = FPS_STEPS[0];
            for (int s : FPS_STEPS) if (s < cur) lower = s;
            renderFps = lower;
            badSecs = 0;
        } else if (goodSecs >= 40 && cur < cfg.fps) {
            int higher = cfg.fps;
            for (int i = FPS_STEPS.length - 1; i >= 0; i--) if (FPS_STEPS[i] > cur && FPS_STEPS[i] <= cfg.fps) higher = FPS_STEPS[i];
            renderFps = higher;
            goodSecs = 0;
        }
    }

    /** Frame rate the picture is really drawn at right now (may be lower than the setting). */
    int activeFps() {
        return renderFps;
    }

    private void setBitrate(int kbps) {
        try {
            Bundle b = new Bundle();
            b.putInt(MediaCodec.PARAMETER_KEY_VIDEO_BITRATE, kbps * 1000);
            encoder.setParameters(b);
            currentKbps = kbps;
        } catch (Exception ignored) {
        }
    }
}
