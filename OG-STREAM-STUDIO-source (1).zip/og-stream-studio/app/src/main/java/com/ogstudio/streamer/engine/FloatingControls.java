package com.ogstudio.streamer.engine;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import com.ogstudio.streamer.model.Prefs;

/**
 * Small LIVE bubble on top of the game. Tap it to open a panel with the stream controls:
 * mic / game mute, volume sliders and Stop. Drag it to move it. Needs the "Display over other
 * apps" permission. Everything here runs on the main thread.
 */
final class FloatingControls {
    private final Context ctx;
    private final WindowManager wm;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final float dp;

    private FrameLayout root;
    private TextView bubble;
    private LinearLayout panel;
    private TextView info;
    private TextView micBtn;
    private TextView gameBtn;
    private TextView stopBtn;
    private SeekBar micBar;
    private SeekBar gameBar;
    private WindowManager.LayoutParams lp;
    private boolean expanded;
    private boolean shown;
    private long stopArmedAt;

    FloatingControls(Context ctx) {
        this.ctx = ctx.getApplicationContext();
        this.wm = (WindowManager) this.ctx.getSystemService(Context.WINDOW_SERVICE);
        this.dp = this.ctx.getResources().getDisplayMetrics().density;
    }

    private int px(float v) {
        return Math.round(v * dp);
    }

    void show() {
        main.post(new Runnable() {
            @Override
            public void run() {
                try {
                    build();
                    shown = true;
                    main.postDelayed(refresh, 500);
                } catch (Throwable t) {
                    shown = false; // no permission or the phone refused: the stream goes on without the bubble
                }
            }
        });
    }

    void hide() {
        main.post(new Runnable() {
            @Override
            public void run() {
                shown = false;
                main.removeCallbacks(refresh);
                try {
                    if (root != null) wm.removeView(root);
                } catch (Throwable ignored) {
                }
                root = null;
            }
        });
    }

    private GradientDrawable bg(int color, float radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(px(radiusDp));
        return d;
    }

    private void build() {
        root = new FrameLayout(ctx);

        bubble = new TextView(ctx);
        bubble.setGravity(Gravity.CENTER);
        bubble.setTextColor(Color.WHITE);
        bubble.setTextSize(11);
        bubble.setText("LIVE");
        bubble.setBackground(bg(0xCCE53935, 24));
        root.addView(bubble, new FrameLayout.LayoutParams(px(52), px(34)));

        panel = new LinearLayout(ctx);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackground(bg(0xE6121212, 12));
        panel.setPadding(px(10), px(8), px(10), px(10));
        panel.setVisibility(View.GONE);

        LinearLayout head = new LinearLayout(ctx);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        info = new TextView(ctx);
        info.setTextColor(Color.WHITE);
        info.setTextSize(12);
        head.addView(info, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        TextView min = label("—", 0x33FFFFFF);
        min.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setExpanded(false);
            }
        });
        head.addView(min, new LinearLayout.LayoutParams(px(36), px(30)));
        panel.addView(head);
        attachDrag(head);

        LinearLayout row = new LinearLayout(ctx);
        row.setOrientation(LinearLayout.HORIZONTAL);
        micBtn = label("Mic", 0xFF2E7D32);
        micBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                StreamService.micMuted = !StreamService.micMuted;
                update();
            }
        });
        gameBtn = label("Game", 0xFF2E7D32);
        gameBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                StreamService.brb = !StreamService.brb;
                update();
            }
        });
        LinearLayout.LayoutParams a = new LinearLayout.LayoutParams(0, px(36), 1f);
        a.rightMargin = px(4);
        LinearLayout.LayoutParams b = new LinearLayout.LayoutParams(0, px(36), 1f);
        b.leftMargin = px(4);
        row.addView(micBtn, a);
        row.addView(gameBtn, b);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        rp.topMargin = px(6);
        panel.addView(row, rp);

        micBar = bar(true);
        gameBar = bar(false);
        panel.addView(caption("Mic volume"));
        panel.addView(micBar);
        panel.addView(caption("Game volume"));
        panel.addView(gameBar);

        TextView chat = new TextView(ctx);
        chat.setTextColor(0xFF9E9E9E);
        chat.setTextSize(11);
        chat.setText("YouTube chat yahan aayegi (Google login jodne ke baad).");
        chat.setPadding(0, px(6), 0, px(6));
        panel.addView(chat);

        stopBtn = label("STOP", 0xFFC62828);
        stopBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                long now = SystemClock.elapsedRealtime();
                if (now - stopArmedAt < 3000) {
                    Intent i = new Intent(ctx, StreamService.class);
                    i.setAction(StreamService.ACTION_STOP);
                    ctx.startService(i);
                } else {
                    stopArmedAt = now;
                    update();
                }
            }
        });
        panel.addView(stopBtn, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, px(40)));

        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(px(230), FrameLayout.LayoutParams.WRAP_CONTENT);
        root.addView(panel, pp);
        attachDrag(bubble);

        lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = px(8);
        lp.y = px(90);
        wm.addView(root, lp);
        update();
    }

    private TextView label(String text, int color) {
        TextView t = new TextView(ctx);
        t.setText(text);
        t.setTextColor(Color.WHITE);
        t.setTextSize(13);
        t.setGravity(Gravity.CENTER);
        t.setBackground(bg(color, 8));
        return t;
    }

    private TextView caption(String text) {
        TextView t = new TextView(ctx);
        t.setText(text);
        t.setTextColor(0xFFBDBDBD);
        t.setTextSize(11);
        t.setPadding(0, px(6), 0, 0);
        return t;
    }

    private SeekBar bar(final boolean isMic) {
        SeekBar s = new SeekBar(ctx);
        s.setMax(200);
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                if (!fromUser) return;
                if (isMic) StreamService.micGain = progress / 100f;
                else StreamService.gameGain = progress / 100f;
            }

            @Override
            public void onStartTrackingTouch(SeekBar sb) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar sb) {
                Prefs p = new Prefs(ctx);
                if (isMic) p.setMicVolume(sb.getProgress());
                else p.setGameVolume(sb.getProgress());
            }
        });
        return s;
    }

    private void setExpanded(boolean on) {
        expanded = on;
        bubble.setVisibility(on ? View.GONE : View.VISIBLE);
        panel.setVisibility(on ? View.VISIBLE : View.GONE);
        if (on) {
            micBar.setProgress(Math.round(StreamService.micGain * 100f));
            gameBar.setProgress(Math.round(StreamService.gameGain * 100f));
        }
        update();
        try {
            wm.updateViewLayout(root, lp);
        } catch (Throwable ignored) {
        }
    }

    /** Dragging moves the whole window; a short tap on the bubble opens the panel. */
    private void attachDrag(final View handle) {
        handle.setOnTouchListener(new View.OnTouchListener() {
            private float downX;
            private float downY;
            private int startX;
            private int startY;
            private boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = e.getRawX();
                        downY = e.getRawY();
                        startX = lp.x;
                        startY = lp.y;
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - downX;
                        float dy = e.getRawY() - downY;
                        if (Math.abs(dx) > px(6) || Math.abs(dy) > px(6)) moved = true;
                        if (moved) {
                            lp.x = Math.max(0, startX + (int) dx);
                            lp.y = Math.max(0, startY + (int) dy);
                            try {
                                wm.updateViewLayout(root, lp);
                            } catch (Throwable ignored) {
                            }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved && v == bubble) setExpanded(true);
                        return true;
                    default:
                        return true;
                }
            }
        });
    }

    private void update() {
        if (root == null) return;
        long secs = StreamService.liveSinceMs > 0 ? (SystemClock.elapsedRealtime() - StreamService.liveSinceMs) / 1000 : 0;
        String t = String.format("%02d:%02d", secs / 60, secs % 60);
        bubble.setText(StreamService.brb ? "BRB" : (StreamService.micMuted ? "MIC OFF" : t));
        bubble.setBackground(bg(StreamService.brb ? 0xCCF9A825 : (StreamService.micMuted ? 0xCC616161 : 0xCCE53935), 24));
        info.setText(t + "   " + StreamService.curKbps + " kbps   " + StreamService.curFps + " fps");
        boolean micOff = StreamService.micMuted || StreamService.brb;
        micBtn.setText(StreamService.brb ? "Mic (BRB)" : (StreamService.micMuted ? "Mic OFF" : "Mic ON"));
        micBtn.setBackground(bg(micOff ? 0xFF616161 : 0xFF2E7D32, 8));
        gameBtn.setText(StreamService.brb ? "Game OFF" : "Game ON");
        gameBtn.setBackground(bg(StreamService.brb ? 0xFFF9A825 : 0xFF2E7D32, 8));
        boolean armed = SystemClock.elapsedRealtime() - stopArmedAt < 3000;
        stopBtn.setText(armed ? "Pakka band karu? Phir dabao" : "STOP");
    }

    private final Runnable refresh = new Runnable() {
        @Override
        public void run() {
            if (!shown) return;
            update();
            main.postDelayed(this, 1000);
        }
    };
}
