package com.ogstudio.streamer.rtmp;

import java.io.ByteArrayOutputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Minimal AMF0 encoder / decoder, just enough for the RTMP publish handshake. */
public final class Amf0 {
    private static final Charset UTF8 = Charset.forName("UTF-8");

    private Amf0() {}

    /** Builds an AMF0 byte sequence. */
    public static final class Writer {
        private final ByteArrayOutputStream out = new ByteArrayOutputStream();

        public Writer number(double v) {
            out.write(0x00);
            long bits = Double.doubleToLongBits(v);
            for (int i = 7; i >= 0; i--) out.write((int) (bits >> (i * 8)) & 0xff);
            return this;
        }

        public Writer bool(boolean v) {
            out.write(0x01);
            out.write(v ? 1 : 0);
            return this;
        }

        public Writer string(String s) {
            out.write(0x02);
            writeUtf(s);
            return this;
        }

        public Writer nul() {
            out.write(0x05);
            return this;
        }

        public Writer objectStart() {
            out.write(0x03);
            return this;
        }

        public Writer ecmaArrayStart(int count) {
            out.write(0x08);
            out.write((count >> 24) & 0xff);
            out.write((count >> 16) & 0xff);
            out.write((count >> 8) & 0xff);
            out.write(count & 0xff);
            return this;
        }

        public Writer objectEnd() {
            out.write(0x00);
            out.write(0x00);
            out.write(0x09);
            return this;
        }

        // property helpers (key + value)
        public Writer prop(String key, double v) { key(key); return number(v); }
        public Writer prop(String key, boolean v) { key(key); return bool(v); }
        public Writer prop(String key, String v) { key(key); return string(v); }

        private void key(String k) { writeUtf(k); }

        private void writeUtf(String s) {
            byte[] b = s.getBytes(UTF8);
            out.write((b.length >> 8) & 0xff);
            out.write(b.length & 0xff);
            out.write(b, 0, b.length);
        }

        public byte[] toByteArray() { return out.toByteArray(); }
    }

    /** Decodes every top level AMF0 value in the buffer. Objects become Map, arrays List. */
    public static List<Object> decode(byte[] d, int off, int len) {
        List<Object> res = new ArrayList<Object>();
        int[] p = {off};
        int end = off + len;
        while (p[0] < end) {
            try {
                res.add(readValue(d, p, end));
            } catch (RuntimeException e) {
                break;
            }
        }
        return res;
    }

    private static Object readValue(byte[] d, int[] p, int end) {
        if (p[0] >= end) throw new IllegalStateException("eof");
        int marker = d[p[0]++] & 0xff;
        switch (marker) {
            case 0x00: {
                long bits = 0;
                for (int i = 0; i < 8; i++) bits = (bits << 8) | (d[p[0]++] & 0xff);
                return Double.longBitsToDouble(bits);
            }
            case 0x01:
                return d[p[0]++] != 0;
            case 0x02:
                return readString(d, p, 2);
            case 0x03:
                return readObject(d, p, end);
            case 0x05:
            case 0x06:
                return null;
            case 0x08:
                p[0] += 4;
                return readObject(d, p, end);
            case 0x0A: {
                long n = readU32(d, p);
                List<Object> list = new ArrayList<Object>();
                for (long i = 0; i < n; i++) list.add(readValue(d, p, end));
                return list;
            }
            case 0x0B:
                p[0] += 10;
                return null;
            case 0x0C:
                return readString(d, p, 4);
            default:
                throw new IllegalStateException("unsupported amf marker " + marker);
        }
    }

    private static long readU32(byte[] d, int[] p) {
        long v = 0;
        for (int i = 0; i < 4; i++) v = (v << 8) | (d[p[0]++] & 0xff);
        return v;
    }

    private static String readString(byte[] d, int[] p, int lenBytes) {
        int n;
        if (lenBytes == 2) {
            n = ((d[p[0]] & 0xff) << 8) | (d[p[0] + 1] & 0xff);
            p[0] += 2;
        } else {
            n = (int) readU32(d, p);
        }
        String s = new String(d, p[0], n, UTF8);
        p[0] += n;
        return s;
    }

    private static Map<String, Object> readObject(byte[] d, int[] p, int end) {
        Map<String, Object> m = new LinkedHashMap<String, Object>();
        while (p[0] < end) {
            int n = ((d[p[0]] & 0xff) << 8) | (d[p[0] + 1] & 0xff);
            p[0] += 2;
            if (n == 0) {
                if (p[0] < end && d[p[0]] == 0x09) p[0]++;
                break;
            }
            String key = new String(d, p[0], n, UTF8);
            p[0] += n;
            m.put(key, readValue(d, p, end));
        }
        return m;
    }
}
